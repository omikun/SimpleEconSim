"""
intents.py — Modular Player and AI Intent (Command) Engine for Call of Capital.

Provides a unified Command Pattern architecture:
- Human players (via UI / client) and AI brains submit `Intent` instances.
- Democracy regime enforces a 1-turn parliamentary approval delay (stub logic);
  autocracy has no delay (immediate execution).
- `BuildIntent` hires a corporate contractor in the target region, transfers
  treasury funds to them, and initiates a multi-turn `ConstructionProject`
  with weather/accident overruns.
- `RecruitArmyIntent` recruits soldiers from unemployed/poor agents, reducing protest energy.
- `MoveArmyIntent` repositions military units across adjacent tiles or initiates combat.
- `ProposeTreatyIntent`, `BreakTreatyIntent`, `DeclareWarIntent` drive bilateral diplomacy.
- All actions obey the conserved-money principle (0 LEAK / pure transfers).
"""

from __future__ import annotations
from treasury_trace import begin_public_change, finish_public_change
import uuid
from dataclasses import dataclass
from typing import TYPE_CHECKING
from goods import Goods
from buildings import BUILDING_RECIPES, ConstructionProject
from agent import Agent, seed_traits, initialize_agent
from army import (MilitaryUnit, recruit_unit, resolve_battle, move_enlisted_people,
                  settle_battle_casualties, discharge_unit)
from diplomacy import get_diplomacy, TreatyType
from war_logic import WarAim

if TYPE_CHECKING:
    from region import Region
    from nation import Nation


class Intent:
    """Base Command class for all strategic decisions."""

    def __init__(self, nation_name: str, intent_type: str, submitted_turn: int = 0,
                 regime_type: str = 'autocracy'):
        self.intent_id = str(uuid.uuid4())[:8]
        self.nation_name = nation_name
        self.intent_type = intent_type
        self.submitted_turn = submitted_turn
        
        # Government type approval logic:
        # Democracy requires parliament approval (1-turn delay stub).
        # Autocracy has no delay (immediate execution).
        if regime_type == 'democracy':
            self.approval_delay = 1
            self.status = 'pending_approval'
        else:
            self.approval_delay = 0
            self.status = 'approved'

        self.logs: list[str] = []

    def validate(self, tiles_by_name: dict[str, Region],
                 nations_by_name: dict[str, Nation], t: int) -> tuple[bool, str]:
        """Validate if this intent can legally be executed."""
        if self.nation_name not in nations_by_name:
            return False, f"Nation '{self.nation_name}' not found."
        return True, "Valid"

    def execute(self, tiles_by_name: dict[str, Region],
                nations_by_name: dict[str, Nation], t: int) -> tuple[bool, str]:
        """Execute the intent, applying state changes and conserved transfers."""
        raise NotImplementedError("Subclasses must implement execute()")

    def step(self, tiles_by_name: dict[str, Region],
             nations_by_name: dict[str, Nation], t: int) -> list[dict]:
        """Step intent state; handle parliamentary approval countdown and execution."""
        events = []
        status_before = self.status
        nation = nations_by_name.get(self.nation_name)
        treasury_before = nation.treasury()['total'] if nation is not None else None
        if self.status == 'pending_approval':
            if self.approval_delay > 0:
                self.approval_delay -= 1
            else:
                self.status = 'approved'
                events.append({
                    't': t,
                    'intent_id': self.intent_id,
                    'event': 'APPROVED',
                    'message': f"Parliament of {self.nation_name} approved {self.intent_type} (ID {self.intent_id})."
                })
                ok, msg = self.execute(tiles_by_name, nations_by_name, t)
                events.append({
                    't': t,
                    'intent_id': self.intent_id,
                    'event': 'EXEC_RESULT',
                    'success': ok,
                    'message': msg
                })
        elif self.status == 'approved':
            ok, msg = self.execute(tiles_by_name, nations_by_name, t)
            events.append({
                't': t,
                'intent_id': self.intent_id,
                'event': 'EXEC_RESULT',
                'success': ok,
                'message': msg
            })

        if nation is not None and nation.tiles:
            from run_trace import emit
            emit(nation.tiles[0], kind='intent_execution', record_class='outcome',
                 phase='strategy', subject={'type': 'nation', 'id': self.nation_name},
                 metric_id='ai.intent_execution', unit='intent_state',
                 after=self.status,
                 operation_id=self.intent_id,
                 decision_id=getattr(self, '_decision_event_id', None),
                 inputs={'intent_type': self.intent_type, 'status_before': status_before,
                         'status_after': self.status,
                         'approval_delay_after': self.approval_delay,
                         'treasury_before': treasury_before,
                         'treasury_after': nation.treasury()['total'],
                         'events': [{'event': ev.get('event'),
                                     'success': ev.get('success'),
                                     'message': ev.get('message')}
                                    for ev in events]})
        return events


class BuildIntent(Intent):
    """Intent to construct a building in a region by hiring and funding a contractor corp."""

    def __init__(self, nation_name: str, region_name: str, building_type: str,
                 submitted_turn: int = 0, regime_type: str = 'autocracy'):
        super().__init__(nation_name, 'BUILD', submitted_turn, regime_type)
        self.region_name = region_name
        self.building_type = building_type
        self.project: ConstructionProject | None = None
        self.recipe_override = None
        self.retrofit_target = None

    def _recipe(self, nation):
        from engineering import quote_recipe
        from innovation import get_innovation_system
        return getattr(self, 'recipe_override', None) or quote_recipe(nation, BUILDING_RECIPES[self.building_type],
                                                    get_innovation_system())

    def validate(self, tiles_by_name: dict[str, Region],
                 nations_by_name: dict[str, Nation], t: int) -> tuple[bool, str]:
        ok, msg = super().validate(tiles_by_name, nations_by_name, t)
        if not ok:
            return False, msg

        nation = nations_by_name[self.nation_name]
        if self.region_name not in tiles_by_name:
            return False, f"Region '{self.region_name}' not found."

        region = tiles_by_name[self.region_name]
        if region not in nation.tiles and getattr(region, 'owner_nation', None) is not nation:
            return False, f"Nation '{self.nation_name}' does not own tile '{self.region_name}'."

        if self.building_type not in BUILDING_RECIPES:
            return False, f"Unknown building recipe '{self.building_type}'."

        try:
            recipe = self._recipe(nation)
        except ValueError as error:
            return False, str(error)
        if getattr(self, 'retrofit_target', None) is not None:
            if self.retrofit_target not in getattr(region, 'buildings', ()):
                return False, 'The selected installation no longer exists.'
            if getattr(self.retrofit_target, 'retrofit_project_id', None):
                return False, 'This installation already has a retrofit in progress.'
        
        # Check treasury cash
        treasury = nation.treasury()
        if treasury['total'] < recipe.cost:
            return False, (f"Insufficient funds for {recipe.display_name}: "
                           f"requires ${recipe.cost:.2f}, treasury total is ${treasury['total']:.2f}.")

        return True, "Valid"

    def execute(self, tiles_by_name: dict[str, Region],
                nations_by_name: dict[str, Nation], t: int) -> tuple[bool, str]:
        valid, reason = self.validate(tiles_by_name, nations_by_name, t)
        nation = nations_by_name.get(self.nation_name)
        region = tiles_by_name.get(self.region_name)
        trace_region = region or (nation.tiles[0] if nation and nation.tiles else None)
        from run_trace import emit

        if not valid:
            self.status = 'rejected'
            if trace_region is not None:
                emit(trace_region, kind='construction_funding_decision',
                     record_class='outcome', phase='strategy',
                     subject={'type': 'tile/intent', 'id': self.intent_id,
                              'tile': getattr(trace_region, 'name', None)},
                     metric_id='construction.funding_decision', unit='funded',
                     before=None, after=False, operation_id=self.intent_id,
                     decision_id=getattr(self, '_decision_event_id', None),
                     inputs={'operation_id': self.intent_id,
                             'intent_type': self.intent_type,
                             'nation': self.nation_name,
                             'target_region': self.region_name,
                             'building_type': self.building_type,
                             'validation_passed': False,
                             'reason': reason, 'source_legs': [],
                             'contractor_payment_made': False})
            return False, f"BuildIntent rejected: {reason}"

        # The operation key is the intent ID, stable across its funding,
        # contractor payment, project, and intent-execution records.
        operation_id = self.intent_id
        recipe = self._recipe(nation)
        cost = recipe.cost

        # 1. Procure funds from government (conserved transfer across sovereign treasury pool)
        treasury = nation.treasury()
        treasury_total_before = float(treasury['total'])
        remaining_needed = cost
        funding_sources = []
        source_legs = []
        bank_withdrawal_event_ids = []

        funding_plan_event_id = emit(
            region, kind='construction_funding_plan',
            record_class='decision', phase='strategy',
            subject={'type': 'tile/intent', 'id': self.intent_id,
                     'tile': region.name},
            operation_id=operation_id,
            decision_id=getattr(self, '_decision_event_id', None),
            inputs={'nation': nation.name, 'target_region': region.name,
                    'building_type': self.building_type,
                    'amount_required': float(cost),
                    'treasury_total_before': treasury_total_before,
                    'source_priority': [
                        'target_municipal_cash_then_deposits',
                        'national_government_cash_then_deposits',
                        'sister_tile_government_cash_then_deposits_in_tile_order',
                        'target_bank_capital'],
                    'rollback_on_shortfall': True})

        # Try tile regional government first, then national government, then sister tiles
        rgov = getattr(region, 'gov', None)
        gov_pool = []
        if rgov is not None:
            gov_pool.append(rgov)
        if nation.government not in gov_pool:
            gov_pool.append(nation.government)
        for tile in nation.tiles:
            tgov = getattr(tile, 'gov', None)
            if tgov and tgov not in gov_pool:
                gov_pool.append(tgov)

        for g in gov_pool:
            if remaining_needed <= 0.001:
                break
            # Cash on hand
            if g.agent.cash > 0:
                take = min(remaining_needed, g.agent.cash)
                cash_before = float(g.agent.cash)
                public_change = begin_public_change(region, g.agent, cash=True)
                g.agent.cash -= take
                finish_public_change(public_change, 'construction_cash_funding')
                from finance_trace import emit_public_account_flow
                emit_public_account_flow(region, g.agent, kind='public_construction_cash_debit',
                                         signed_amount=-take,
                                         inputs={'operation_id': operation_id, 'building_type': self.building_type})
                remaining_needed -= take
                funding_sources.append((g.agent, take))
                source_legs.append({
                    'source_kind': 'government_wallet_cash',
                    'government_scope': ('national' if g is nation.government
                                         else 'municipal_or_sister_tile'),
                    'government_name': getattr(g, 'name', None),
                    'account_id': getattr(g.agent, 'id', None),
                    'currency': getattr(g.agent, 'home_currency',
                                        getattr(region, 'home_currency', None)),
                    'amount_applied': float(take),
                    'amount_counted_toward_project': float(take),
                    'cash_before': cash_before,
                    'cash_after': float(g.agent.cash)})

            # Bank deposits
            if remaining_needed > 0.001:
                for b_tile in nation.tiles:
                    bank = getattr(b_tile, 'bank', None)
                    if bank is not None and g.agent in getattr(bank, 'deposits', {}):
                        dep = bank.deposits[g.agent]
                        take_dep = min(remaining_needed, dep)
                        if take_dep > 0:
                            cash_before = float(g.agent.cash)
                            deposit_before = float(bank.deposits[g.agent])
                            bank_total_before = float(bank.total_deposits)
                            withdrawal_ids = []
                            settled = bank.Withdraw(
                                g.agent, take_dep, trace_region=b_tile, t=t,
                                reason='public_project_funding',
                                trace_event_ids=withdrawal_ids)
                            public_change = begin_public_change(region, g.agent, cash=True)
                            g.agent.cash -= take_dep
                            finish_public_change(public_change, 'construction_deposit_funding')
                            from finance_trace import emit_public_account_flow
                            emit_public_account_flow(region, g.agent, kind='public_construction_deposit_funding_debit',
                                                     signed_amount=-take_dep,
                                                     inputs={'operation_id': operation_id, 'requested_withdrawal': take_dep,
                                                             'settled_withdrawal': settled},
                                                     cause_event_ids=withdrawal_ids or None)
                            remaining_needed -= take_dep
                            funding_sources.append((g.agent, take_dep))
                            bank_withdrawal_event_ids.extend(withdrawal_ids)
                            source_legs.append({
                                'source_kind': 'government_bank_deposit',
                                'government_scope': ('national' if g is nation.government
                                                     else 'municipal_or_sister_tile'),
                                'government_name': getattr(g, 'name', None),
                                'account_id': getattr(g.agent, 'id', None),
                                'bank_id': f'bank:{b_tile.name}',
                                'currency': getattr(b_tile, 'home_currency', None),
                                'government_cash_debit_requested': float(take_dep),
                                'amount_counted_toward_project': float(take_dep),
                                'bank_withdrawal_requested': float(take_dep),
                                'bank_withdrawal_settled': float(settled),
                                'bank_deposit_before': deposit_before,
                                'bank_deposit_after': float(bank.deposits[g.agent]),
                                'bank_total_deposits_before': bank_total_before,
                                'bank_total_deposits_after': float(bank.total_deposits),
                                'government_cash_before': cash_before,
                                'government_cash_after_bank_withdrawal':
                                    float(cash_before + settled),
                                'government_cash_after_funding_debit':
                                    float(g.agent.cash),
                                'withdrawal_event_ids': withdrawal_ids,
                                'unsettled_withdrawal_request':
                                    float(max(0.0, take_dep - settled)),
                                'government_wallet_overdraft_after_funding':
                                    float(max(0.0, -g.agent.cash))})
                    if remaining_needed <= 0.001:
                        break

        # If slightly short but regional bank exists, allow deficit overdraft/borrowing
        bank = getattr(region, 'bank', None)
        if remaining_needed > 0.01:
            capital_before = (float(getattr(bank, 'capital', 0.0))
                              if bank is not None else None)
            if bank is not None and capital_before >= remaining_needed:
                capital_used = float(remaining_needed)
                from bank_trace import begin_change, finish_change
                bank_trace_change = begin_change(bank, region)
                bank.capital -= capital_used
                finish_change(bank, bank_trace_change, 'construction_capital_funding',
                              inputs={'amount': capital_used, 'turn': t})
                source_legs.append({
                    'source_kind': 'target_bank_capital',
                    'bank_id': f'bank:{region.name}',
                    'currency': getattr(region, 'home_currency', None),
                    'amount_applied': capital_used,
                    'amount_counted_toward_project': capital_used,
                    'capital_before': capital_before,
                    'capital_after': float(bank.capital),
                    'capital_available': capital_before,
                    'eligible': True})
                remaining_needed = 0.0
            else:
                if bank is not None:
                    source_legs.append({
                        'source_kind': 'target_bank_capital',
                        'bank_id': f'bank:{region.name}',
                        'currency': getattr(region, 'home_currency', None),
                        'amount_requested': float(remaining_needed),
                        'amount_applied': 0.0,
                        'amount_counted_toward_project': 0.0,
                        'capital_before': capital_before,
                        'capital_after': capital_before,
                        'capital_available': capital_before,
                        'eligible': False})
                # Rollback partial withdrawals
                rollback_legs = []
                for src_agent, amt in funding_sources:
                    cash_before_rollback = float(src_agent.cash)
                    public_change = begin_public_change(region, src_agent, cash=True)
                    src_agent.cash += amt
                    finish_public_change(public_change, 'construction_rollback')
                    from finance_trace import emit_public_account_flow
                    emit_public_account_flow(region, src_agent, kind='public_construction_rollback_refund',
                                             signed_amount=amt, inputs={'operation_id': operation_id})
                    rollback_legs.append({
                        'account_id': getattr(src_agent, 'id', None),
                        'amount_restored': float(amt),
                        'cash_before': cash_before_rollback,
                        'cash_after': float(src_agent.cash)})
                self.status = 'rejected'
                treasury_total_after = float(nation.treasury()['total'])
                decision_causes = ([funding_plan_event_id]
                                   if funding_plan_event_id else [])
                decision_causes.extend(bank_withdrawal_event_ids)
                emit(region, kind='construction_funding_decision',
                     record_class='outcome', phase='strategy',
                     subject={'type': 'tile/intent', 'id': self.intent_id,
                              'tile': region.name},
                     metric_id='construction.funding_decision', unit='funded',
                     before=None, after=False, operation_id=operation_id,
                     decision_id=getattr(self, '_decision_event_id', None),
                     cause_event_ids=decision_causes or None,
                     inputs={'operation_id': operation_id,
                             'intent_type': self.intent_type,
                             'nation': nation.name,
                             'target_region': region.name,
                             'building_type': self.building_type,
                             'amount_required': float(cost),
                             'amount_counted_before_rollback':
                                 float(cost - remaining_needed),
                             'remaining_gap': float(remaining_needed),
                             'treasury_total_before': treasury_total_before,
                             'treasury_total_after_rollback': treasury_total_after,
                             'source_legs': source_legs,
                             'rollback_legs': rollback_legs,
                             'bank_withdrawal_event_ids': bank_withdrawal_event_ids,
                             'contractor_payment_made': False,
                             'failure_reason': 'insufficient_accessible_funds',
                             'note': ('Wallet withdrawals were restored. Any bank deposit '
                                      'withdrawal remains settled because the existing '
                                      'rollback only restores government wallet cash.')})
                return False, f"BuildIntent failed: Insufficient treasury cash (${treasury['total']:.2f} < ${cost:.2f})."

        treasury_total_after_funding = float(nation.treasury()['total'])
        decision_causes = ([funding_plan_event_id]
                           if funding_plan_event_id else [])
        decision_causes.extend(bank_withdrawal_event_ids)
        funding_decision_event_id = emit(
            region, kind='construction_funding_decision',
            record_class='outcome', phase='strategy',
            subject={'type': 'tile/intent', 'id': self.intent_id,
                     'tile': region.name},
            metric_id='construction.funding_decision', unit='funded',
            before=None, after=True, operation_id=operation_id,
            decision_id=getattr(self, '_decision_event_id', None),
            cause_event_ids=decision_causes or None,
            inputs={'operation_id': operation_id,
                    'intent_type': self.intent_type,
                    'nation': nation.name, 'target_region': region.name,
                    'building_type': self.building_type,
                    'amount_required': float(cost),
                    'amount_counted_for_project': float(cost),
                    'remaining_gap': 0.0,
                    'treasury_total_before': treasury_total_before,
                    'treasury_total_after_funding': treasury_total_after_funding,
                    'source_legs': source_legs,
                    'bank_withdrawal_event_ids': bank_withdrawal_event_ids,
                    'contractor_payment_made': False,
                    'funding_order': ('each municipal/national/sister government wallet '
                                      'then its tile-bank deposits, followed by '
                                      'target-bank capital')})

        # 2. Hire or emerge contractor corporation
        from construction_politics import find_or_emerge_contractor
        contractor = find_or_emerge_contractor(region, cost, t)

        # 3. Conserved transfer: Gov pays contractor
        contractor_cash_before = float(contractor.cash)
        _public_write = begin_public_change(None, contractor)
        contractor.cash += cost
        finish_public_change(_public_write, 'intents:BuildIntent.execute',
                             inputs={'source_writer': 'intents.py:BuildIntent.execute:7c35358662fc9f9b:1', 'semantic_operation_id': locals().get('operation_id')})
        contractor_cash_after = float(contractor.cash)
        transfer_contract = {
            'operation_type': 'public_construction_funding',
            'operation_id': operation_id,
            'amount': float(cost),
            'currency': getattr(region, 'home_currency', None),
            'payer_account': {
                'type': 'multi_source_public_funding_pool',
                'id': operation_id,
                'cash_balance_captured': False,
                'source_legs': source_legs,
                'note': ('Composite source only; the game has no pooled wallet. '
                         'See itemized government and bank source legs.')},
            'payee_account': {
                'type': 'contractor_wallet',
                'id': contractor.id,
                'balance_before': contractor_cash_before,
                'balance_after': contractor_cash_after}}
        payment_causes = [funding_decision_event_id]
        payment_causes.extend(bank_withdrawal_event_ids)
        payment_event_id = emit(
            region, kind='construction_contractor_payment',
            record_class='transfer', phase='strategy',
            subject={'type': 'tile/contractor', 'id': str(contractor.id),
                     'tile': region.name},
            metric_id='finance.cash_transfer',
            unit=getattr(region, 'home_currency', None) or 'local_currency',
            before=contractor_cash_before, after=contractor_cash_after,
            operation_id=operation_id,
            cause_event_ids=payment_causes,
            inputs={'transfer_contract': transfer_contract,
                    'funding_decision_event_id': funding_decision_event_id,
                    'bank_withdrawal_event_ids': bank_withdrawal_event_ids,
                    'project_id': f'proj_{self.intent_id}',
                    'contractor_id': contractor.id})

        # 4. Spawn ConstructionProject
        project = ConstructionProject(
            project_id=f"proj_{self.intent_id}",
            nation_name=nation.name,
            region=region,
            recipe=recipe,
            contractor=contractor,
            started_turn=t
        )
        self.project = project
        if getattr(self, 'retrofit_target', None) is not None:
            project.retrofit_target = self.retrofit_target
            self.retrofit_target.retrofit_project_id = project.project_id

        if not hasattr(region, 'construction_projects'):
            region.construction_projects = []
        region.construction_projects.append(project)

        if not hasattr(nation, 'construction_projects'):
            nation.construction_projects = []
        nation.construction_projects.append(project)

        self.status = 'in_progress'
        emit(region, kind='construction_project_commissioned',
             record_class='outcome', phase='strategy',
             subject={'type': 'tile/project', 'id': project.project_id,
                      'tile': region.name},
             metric_id='construction.project_commission', unit='projects',
             before=0, after=1, operation_id=operation_id,
             decision_id=getattr(self, '_decision_event_id', None),
             cause_event_ids=[funding_decision_event_id, payment_event_id],
             inputs={'operation_id': operation_id,
                     'project_id': project.project_id,
                     'nation': nation.name, 'region': region.name,
                     'building_type': self.building_type,
                     'building_name': recipe.display_name,
                     'amount_paid': float(cost),
                     'contractor_id': contractor.id,
                     'contractor_cash_before': contractor_cash_before,
                     'contractor_cash_after': contractor_cash_after,
                     'project_status': project.status,
                     'estimated_duration_turns': project.total_turns,
                     'funding_decision_event_id': funding_decision_event_id,
                     'payment_event_id': payment_event_id})
        msg = (f"Commissioned {recipe.display_name} in {region.name}: paid ${cost:.2f} to contractor. "
               f"Estimated duration: {project.total_turns} turns ({project.base_turns} base + {project.overrun_turns} weather/accidents).")
        self.logs.append(msg)
        return True, msg


class SubsidizeContractorIntent(Intent):
    """Intent to inject an emergency overrun grant into a contractor to avert layoffs."""

    def __init__(self, nation_name: str, project_id: str, amount: float = 100.0,
                 submitted_turn: int = 0, regime_type: str = 'autocracy'):
        super().__init__(nation_name, 'subsidize_contractor', submitted_turn, regime_type)
        self.project_id = project_id
        self.amount = float(amount)

    def execute(self, tiles_by_name: dict[str, Region],
                nations_by_name: dict[str, Nation], t: int) -> tuple[bool, str]:
        nation = nations_by_name.get(self.nation_name)
        if not nation:
            self.status = 'rejected'
            return False, f"SubsidizeContractorIntent failed: Nation '{self.nation_name}' not found."

        target_project = None
        for p in getattr(nation, 'construction_projects', []):
            if p.project_id == self.project_id:
                target_project = p
                break
        if not target_project:
            for tile in getattr(nation, 'tiles', []):
                for p in getattr(tile, 'construction_projects', []):
                    if p.project_id == self.project_id:
                        target_project = p
                        break
                if target_project:
                    break

        if not target_project:
            self.status = 'rejected'
            return False, f"SubsidizeContractorIntent failed: Project '{self.project_id}' not found."

        from construction_politics import subsidize_contractor
        ok, msg = subsidize_contractor(target_project, self.amount, nation, world=None)
        if ok:
            self.status = 'executed'
            self.logs.append(msg)
            return True, msg
        else:
            self.status = 'rejected'
            self.logs.append(msg)
            return False, msg


# =====================================================================
# Military & Diplomatic Intents (M5)
# =====================================================================

class RecruitArmyIntent(Intent):
    """Intent to recruit soldiers from a region into a new military unit."""

    def __init__(self, nation_name: str, region_name: str, soldier_count: int,
                 wage: float = 1.0, equipment: float = 1.0,
                 submitted_turn: int = 0, regime_type: str = 'autocracy'):
        super().__init__(nation_name, 'recruit_army', submitted_turn, regime_type)
        self.region_name = region_name
        self.soldier_count = soldier_count
        self.wage = wage
        self.equipment = equipment

    @property
    def soldiers(self) -> int:
        """Alias for soldier_count."""
        return self.soldier_count

    def validate(self, tiles_by_name: dict[str, Region],
                 nations_by_name: dict[str, Nation], t: int) -> tuple[bool, str]:
        ok, msg = super().validate(tiles_by_name, nations_by_name, t)
        if not ok:
            return False, msg

        nation = nations_by_name[self.nation_name]
        if self.region_name not in tiles_by_name:
            return False, f"Region '{self.region_name}' not found."

        region = tiles_by_name[self.region_name]
        if region not in nation.tiles and getattr(region, 'owner_nation', None) is not nation:
            return False, f"Nation '{self.nation_name}' does not control region '{self.region_name}'."

        if self.soldier_count <= 0:
            return False, "Soldier count must be positive."

        # Check treasury cash for first-turn upkeep
        treasury = nation.treasury()
        needed = self.soldier_count * self.wage
        if treasury['total'] < needed:
            return False, f"Insufficient funds: need ${needed:.2f} for recruitment/wages, treasury has ${treasury['total']:.2f}."

        return True, "Valid"

    def execute(self, tiles_by_name: dict[str, Region],
                nations_by_name: dict[str, Nation], t: int) -> tuple[bool, str]:
        valid, reason = self.validate(tiles_by_name, nations_by_name, t)
        if not valid:
            self.status = 'rejected'
            return False, f"RecruitArmyIntent rejected: {reason}"

        nation = nations_by_name[self.nation_name]
        region = tiles_by_name[self.region_name]

        unit = recruit_unit(nation, region, self.soldier_count, wage=self.wage,
                            equipment=self.equipment, t=t)
        if unit is None:
            self.status = 'failed'
            return False, f"Failed to recruit soldiers in {self.region_name}: insufficient population."

        self.status = 'completed'
        msg = f"Recruited unit {unit.unit_id} ({unit.soldiers} soldiers, str: {unit.strength:.1f}) in {self.region_name}."
        self.logs.append(msg)
        return True, msg


class MoveArmyIntent(Intent):
    """Intent to move a military unit to an adjacent tile (or attack if enemy)."""

    def __init__(self, nation_name: str, unit_id: str, from_region: str,
                 to_region: str, submitted_turn: int = 0, regime_type: str = 'autocracy'):
        super().__init__(nation_name, 'MOVE_ARMY', submitted_turn, regime_type)
        self.unit_id = unit_id
        self.from_region = from_region
        self.to_region = to_region

    def validate(self, tiles_by_name: dict[str, Region],
                 nations_by_name: dict[str, Nation], t: int) -> tuple[bool, str]:
        ok, msg = super().validate(tiles_by_name, nations_by_name, t)
        if not ok:
            return False, msg

        nation = nations_by_name[self.nation_name]
        if self.from_region not in tiles_by_name or self.to_region not in tiles_by_name:
            return False, "Origin or destination tile not found."

        from_tile = tiles_by_name[self.from_region]
        to_tile = tiles_by_name[self.to_region]

        if to_tile.name not in from_tile.neighbors:
            return False, f"Tiles {self.from_region} and {self.to_region} are not adjacent."

        # Find unit
        units = getattr(nation, 'military_units', [])
        unit = next((u for u in units if u.unit_id == self.unit_id), None)
        if unit is None:
            return False, f"Unit '{self.unit_id}' not found in nation's army."
        if unit.region_name != from_tile.name or unit.soldiers <= 0:
            return False, "Unit is not stationed at the origin or has no soldiers."
        if getattr(nation, 'scenario_personnel', False):
            if from_tile.owner_nation is not nation:
                return False, "Origin is outside national supply jurisdiction."
            if to_tile.owner_nation is None:
                return False, "This scenario does not permit settlement by army movement."
            if (to_tile.owner_nation is not nation and
                    to_tile.scenario_location != 'borderland'):
                return False, "Only the border district can be contested."
            people = {a.id for a in from_tile.agents if a.alive}
            if not set(unit.person_ids).issubset(people):
                return False, "Enlisted people are absent from the origin."

        return True, "Valid"

    def execute(self, tiles_by_name: dict[str, Region],
                nations_by_name: dict[str, Nation], t: int) -> tuple[bool, str]:
        valid, reason = self.validate(tiles_by_name, nations_by_name, t)
        if not valid:
            self.status = 'rejected'
            return False, f"MoveArmyIntent rejected: {reason}"

        nation = nations_by_name[self.nation_name]
        from_tile = tiles_by_name[self.from_region]
        to_tile = tiles_by_name[self.to_region]
        unit = next(u for u in nation.military_units if u.unit_id == self.unit_id)

        target_owner = getattr(to_tile, 'owner_nation', None)
        diplomacy = get_diplomacy()

        # Case 1: Friendly move (own tile or wilderness)
        if target_owner is None or target_owner is nation:
            if hasattr(from_tile, 'military_units') and unit in from_tile.military_units:
                from_tile.military_units.remove(unit)
            if not hasattr(to_tile, 'military_units'):
                to_tile.military_units = []
            to_tile.military_units.append(unit)
            if unit.scenario_personnel:
                move_enlisted_people(unit, from_tile, to_tile)
            unit.region_name = to_tile.name
            self.status = 'completed'
            msg = f"Unit {unit.unit_id} moved from {self.from_region} to {self.to_region}."
            self.logs.append(msg)
            return True, msg

        # Case 2: Foreign tile
        if not diplomacy.are_at_war(nation.name, target_owner.name):
            self.status = 'rejected'
            return False, f"Cannot move troops into foreign tile {to_tile.name} of {target_owner.name} without a state of war."

        # Combat resolution
        defenders = [u for u in getattr(target_owner, 'military_units', []) if u.region_name == to_tile.name]
        attackers = ([u for u in nation.military_units if u.region_name == from_tile.name
                      and u.soldiers > 0] if unit.scenario_personnel else [unit])
        attacker_strength_before = sum(u.strength for u in attackers)
        defender_strength_before = sum(u.strength for u in defenders)
        soldiers_before = sum(u.soldiers for u in attackers + defenders)
        battle = resolve_battle(attackers, defenders)
        from run_trace import emit
        battle_event_id = emit(to_tile, kind='war_battle_outcome', record_class='outcome',
                               phase='strategy',
                               subject={'type': 'tile', 'id': to_tile.name,
                                        'attacker': nation.name, 'defender': target_owner.name},
                               metric_id='war.battle', unit='soldiers',
                               before=soldiers_before,
                               after=sum(u.soldiers for u in attackers + defenders),
                               operation_id=self.intent_id,
                               decision_id=getattr(self, '_decision_event_id', None),
                               inputs={'attacker_unit_ids': [u.unit_id for u in attackers],
                                       'defender_unit_ids': [u.unit_id for u in defenders],
                                       'attacker_strength_before': attacker_strength_before,
                                       'defender_strength_before': defender_strength_before,
                                       'defense_bonus': 1.2, **battle})
        diplomacy.record_battle(nation.name, target_owner.name,
                                battle['atk_losses'], battle['def_losses'])
        if unit.scenario_personnel:
            settle_battle_casualties([*attackers, *defenders], list(tiles_by_name.values()),
                                    list(nations_by_name.values()), t)

        if battle['conquered']:
            # Territorial transfer
            target_owner.transfer_tile(to_tile, nation)
            emit(to_tile, kind='war_territory_transfer',
                 record_class='outcome', phase='strategy',
                 subject={'type': 'tile', 'id': to_tile.name},
                 metric_id='war.territory_control',
                 before=target_owner.name, after=nation.name,
                 operation_id=self.intent_id,
                 decision_id=getattr(self, '_decision_event_id', None),
                 cause_event_ids=[battle_event_id] if battle_event_id else [],
                 inputs={'attacker': nation.name,
                         'previous_owner': target_owner.name,
                         'battle_winner': battle['winner'],
                         'remaining_defender_strength': battle['remaining_def_strength']})
            if unit.scenario_personnel:
                for defender in list(defenders):
                    discharge_unit(defender, list(tiles_by_name.values()), target_owner)
            for attacker in attackers:
                if attacker.soldiers <= 0:
                    discharge_unit(attacker, list(tiles_by_name.values()), nation)
                    continue
                if hasattr(from_tile, 'military_units') and attacker in from_tile.military_units:
                    from_tile.military_units.remove(attacker)
                if not hasattr(to_tile, 'military_units'):
                    to_tile.military_units = []
                to_tile.military_units.append(attacker)
                if attacker.scenario_personnel:
                    move_enlisted_people(attacker, from_tile, to_tile)
                attacker.region_name = to_tile.name
            self.status = 'completed'
            msg = f"VICTORY: Unit {unit.unit_id} conquered {self.to_region} from {target_owner.name} (Casualties: Atk -{battle['atk_losses']}, Def -{battle['def_losses']})."
        elif battle['winner'] == 'attacker':
            self.status = 'completed'
            msg = f"BATTLE: Unit {unit.unit_id} won engagement at {self.to_region}, but garrison holds."
        else:
            self.status = 'completed'
            msg = f"REPULSED: Attack on {self.to_region} repulsed by {target_owner.name} defenders."

        self.logs.append(msg)
        return True, msg


class ProposeTreatyIntent(Intent):
    """Intent to propose a bilateral treaty (Trade Pact, NAP, Defensive Alliance)."""

    def __init__(self, nation_name: str, target_nation_name: str, treaty_type: str,
                 submitted_turn: int = 0, regime_type: str = 'autocracy'):
        super().__init__(nation_name, 'PROPOSE_TREATY', submitted_turn, regime_type)
        self.target_nation_name = target_nation_name
        self.treaty_type = treaty_type

    def execute(self, tiles_by_name: dict[str, Region],
                nations_by_name: dict[str, Nation], t: int) -> tuple[bool, str]:
        if self.target_nation_name not in nations_by_name:
            self.status = 'rejected'
            return False, f"Target nation '{self.target_nation_name}' not found."

        diplomacy = get_diplomacy()
        ok, msg = diplomacy.propose_treaty(self.nation_name, self.target_nation_name,
                                           self.treaty_type, t=t,
                                           _trace_world={
                                               'nations': list(nations_by_name.values())})
        self.status = 'completed' if ok else 'rejected'
        self.logs.append(msg)
        return ok, msg


class BreakTreatyIntent(Intent):
    """Intent to break / betray an active treaty."""

    def __init__(self, nation_name: str, target_nation_name: str, treaty_type: str,
                 submitted_turn: int = 0, regime_type: str = 'autocracy'):
        super().__init__(nation_name, 'BREAK_TREATY', submitted_turn, regime_type)
        self.target_nation_name = target_nation_name
        self.treaty_type = treaty_type

    def execute(self, tiles_by_name: dict[str, Region],
                nations_by_name: dict[str, Nation], t: int) -> tuple[bool, str]:
        diplomacy = get_diplomacy()
        res = diplomacy.break_treaty(self.nation_name, self.target_nation_name,
                                     self.treaty_type, t=t,
                                     _trace_world={
                                         'nations': list(nations_by_name.values())})
        ok = res['success']
        msg = res['message']
        self.status = 'completed' if ok else 'failed'
        self.logs.append(msg)
        return ok, msg


class DeclareWarIntent(Intent):
    """Intent to declare war against a foreign nation."""

    def __init__(self, nation_name: str, target_nation_name: str, reason: str = "",
                 submitted_turn: int = 0, regime_type: str = 'autocracy',
                 aim: WarAim | None = None):
        super().__init__(nation_name, 'DECLARE_WAR', submitted_turn, regime_type)
        self.target_nation_name = target_nation_name
        self.reason = reason or "Geopolitical confrontation"
        self.aim = aim or WarAim()

    def execute(self, tiles_by_name: dict[str, Region],
                nations_by_name: dict[str, Nation], t: int) -> tuple[bool, str]:
        if self.target_nation_name not in nations_by_name:
            self.status = 'rejected'
            return False, f"Target nation '{self.target_nation_name}' not found."

        diplomacy = get_diplomacy()
        events = diplomacy.declare_war(self.nation_name, self.target_nation_name,
                                       t=t, reason=self.reason, aim=self.aim,
                                       nations=nations_by_name)
        self.status = 'completed'
        msg = f"War declared on {self.target_nation_name} by {self.nation_name}."
        self.logs.append(msg)
        return True, msg


class ProposePeaceIntent(Intent):
    """Offer a ceasefire recognizing actual current territorial control."""

    def __init__(self, nation_name: str, target_nation_name: str,
                 submitted_turn: int = 0, regime_type: str = 'autocracy'):
        super().__init__(nation_name, 'PROPOSE_PEACE', submitted_turn, regime_type)
        self.target_nation_name = target_nation_name

    def execute(self, tiles_by_name, nations_by_name, t):
        result = get_diplomacy().propose_peace(self.nation_name,
                                               self.target_nation_name, t,
                                               _trace_world={
                                                   'nations': list(nations_by_name.values())})
        self.status = 'completed' if result['success'] else 'rejected'
        self.logs.append(result['message'])
        return result['success'], result['message']


class RespondPeaceIntent(Intent):
    """Accept or reject a previously offered ceasefire."""

    def __init__(self, nation_name: str, proposer_name: str, accept: bool,
                 submitted_turn: int = 0, regime_type: str = 'autocracy'):
        super().__init__(nation_name, 'RESPOND_PEACE', submitted_turn, regime_type)
        self.proposer_name = proposer_name
        self.accept = accept

    def execute(self, tiles_by_name, nations_by_name, t):
        result = get_diplomacy().respond_peace(self.nation_name,
                                               self.proposer_name,
                                               self.accept, t,
                                               _trace_world={
                                                   'nations': list(nations_by_name.values())})
        self.status = 'completed' if result['success'] else 'rejected'
        self.logs.append(result['message'])
        return result['success'], result['message']


# =====================================================================
# Main Intent & Project Stepping Orchestrator
# =====================================================================

def step_intents_and_construction(t: int, tiles: list, nations: list, on_event=None, world: dict = None) -> list[dict]:
    """Execute pending intents and advance active construction projects across all tiles (M5)."""
    events = []
    tiles_by_name = {r.name: r for r in tiles}
    nations_by_name = {n.name: n for n in nations}

    # 1. Resolve accepted ceasefires before movement or battle.  Pending
    # parliamentary approval remains pending; all intents still step once.
    for nation in nations:
        for intent in list(getattr(nation, 'intents', [])):
            if not isinstance(intent, RespondPeaceIntent) or not intent.accept:
                continue
            sub_events = intent.step(tiles_by_name, nations_by_name, t)
            events.extend(sub_events)
            if on_event:
                for ev in sub_events:
                    on_event(t, ev['event'], ev['message'])
            if intent.status in ('completed', 'rejected', 'failed'):
                nation.intents.remove(intent)

    # 2. Step pending intents per nation
    for nation in nations:
        intents = getattr(nation, 'intents', [])
        for intent in list(intents):
            if isinstance(intent, RespondPeaceIntent) and intent.accept:
                continue
            sub_events = intent.step(tiles_by_name, nations_by_name, t)
            events.extend(sub_events)
            if on_event:
                for ev in sub_events:
                    on_event(t, ev['event'], ev['message'])
            # Remove completed or rejected intents from active queue
            if intent.status in ('completed', 'rejected', 'failed'):
                intents.remove(intent)

    # Firms use prior settled sales and private finance before projects advance.
    from technology_adoption import step_private_adoption
    for ev in step_private_adoption(tiles, nations, t):
        events.append(ev)
        if on_event:
            on_event(t, ev['event'], ev['message'])

    # 2. Step active construction projects and building staffing across all tiles
    from construction_politics import step_construction_politics
    for r in tiles:
        # Operational building staffing
        for b in getattr(r, 'buildings', []):
            if hasattr(b, 'step_operational_staffing'):
                b.step_operational_staffing(r, t)

        projects = getattr(r, 'construction_projects', [])
        for p in list(projects):
            completed_building = p.step(t, world=world)
            # Emit project events
            for ev in p.events:
                if ev['t'] == t:
                    events.append(ev)
                    if on_event:
                        on_event(t, ev['event'], ev['message'])
            # Clean up completed projects from active list
            if p.status == 'completed':
                projects.remove(p)

        # Construction contractor lobbying, drought layoffs, and riots
        step_construction_politics(r, t, world=world)

    return events


# =====================================================================
# Inter-Governmental Fiscal Transfer & Shortfall Resolution
# =====================================================================

def execute_fiscal_transfer_and_build(world, nation_name: str, region_name: str, building_type: str,
                                      transfer_source: str, transfer_amount: float, t: int) -> tuple[bool, str]:
    """Execute a fiscal grant or bank loan to fund a construction project shortfall."""
    tiles_by_name = {r.name: r for r in world.get('tiles', [])}
    nations_by_name = {n.name: n for n in world.get('nations', [])}

    if nation_name not in nations_by_name or region_name not in tiles_by_name:
        return False, "Nation or Region not found."

    nation = nations_by_name[nation_name]
    region = tiles_by_name[region_name]
    rgov = getattr(region, 'gov', None)
    if rgov is None:
        return False, f"Region {region_name} has no municipal government."

    recipe = BUILDING_RECIPES.get(building_type)
    if not recipe:
        return False, f"Unknown building recipe '{building_type}'."

    transfer_amount = max(0.0, float(transfer_amount))

    # 1. Execute the source transfer
    if transfer_source == 'province_grant':
        province = getattr(region, 'province', None)
        prov_siblings = [t for t in getattr(province, 'tiles', []) if t != region and getattr(t, 'gov', None)]
        nation_siblings = [t for t in nation.tiles if t != region and t not in prov_siblings and getattr(t, 'gov', None)]
        pool_tiles = prov_siblings + nation_siblings
        gathered = 0.0
        for ot in pool_tiles:
            ogov = getattr(ot, 'gov', None)
            if ogov is not None and ogov is not rgov:
                # 1. Cash on hand
                if ogov.agent.cash > 0:
                    take = min(transfer_amount - gathered, ogov.agent.cash)
                    _public_write = begin_public_change(None, ogov.agent)
                    ogov.agent.cash -= take
                    finish_public_change(_public_write, 'intents:execute_fiscal_transfer_and_build',
                                         inputs={'source_writer': 'intents.py:execute_fiscal_transfer_and_build:ca2e4daa917e332c:1', 'semantic_operation_id': locals().get('operation_id')})
                    _public_write = begin_public_change(None, rgov.agent)
                    rgov.agent.cash += take
                    finish_public_change(_public_write, 'intents:execute_fiscal_transfer_and_build',
                                         inputs={'source_writer': 'intents.py:execute_fiscal_transfer_and_build:c2fc38fa334a9836:1', 'semantic_operation_id': locals().get('operation_id')})
                    gathered += take
                    if gathered >= transfer_amount - 0.01:
                        break
                # 2. Bank deposits
                bank = getattr(ot, 'bank', None)
                if bank and ogov.agent in getattr(bank, 'deposits', {}):
                    dep = bank.deposits[ogov.agent]
                    take_dep = min(transfer_amount - gathered, dep)
                    if take_dep > 0:
                        bank.Withdraw(ogov.agent, take_dep, trace_region=ot, t=t,
                                      reason='provincial_budget_transfer')
                        _public_write = begin_public_change(None, ogov.agent)
                        ogov.agent.cash -= take_dep
                        finish_public_change(_public_write, 'intents:execute_fiscal_transfer_and_build',
                                             inputs={'source_writer': 'intents.py:execute_fiscal_transfer_and_build:acda784ec3a3d2db:1', 'semantic_operation_id': locals().get('operation_id')})
                        _public_write = begin_public_change(None, rgov.agent)
                        rgov.agent.cash += take_dep
                        finish_public_change(_public_write, 'intents:execute_fiscal_transfer_and_build',
                                             inputs={'source_writer': 'intents.py:execute_fiscal_transfer_and_build:f57e93f6afac059e:1', 'semantic_operation_id': locals().get('operation_id')})
                        gathered += take_dep
                        if gathered >= transfer_amount - 0.01:
                            break
        if gathered < transfer_amount - 0.01 and pool_tiles:
            return False, f"Province grant shortfall: only collected ${gathered:.2f} of ${transfer_amount:.2f}."

    elif transfer_source == 'national_bailout':
        nat_gov = nation.government
        if nat_gov.agent.cash < transfer_amount:
            # Check national bank deposits
            return False, f"National sovereign treasury has insufficient cash (${nat_gov.agent.cash:.2f} < ${transfer_amount:.2f})."
        _public_write = begin_public_change(None, nat_gov.agent)
        nat_gov.agent.cash -= transfer_amount
        finish_public_change(_public_write, 'intents:execute_fiscal_transfer_and_build',
                             inputs={'source_writer': 'intents.py:execute_fiscal_transfer_and_build:ea1421955a8e7c55:1', 'semantic_operation_id': locals().get('operation_id')})
        _public_write = begin_public_change(None, rgov.agent)
        rgov.agent.cash += transfer_amount
        finish_public_change(_public_write, 'intents:execute_fiscal_transfer_and_build',
                             inputs={'source_writer': 'intents.py:execute_fiscal_transfer_and_build:1bc24321fd4b8b11:1', 'semantic_operation_id': locals().get('operation_id')})

    elif transfer_source == 'bank_loan':
        bank = getattr(region, 'bank', None)
        if bank is None or getattr(bank, 'capital', 0.0) < transfer_amount:
            return False, f"Municipal bank has insufficient capital for loan (${getattr(bank, 'capital', 0.0):.2f} < ${transfer_amount:.2f})."
        from bank_trace import begin_change, finish_change
        bank_trace_change = begin_change(bank, region)
        bank.capital -= transfer_amount
        finish_change(bank, bank_trace_change, 'municipal_construction_transfer',
                      inputs={'amount': transfer_amount, 'turn': t})
        _public_write = begin_public_change(None, rgov.agent)
        rgov.agent.cash += transfer_amount
        finish_public_change(_public_write, 'intents:execute_fiscal_transfer_and_build',
                             inputs={'source_writer': 'intents.py:execute_fiscal_transfer_and_build:e32feb2be473b8bd:1', 'semantic_operation_id': locals().get('operation_id')})

    # 2. Now execute BuildIntent
    intent = BuildIntent(nation_name, region_name, building_type, submitted_turn=t, regime_type=nation.regime_type)
    nation.submit_intent(intent, t)
    ok, msg = intent.execute(tiles_by_name, nations_by_name, t)
    if ok:
        from client.desktop.engine import ticker_push
        transfer_desc = {
            'province_grant': f"funded via Provincial Grant (${transfer_amount:.0f})",
            'national_bailout': f"funded via Sovereign National Bailout (${transfer_amount:.0f})",
            'bank_loan': f"funded via Municipal Bank Loan (${transfer_amount:.0f})",
        }.get(transfer_source, "")
        ticker_push(world, t, 'CONSTRUCT', f"Commissioned {recipe.display_name} in {region_name} ({transfer_desc}).", (245, 180, 50))
    return ok, msg


def execute_equalization_grant(world, nation_name: str, region_name: str, grant_source: str = 'national_sovereign', grant_amount: float = 250.0, t: int = 0) -> tuple[bool, str]:
    """Manually transfer an Equalization Grant from Sovereign National Treasury or Provincial Pool to a distressed municipal tile."""
    tiles_by_name = {r.name: r for r in world.get('tiles', [])}
    nations_by_name = {n.name: n for n in world.get('nations', [])}

    nation = nations_by_name.get(nation_name)
    region = tiles_by_name.get(region_name)
    if not nation or not region:
        return False, "Invalid nation or region for equalization grant."

    rgov = getattr(region, 'gov', None)
    if not rgov:
        return False, "Target region has no municipal government."

    grant_amount = max(0.0, float(grant_amount))
    if grant_amount <= 0:
        return False, "Grant amount must be positive."

    if grant_source == 'national_sovereign':
        nat_gov = nation.government
        if nat_gov.agent.cash < grant_amount:
            return False, f"National sovereign treasury has insufficient cash (${nat_gov.agent.cash:.2f} < ${grant_amount:.2f})."
        _public_write = begin_public_change(None, nat_gov.agent)
        nat_gov.agent.cash -= grant_amount
        finish_public_change(_public_write, 'intents:execute_equalization_grant',
                             inputs={'source_writer': 'intents.py:execute_equalization_grant:01bdfccb1c0b2fd8:1', 'semantic_operation_id': locals().get('operation_id')})
        _public_write = begin_public_change(None, rgov.agent)
        rgov.agent.cash += grant_amount
        finish_public_change(_public_write, 'intents:execute_equalization_grant',
                             inputs={'source_writer': 'intents.py:execute_equalization_grant:c85f5ea7db90c285:1', 'semantic_operation_id': locals().get('operation_id')})
        source_name = "Sovereign National Treasury"
    elif grant_source == 'provincial_pool':
        province = getattr(region, 'province', None)
        prov_siblings = [t_tile for t_tile in getattr(province, 'tiles', []) if t_tile != region and getattr(t_tile, 'gov', None)]
        nation_siblings = [t_tile for t_tile in nation.tiles if t_tile != region and t_tile not in prov_siblings and getattr(t_tile, 'gov', None)]
        pool_tiles = prov_siblings + nation_siblings
        gathered = 0.0
        for ot in pool_tiles:
            ogov = getattr(ot, 'gov', None)
            if ogov is not None and ogov is not rgov:
                if ogov.agent.cash > 0:
                    take = min(grant_amount - gathered, ogov.agent.cash)
                    _public_write = begin_public_change(None, ogov.agent)
                    ogov.agent.cash -= take
                    finish_public_change(_public_write, 'intents:execute_equalization_grant',
                                         inputs={'source_writer': 'intents.py:execute_equalization_grant:89f09b8fadf82844:1', 'semantic_operation_id': locals().get('operation_id')})
                    _public_write = begin_public_change(None, rgov.agent)
                    rgov.agent.cash += take
                    finish_public_change(_public_write, 'intents:execute_equalization_grant',
                                         inputs={'source_writer': 'intents.py:execute_equalization_grant:e5712d8df4457c33:1', 'semantic_operation_id': locals().get('operation_id')})
                    gathered += take
                    if gathered >= grant_amount - 0.01:
                        break
        if gathered < grant_amount - 0.01:
            return False, f"Provincial pool shortfall: only collected ${gathered:.2f} of ${grant_amount:.2f}."
        source_name = "Provincial Equalization Pool"
    else:
        return False, f"Unknown grant source '{grant_source}'."

    from client.desktop.engine import ticker_push
    city_name = getattr(region, 'display_name', getattr(region, 'city_name', region.name))
    ticker_push(world, t, 'POLICY', f"Disbursed Equalization Grant of ${grant_amount:.0f} to {city_name} from {source_name}.", (120, 220, 140))
    return True, f"Disbursed ${grant_amount:.0f} Equalization Grant to {city_name}."


class IssueSovereignBondIntent(Intent):
    """Announce a domestic sovereign debt bond offering (1-turn advance notice, 20/50/100 turns)."""
    def __init__(self, nation_name: str, principal: float = 1000.0, duration_turns: int = 20, submitted_turn: int = 0):
        super().__init__(nation_name, 'issue_bond', submitted_turn)
        self.principal = principal
        self.duration_turns = duration_turns

    def execute(self, tiles_by_name: dict, nations_by_name: dict, t: int, world: dict | None = None) -> tuple[bool, str]:
        nation = nations_by_name.get(self.nation_name)
        if not nation:
            return False, f"Nation '{self.nation_name}' not found."
        from sovereign_bonds import get_bond_market
        market = get_bond_market()
        ok, msg, offering = market.announce_bond_offering(nation, self.principal, self.duration_turns, t, world)
        return ok, msg


class BuyForeignBondIntent(Intent):
    """Purchase a foreign nation's sovereign bond or live offering into foreign exchange reserves."""
    def __init__(self, nation_name: str, target_nation_name: str = "", offering_id: str = "", principal: float = 500.0, duration_turns: int = 20, submitted_turn: int = 0):
        super().__init__(nation_name, 'buy_bond', submitted_turn)
        self.target_nation_name = target_nation_name
        self.offering_id = offering_id
        self.principal = principal
        self.duration_turns = duration_turns

    def execute(self, tiles_by_name: dict, nations_by_name: dict, t: int, world: dict | None = None) -> tuple[bool, str]:
        buyer = nations_by_name.get(self.nation_name)
        if not buyer:
            return False, "Buyer nation not found."
        from sovereign_bonds import get_bond_market
        market = get_bond_market()
        if self.offering_id:
            ok, msg, bond = market.purchase_live_offering(buyer, self.offering_id, world or {}, t)
            return ok, msg
        else:
            issuer = nations_by_name.get(self.target_nation_name)
            if not issuer:
                return False, "Issuer nation not found."
            ok, msg, bond = market.issue_bond(issuer, buyer, self.principal, self.duration_turns, t, world)
            if ok and world:
                from client.desktop.engine import ticker_push
                ticker_push(world, t, 'FINANCE', f"🌐 {buyer.name} purchased ${self.principal:.0f} of {issuer.name}'s {self.duration_turns}t Sovereign Bonds.", (120, 220, 140))
            return ok, msg


class RedeemBondEarlyIntent(Intent):
    """Redeem and repay a sovereign bond early."""
    def __init__(self, nation_name: str, bond_id: str = "", submitted_turn: int = 0):
        super().__init__(nation_name, 'redeem_bond', submitted_turn)
        self.bond_id = bond_id

    def execute(self, tiles_by_name: dict, nations_by_name: dict, t: int, world: dict | None = None) -> tuple[bool, str]:
        from sovereign_bonds import get_bond_market
        market = get_bond_market()
        return market.redeem_bond_early(self.bond_id, world or {}, t)


class LobbyRatingUpgradeIntent(Intent):
    """Lobby the ISRB for a credit rating upgrade."""
    def __init__(self, nation_name: str, submitted_turn: int = 0):
        super().__init__(nation_name, 'lobby_upgrade', submitted_turn)

    def execute(self, tiles_by_name: dict, nations_by_name: dict, t: int, world: dict | None = None) -> tuple[bool, str]:
        nation = nations_by_name.get(self.nation_name)
        if not nation:
            return False, f"Nation '{self.nation_name}' not found."
        from sovereign_bonds import get_bond_market
        market = get_bond_market()
        ok, msg, is_scandal = market.isrb.lobby_upgrade(nation, t)
        if world:
            from client.desktop.engine import ticker_push
            color = (240, 80, 80) if is_scandal else ((120, 220, 140) if ok else (220, 160, 60))
            ticker_push(world, t, 'ALERT' if is_scandal else 'POLICY', msg, color)
        return ok, msg


class LobbyAdversaryDowngradeIntent(Intent):
    """Lobby the ISRB for an aggressive audit and downgrade against a rival."""
    def __init__(self, nation_name: str, target_nation_name: str = "", submitted_turn: int = 0):
        super().__init__(nation_name, 'lobby_downgrade', submitted_turn)
        self.target_nation_name = target_nation_name

    def execute(self, tiles_by_name: dict, nations_by_name: dict, t: int, world: dict | None = None) -> tuple[bool, str]:
        nation = nations_by_name.get(self.nation_name)
        if not nation:
            return False, f"Nation '{self.nation_name}' not found."
        from sovereign_bonds import get_bond_market
        market = get_bond_market()
        ok, msg, is_scandal = market.isrb.lobby_adversary_downgrade(nation, self.target_nation_name, t)
        if world:
            from client.desktop.engine import ticker_push
            color = (240, 80, 80) if is_scandal else ((120, 220, 140) if ok else (220, 160, 60))
            ticker_push(world, t, 'ALERT' if is_scandal else 'POLICY', msg, color)
        return ok, msg


class AcquireBoardSeatIntent(Intent):
    """Acquire a permanent seat on the ISRB Board of Governors."""
    def __init__(self, nation_name: str, submitted_turn: int = 0):
        super().__init__(nation_name, 'acquire_board_seat', submitted_turn)

    def execute(self, tiles_by_name: dict, nations_by_name: dict, t: int, world: dict | None = None) -> tuple[bool, str]:
        nation = nations_by_name.get(self.nation_name)
        if not nation:
            return False, f"Nation '{self.nation_name}' not found."
        from sovereign_bonds import get_bond_market
        market = get_bond_market()
        ok, msg = market.isrb.acquire_board_seat(nation)
        if world:
            from client.desktop.engine import ticker_push
            ticker_push(world, t, 'POLICY', msg, (245, 215, 120) if ok else (220, 160, 60))
        return ok, msg


class EncloseCommonsIntent(Intent):
    """Sovereign decree to enclose feudal land on a tile, stripping customary usufruct rights."""

    def __init__(self, nation_name: str, tile_name: str, plot_id: str,
                 rent_rate: float = 3.0, submitted_turn: int = 0,
                 regime_type: str = 'autocracy'):
        super().__init__(nation_name, 'ENCLOSE_COMMONS', submitted_turn, regime_type)
        self.tile_name = tile_name
        self.plot_id = plot_id
        self.rent_rate = rent_rate

    def validate(self, tiles_by_name: dict, nations_by_name: dict, t: int) -> tuple[bool, str]:
        ok, msg = super().validate(tiles_by_name, nations_by_name, t)
        if not ok:
            return False, msg
        tile = tiles_by_name.get(self.tile_name)
        if not tile:
            return False, f"Tile '{self.tile_name}' not found."
        nation = nations_by_name.get(self.nation_name)
        if getattr(tile, 'owner_nation', None) != nation:
            return False, f"Tile '{self.tile_name}' does not belong to {self.nation_name}."
        tenure = getattr(tile, 'tenure', None)
        if not tenure:
            return False, f"Tile '{self.tile_name}' has no land tenure."
        plot = tenure.find_plot(self.plot_id)
        if not plot:
            return False, f"Plot '{self.plot_id}' not found on tile '{self.tile_name}'."
        from land_tenure import TenureStatus
        if plot.tenure != TenureStatus.FEUDAL:
            return False, f"Plot '{self.plot_id}' is already {plot.tenure.value}."
        return True, "Valid"

    def execute(self, tiles_by_name: dict, nations_by_name: dict, t: int, world: dict | None = None) -> tuple[bool, str]:
        val_ok, val_msg = self.validate(tiles_by_name, nations_by_name, t)
        if not val_ok:
            self.status = 'rejected'
            return False, val_msg

        tile = tiles_by_name[self.tile_name]
        from enclosure import execute_enclosure
        ok, msg, events = execute_enclosure(tile, self.plot_id, t, rent_rate=self.rent_rate)
        self.status = 'completed' if ok else 'failed'
        self.logs.append(msg)
        if world and ok:
            try:
                from client.desktop.engine import ticker_push
                ticker_push(world, t, 'ENCLOSURE', msg, (230, 140, 70))
            except ImportError:
                pass
        return ok, msg


class IssueMunicipalSewerBondIntent(Intent):
    """Float a 50-turn Municipal Revenue Sewer Bond to finance the Bazalgette Intercepting Sewer Network."""
    def __init__(self, nation_name: str, tile_name: str, submitted_turn: int = 0):
        super().__init__(nation_name, 'issue_sewer_bond', submitted_turn)
        self.tile_name = tile_name

    def validate(self, tiles_by_name: dict, nations_by_name: dict, t: int) -> tuple[bool, str]:
        ok, msg = super().validate(tiles_by_name, nations_by_name, t)
        if not ok:
            return False, msg
        tile = tiles_by_name.get(self.tile_name)
        if not tile:
            return False, f"Tile '{self.tile_name}' not found."
        nation = nations_by_name.get(self.nation_name)
        if getattr(tile, 'owner_nation', None) != nation:
            return False, f"Tile '{self.tile_name}' does not belong to {self.nation_name}."
        return True, "Valid"

    def execute(self, tiles_by_name: dict, nations_by_name: dict, t: int, world: dict | None = None) -> tuple[bool, str]:
        val_ok, val_msg = self.validate(tiles_by_name, nations_by_name, t)
        if not val_ok:
            self.status = 'rejected'
            return False, val_msg
        nation = nations_by_name[self.nation_name]
        tile = tiles_by_name[self.tile_name]
        from sovereign_bonds import get_bond_market
        market = get_bond_market()
        ok, msg, bond = market.issue_municipal_sewer_bond(nation, tile, t, world)
        self.status = 'completed' if ok else 'failed'
        self.logs.append(msg)
        return ok, msg


class RestructureDebtIntent(Intent):
    """Propose or ratify a diplomatic debt restructuring accord (Brady bond swap & haircut)."""
    def __init__(self, nation_name: str, creditor_name: str, haircut_pct: float | None = None,
                 use_brady_bonds: bool = True, grant_unequal_treaty: bool = False, submitted_turn: int = 0):
        super().__init__(nation_name, 'restructure_debt', submitted_turn)
        self.creditor_name = creditor_name
        self.haircut_pct = haircut_pct
        self.use_brady_bonds = use_brady_bonds
        self.grant_unequal_treaty = grant_unequal_treaty

    def execute(self, tiles_by_name: dict, nations_by_name: dict, t: int, world: dict | None = None) -> tuple[bool, str]:
        debtor = nations_by_name.get(self.nation_name)
        creditor = nations_by_name.get(self.creditor_name)
        if not debtor or not creditor:
            return False, "Invalid nations for debt restructuring."
        from imperialism import get_imperialism_manager
        imp_mgr = get_imperialism_manager()
        ok, msg, res = imp_mgr.negotiate_debt_restructuring(
            debtor, creditor, self.haircut_pct, self.use_brady_bonds, self.grant_unequal_treaty, world, t
        )
        self.status = 'completed' if ok else 'failed'
        self.logs.append(msg)
        return ok, msg


class EscalateCaisseIntent(Intent):
    """Creditor imperial decree: escalate receivership to Caisse de la Dette Publique."""
    def __init__(self, nation_name: str, debtor_name: str, submitted_turn: int = 0):
        super().__init__(nation_name, 'escalate_caisse', submitted_turn)
        self.debtor_name = debtor_name

    def execute(self, tiles_by_name: dict, nations_by_name: dict, t: int, world: dict | None = None) -> tuple[bool, str]:
        creditor = nations_by_name.get(self.nation_name)
        debtor = nations_by_name.get(self.debtor_name)
        if not creditor or not debtor:
            return False, "Invalid nations."
        from imperialism import get_imperialism_manager
        imp_mgr = get_imperialism_manager()
        can_esc, reason, threat = imp_mgr.can_escalate_to_caisse(creditor, debtor, world)
        if not can_esc:
            self.status = 'rejected'
            return False, reason
        rec = imp_mgr.get_active_receivership_on(debtor.name)
        if not rec:
            return False, "No active receivership."
        ok, msg = imp_mgr.escalate_to_caisse(rec.receivership_id, world, t)
        self.status = 'completed' if ok else 'failed'
        self.logs.append(msg)
        return ok, msg
