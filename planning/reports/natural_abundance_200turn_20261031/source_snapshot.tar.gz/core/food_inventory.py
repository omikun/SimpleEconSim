"""Commodity-list compatibility with exact thousandth-unit food balances.

Only the stored representation of edible goods changes. Every public read,
iteration, slice, pickle, and copy exposes ordinary commodity units.
"""
from decimal import Decimal, ROUND_HALF_EVEN
from goods import Goods

SCALE = 1000
EDIBLE = frozenset((int(Goods.food), int(Goods.prepared_food)))


def milli(value):
    return int((Decimal(str(value)) * SCALE).quantize(Decimal('1'), rounding=ROUND_HALF_EVEN))


class FoodInventory(list):
    def __init__(self, values=()):
        super().__init__(milli(v) if i in EDIBLE else v for i, v in enumerate(values))

    def __getitem__(self, index):
        if isinstance(index, slice):
            return list(self)[index]
        value = super().__getitem__(index)
        i = index if index >= 0 else len(self) + index
        return value / SCALE if i in EDIBLE else value

    def __setitem__(self, index, value):
        if isinstance(index, slice):
            values = list(self)
            values[index] = value
            list.clear(self)
            list.extend(self, (milli(v) if i in EDIBLE else v for i, v in enumerate(values)))
        else:
            i = index if index >= 0 else len(self) + index
            list.__setitem__(self, index, milli(value) if i in EDIBLE else value)

    def __iter__(self):
        return (self[i] for i in range(len(self)))

    def __repr__(self):
        return repr(list(self))

    def __eq__(self, other):
        return list(self) == list(other) if isinstance(other, (list, tuple)) else False

    def copy(self):
        return type(self)(list(self))

    def extend(self, values):
        for value in values:
            self.append(value)

    def append(self, value):
        list.append(self, milli(value) if len(self) in EDIBLE else value)

    def __reduce_ex__(self, protocol):
        return type(self), (list(self),)
