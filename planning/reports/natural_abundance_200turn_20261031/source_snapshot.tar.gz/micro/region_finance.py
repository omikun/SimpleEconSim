"""
Corporate wages, profit distributions, owner bailouts, taxation, and consumption multipliers.
"""
from treasury_trace import begin_public_change as _trace_public_begin, finish_public_change as _trace_public_finish
from treasury_trace import begin_public_change, finish_public_change

import math
import forex as _fx
from goods import Goods
from logger import loginfo, logwarning
from labor_contract import ensure_labor_agreement


def _trace_treasury_flow(region, kind, amount, inputs, cause_event_ids=None):
    nation = getattr(region, 'owner_nation', None)
    if nation is None or amount == 0:
        return
    from run_trace import emit
    return emit(region, kind=kind, record_class='transfer',
         subject={'type': 'nation', 'id': nation.name},
         metric_id='finance.treasury_flow', unit=nation.currency,
         after=amount, inputs={'tile': region.name, **inputs},
         cause_event_ids=cause_event_ids)


def pay_wages(region, t):
    """Firms pay wages to their employees (sovereign cash or company scrip under Truck System)."""
    owner = getattr(region, 'owner_nation', None)
    truck_act_enacted = getattr(owner, 'truck_act_enacted', False) if owner else False

    for a in region.agents:
        if a.is_corporation and len(a.employees) > 0:
            # If Truck Act enacted, pay_mode is legally mandated as 'cash'
            pay_mode = "cash" if truck_act_enacted else getattr(a, 'pay_mode', 'cash')

            # Cash-strapped firms adopt company scrip if Truck Act is not enacted
            if not truck_act_enacted and a.cash < len(a.employees) * getattr(a, 'wage', 1.0) and pay_mode == "cash":
                pay_mode = "scrip"
                a.pay_mode = "scrip"

            for e in a.employees:
                if getattr(e, 'is_striking', False) or getattr(e, 'in_revolt', False):
                    continue
                agreement = ensure_labor_agreement(e, a, t)
                wage_nominal = max(0.0, float(agreement.pay_rate))
                e.nominal_wage = wage_nominal
                e.authorized_deductions = 0.0
                e.wage_withheld = 0.0
                if pay_mode == "scrip":
                    # Truck System: paid in corporate company scrip vouchers
                    e.scrip_wallet += wage_nominal
                    e.wages_received = wage_nominal
                    e.realized_wage = wage_nominal
                    e.mem_push('mem_wages', wage_nominal)
                    a.scrip_issued += wage_nominal
                    from economy.actor_accounts import record as record_economic_event
                    record_economic_event(region, 'scrip_wage', turn=t,
                                          payer_id=a.id, recipient_id=e.id,
                                          amount=wage_nominal,
                                          detail={'tender': 'company_scrip'})
                else:
                    # Legal tender cash payment
                    employer_cash_before = float(a.cash)
                    wage_to_pay = min(a.cash, wage_nominal)
                    from state_handler import transfer_cash
                    transfer_cash(
                        a, e, wage_to_pay,
                        region=region,
                        kind='region_finance:pay_wages',
                        payer_source_writer='region_finance.py:pay_wages:46655f1219471632:1',
                        payee_source_writer='region_finance.py:pay_wages:2781207220d5d2a8:1',
                        record_event_kind='wage',
                        turn=t,
                    )
                    e.wages_received = wage_to_pay
                    e.realized_wage = wage_to_pay
                    e.wage_withheld = wage_nominal - wage_to_pay
                    if e.wage_withheld > 1e-9:
                        from economy.actor_accounts import (accrue_wage_arrear,
                                                            record as record_economic_event)
                        payable_before, payable_after, claim_before, claim_after = (
                            accrue_wage_arrear(a, e.id, e.wage_withheld, worker=e))
                        liabilities = getattr(a, 'wage_liabilities', [])
                        liabilities.append({'worker_id': e.id, 'turn': t,
                                            'amount': e.wage_withheld, 'status': 'unpaid'})
                        a.wage_liabilities = liabilities[-500:]
                        record_economic_event(
                            region, 'wage_arrears_accrued', turn=t,
                            payer_id=a.id, recipient_id=e.id,
                            amount=e.wage_withheld,
                            currency=getattr(region, 'home_currency', None),
                            detail={'nominal_wage': wage_nominal,
                                    'cash_paid': wage_to_pay,
                                    'arrears_accrued': e.wage_withheld,
                                    'employer_cash_before': employer_cash_before,
                                    'employer_cash_after': float(a.cash),
                                    'employer_arrears_before': payable_before,
                                    'employer_arrears_after': payable_after,
                                    'worker_claim_before': claim_before,
                                    'worker_claim_after': claim_after,
                                    'reason': 'employer_cash_below_nominal_wage'})
                        from run_trace import emit
                        emit(region, kind='wage_arrears_accrued',
                             record_class='outcome', phase='finance',
                             subject={'type': 'employment_wage_claim',
                                      'id': f'{a.id}:{e.id}', 'tile': region.name,
                                      'employer_id': a.id, 'worker_id': e.id},
                             metric_id='finance.wage_arrears',
                             unit=getattr(region, 'home_currency', None)
                             or 'local_currency',
                             before=payable_before, after=payable_after,
                             formula_id='labor.wage_arrears_accrual.v1',
                             inputs={'employer_id': a.id, 'worker_id': e.id,
                                     'nominal_wage': wage_nominal,
                                     'cash_paid': wage_to_pay,
                                     'arrears_accrued': e.wage_withheld,
                                     'employer_cash_before': employer_cash_before,
                                     'employer_cash_after': float(a.cash),
                                     'worker_claim_before': claim_before,
                                     'worker_claim_after': claim_after,
                                     'truck_act_enacted': bool(truck_act_enacted),
                                     'pay_mode': pay_mode,
                                     'reason': 'employer_cash_below_nominal_wage'})
                    e.mem_push('mem_wages', wage_to_pay)


def settle_wage_arrears(region, t, *, firm_id=None, firm=None, liquidating=False):
    """Pay old wage claims from cash beyond the next payroll reserve.

    On liquidation, any available firm cash is available to wage claimants.
    The return value contains the settled claims; each transfer updates the
    employer's liability and the worker's cash or currency wallet.
    """
    from economy.actor_accounts import (
        _wage_liability_totals, record as record_economic_event,
        settle_wage_arrear,
    )
    by_id = {int(person.id): person for person in getattr(region, 'agents', ())}
    firms = [firm for firm in getattr(region, 'agents', ())
             if getattr(firm, 'is_corporation', False)
             and (liquidating or getattr(firm, 'alive', True))
             and (firm_id is None or firm.id == firm_id)]
    if firm_id is not None and not any(firm.id == firm_id for firm in firms):
        matched_firm = firm or by_id.get(int(firm_id))
        if (matched_firm is not None
                and int(matched_firm.id) == int(firm_id)
                and getattr(matched_firm, 'is_corporation', False)
                and (liquidating or getattr(matched_firm, 'alive', True))):
            firms.append(matched_firm)
    payments = []
    for firm in firms:
        total, claims = _wage_liability_totals(firm)
        if total <= 0 or not claims:
            continue
        payroll_reserve = 0.0
        if not liquidating:
            from labor_contract import ensure_labor_agreement
            for employee in getattr(firm, 'employees', ()):
                if not getattr(employee, 'alive', True) or getattr(employee, 'is_striking', False) or getattr(employee, 'in_revolt', False):
                    continue
                agreement = ensure_labor_agreement(employee, firm, t)
                payroll_reserve += max(0.0, float(agreement.pay_rate))
        available_cash = max(0.0, float(firm.cash) - payroll_reserve)
        if available_cash <= 1e-9:
            continue
        liability_rows = list(getattr(firm, 'wage_liabilities', ()))
        first_turn = {}
        for row in liability_rows:
            worker_id = int(row.get('worker_id', -1))
            if worker_id not in claims or str(row.get('status', 'unpaid')).lower() in {
                    'paid', 'settled', 'written_off', 'forgiven', 'cancelled', 'inherited'}:
                continue
            first_turn[worker_id] = min(first_turn.get(worker_id, int(row.get('turn', 0))),
                                        int(row.get('turn', 0)))
        for worker_id in sorted(claims, key=lambda ident: (first_turn.get(ident, t), ident)):
            if available_cash <= 1e-9:
                break
            worker = (by_id.get(int(worker_id))
                      or (getattr(firm, 'wage_arrears_claimants', {}) or {}).get(worker_id))
            if worker is None or not getattr(worker, 'alive', True):
                continue
            claim_before = float(claims[worker_id])
            paid = min(claim_before, available_cash)
            if paid <= 1e-9:
                continue
            firm_cash_before = float(firm.cash)
            worker_cash_before = float(worker.cash)
            currency = getattr(region, 'home_currency', None)
            local_institution_agents = {
                id(getattr(getattr(region, 'gov', None), 'agent', None)),
                id(getattr(getattr(region, 'charity', None), 'agent', None)),
            }
            is_local_worker = (by_id.get(int(worker_id)) is worker
                               or id(worker) in local_institution_agents)
            use_wallet = bool(currency and (
                not is_local_worker
                or getattr(worker, '_bank_ref', None) is not getattr(region, 'bank', None)))
            wallet_before = None
            if use_wallet:
                wallet_before = float(_fx.fx_balance(worker, currency))
                _fx.fx_add(worker, currency, paid)
            else:
                _trace_cash_write = _trace_public_begin(None, worker)
                worker.cash += paid
                _trace_public_finish(_trace_cash_write, 'region_finance:settle_wage_arrears',
                                     inputs={"source_writer": 'region_finance.py:settle_wage_arrears:49f73179dd4447af:1'})
            _trace_cash_write = _trace_public_begin(None, firm)
            firm.cash -= paid
            _trace_public_finish(_trace_cash_write, 'region_finance:settle_wage_arrears',
                                 inputs={"source_writer": 'region_finance.py:settle_wage_arrears:f04a045740ff4dd2:1'})
            total_before, total_after, claim_before, claim_after, settled = (
                settle_wage_arrear(firm, worker_id, paid))
            if settled <= 0:
                # State is checked before changing either balance, so this is
                # only a defensive guard for corrupt or stale claim records.
                _trace_cash_write = _trace_public_begin(None, firm)
                firm.cash += paid
                _trace_public_finish(_trace_cash_write, 'region_finance:settle_wage_arrears',
                                     inputs={"source_writer": 'region_finance.py:settle_wage_arrears:f3d865cdd62fe3d3:1'})
                if use_wallet:
                    _fx.fx_sub(worker, currency, paid)
                else:
                    _trace_cash_write = _trace_public_begin(None, worker)
                    worker.cash -= paid
                    _trace_public_finish(_trace_cash_write, 'region_finance:settle_wage_arrears',
                                         inputs={"source_writer": 'region_finance.py:settle_wage_arrears:38fc853500d150a5:1'})
                continue
            transfer_id = f'wage-arrears:{t}:{firm.id}:{worker.id}:{len(payments)}'
            detail = {
                'transfer_id': transfer_id, 'payment_kind': 'wage_arrears_paid',
                'employer_id': firm.id, 'worker_id': worker.id,
                'currency': currency, 'amount': float(settled),
                'employer_cash_before': firm_cash_before,
                'employer_cash_after': float(firm.cash),
                'worker_cash_before': worker_cash_before,
                'worker_cash_after': float(worker.cash),
                'claim_before': float(claim_before),
                'claim_after': float(claim_after),
                'employer_payable_before': float(total_before),
                'employer_payable_after': float(total_after),
                'payroll_reserve': float(payroll_reserve),
                'liquidation': bool(liquidating),
            }
            cash_event = record_economic_event(
                region, 'wage_arrears_paid', turn=t, payer_id=firm.id,
                recipient_id=None if use_wallet else worker.id,
                amount=settled, asset_id=transfer_id, source_id=transfer_id,
                currency=currency,
                detail={**detail, 'settlement': 'foreign_wallet' if use_wallet else 'cash'})
            wallet_event = None
            if use_wallet:
                wallet_event = record_economic_event(
                    region, 'wallet_transfer_in', turn=t,
                    recipient_id=worker.id, amount=settled,
                    asset_id=transfer_id, source_id=transfer_id,
                    currency=currency,
                    detail={**detail, 'payment_kind': 'wage_arrears_paid',
                            'wallet_before': wallet_before,
                            'wallet_after': float(_fx.fx_balance(worker, currency))})
            from run_trace import emit
            emit(region, kind='wage_arrears_repaid', record_class='transfer',
                 phase='finance',
                 subject={'type': 'employment_wage_claim',
                          'id': f'{firm.id}:{worker.id}', 'tile': region.name,
                          'employer_id': firm.id, 'worker_id': worker.id},
                 metric_id='finance.wage_arrears', unit=currency or 'local_currency',
                 before=float(claim_before), after=float(claim_after),
                 formula_id='labor.wage_arrears.repayment.v1',
                 inputs={**detail, 'cash_event': {'tile': region.name,
                                                  'event_id': cash_event['id']},
                         'wallet_event': ({'tile': region.name,
                                           'event_id': wallet_event['id']}
                                          if wallet_event else None),
                         'reason': ('firm_liquidation' if liquidating else
                                    'surplus_after_current_payroll')})
            payments.append({'firm_id': firm.id, 'worker_id': worker.id,
                             'amount': settled, 'claim_after': claim_after,
                             'transfer_id': transfer_id})
            available_cash -= settled
    return payments


def liquidate_wage_arrears(region, t, firm, *, reason='firm_exit'):
    """Use a departing firm's remaining cash for wage claims, then write off loss."""
    from economy.actor_accounts import (
        _wage_liability_totals, record as record_economic_event,
        writeoff_wage_arrear,
    )
    payments = settle_wage_arrears(
        region, t, firm_id=firm.id, firm=firm, liquidating=True)
    _, claims = _wage_liability_totals(firm)
    written_off = []
    for worker_id, claim_amount in sorted(claims.items()):
        total_before, total_after, claim_before, claim_after, amount = (
            writeoff_wage_arrear(firm, worker_id, claim_amount))
        if amount <= 0:
            continue
        event = record_economic_event(
            region, 'wage_arrears_written_off', turn=t,
            payer_id=firm.id, recipient_id=worker_id, amount=amount,
            asset_id=f'wage-arrears:{firm.id}:{worker_id}',
            source_id=f'wage-arrears:{firm.id}:{worker_id}',
            currency=getattr(region, 'home_currency', None),
            detail={'employer_id': firm.id, 'worker_id': worker_id,
                    'employer_payable_before': float(total_before),
                    'employer_payable_after': float(total_after),
                    'claim_before': float(claim_before),
                    'claim_after': float(claim_after),
                    'reason': reason, 'settlement': 'limited_liability_writeoff'})
        from run_trace import emit
        emit(region, kind='wage_arrears_written_off', record_class='outcome',
             phase='finance',
             subject={'type': 'employment_wage_claim',
                      'id': f'{firm.id}:{worker_id}', 'tile': region.name,
                      'employer_id': firm.id, 'worker_id': worker_id},
             metric_id='finance.wage_arrears',
             unit=getattr(region, 'home_currency', None) or 'local_currency',
             before=float(claim_before), after=float(claim_after),
             formula_id='labor.wage_arrears.employer_exit_writeoff.v1',
             inputs={'event_id': event['id'], 'employer_id': firm.id,
                     'worker_id': worker_id, 'amount': float(amount),
                     'reason': reason,
                     'cash_recovered': sum(row['amount'] for row in payments)})
        written_off.append({'worker_id': worker_id, 'amount': amount,
                            'event_id': event['id']})

    orphaned = max(0.0, float(getattr(firm, 'wage_arrears_balance', 0.0)))
    if orphaned > 1e-9:
        before = orphaned
        firm.wage_arrears_balance = 0.0
        event = record_economic_event(
            region, 'wage_arrears_written_off', turn=t, payer_id=firm.id,
            amount=orphaned, asset_id=f'wage-arrears:{firm.id}:orphaned',
            source_id=f'wage-arrears:{firm.id}:orphaned',
            currency=getattr(region, 'home_currency', None),
            detail={'employer_id': firm.id, 'employer_payable_before': before,
                    'employer_payable_after': 0.0, 'reason': reason,
                    'settlement': 'unmatched_liability_writeoff',
                    'claimant_id_missing': True})
        from run_trace import emit
        emit(region, kind='wage_arrears_writeoff_without_claimant',
             record_class='outcome', phase='finance',
             subject={'type': 'agent', 'id': firm.id, 'tile': region.name},
             metric_id='finance.wage_arrears',
             unit=getattr(region, 'home_currency', None) or 'local_currency',
             before=before, after=0.0,
             formula_id='labor.wage_arrears.orphan_liability_writeoff.v1',
             inputs={'event_id': event['id'], 'reason': reason,
                     'employer_id': firm.id})
    return {'payments': payments, 'written_off': written_off,
            'cash_recovered': sum(row['amount'] for row in payments),
            'claims_written_off': sum(row['amount'] for row in written_off)}


def redeem_company_scrip(region, t):
    """Workers redeem company scrip at the employer's company store ('Tommy Shop') for marked-up food.

    Strictly 100% money and goods conserved:
      - Food moves 1-for-1 from firm inventory to employee.
      - Scrip is retired (store credit settled). Zero sovereign currency leaked.
      - If worker is broke and unfed, company store issues emergency food on credit ('slate'),
        bonding the worker into debt peonage (company_debt).
    """
    food_price = getattr(region, 'food_price', 1.0)
    tommy_markup = 1.35  # Historical 35% Tommy Shop markup over open market

    for a in region.agents:
        if not a.is_corporation or not a.employees:
            continue

        for e in a.employees:
            if not getattr(e, 'alive', True):
                continue
            from food_access import meal_gap, food_surplus
            food_needed = meal_gap(e)
            if food_needed <= 0:
                continue

            tommy_price = round(food_price * tommy_markup, 2)

            # 1. Scrip Redemption at Tommy Shop
            if getattr(e, 'scrip_wallet', 0.0) >= tommy_price:
                can_buy = min(food_needed, int(e.scrip_wallet // tommy_price))
                if can_buy > 0:
                    firm_food = a.inv_get(Goods.food, 0)
                    if firm_food < can_buy and a.cash >= (can_buy - firm_food) * food_price:
                        needed_to_buy = can_buy - firm_food
                        for seller in region.agents:
                            if seller.id != a.id and food_surplus(seller, region) > 0:
                                qty = min(needed_to_buy, food_surplus(seller, region))
                                cost = qty * food_price
                                if a.cash >= cost:
                                    _trace_cash_write = _trace_public_begin(None, a)
                                    a.cash -= cost
                                    _trace_public_finish(_trace_cash_write, 'region_finance:redeem_company_scrip',
                                                         inputs={"source_writer": 'region_finance.py:redeem_company_scrip:2b8d9e9e21ba278a:1'})
                                    _trace_cash_write = _trace_public_begin(None, seller)
                                    seller.cash += cost
                                    _trace_public_finish(_trace_cash_write, 'region_finance:redeem_company_scrip',
                                                         inputs={"source_writer": 'region_finance.py:redeem_company_scrip:886e95c500987750:1'})
                                    seller.inv_add(Goods.food, -qty)
                                    a.inv_add(Goods.food, qty)
                                    from economy.actor_accounts import record as record_economic_event
                                    record_economic_event(region, 'store_inventory_purchase', turn=t,
                                                          payer_id=a.id, recipient_id=seller.id,
                                                          good=Goods.food, quantity=qty, amount=cost,
                                                          detail={'tender': 'cash', 'store_markup': tommy_markup})
                                    needed_to_buy -= qty
                                    if needed_to_buy <= 0:
                                        break

                    available = min(can_buy, a.inv_get(Goods.food, 0))
                    if available > 0:
                        total_cost = available * tommy_price
                        e.scrip_wallet -= total_cost
                        a.scrip_redeemed += total_cost
                        a.inv_add(Goods.food, -available)
                        e.inv_add(Goods.food, available)
                        from economy.actor_accounts import record as record_economic_event
                        record_economic_event(region, 'scrip_store_sale', turn=t,
                                              payer_id=e.id, recipient_id=a.id,
                                              good=Goods.food, quantity=available,
                                              amount=total_cost,
                                              detail={'tender': 'company_scrip',
                                                      'unit_price': tommy_price})
                        e.food_purchased = getattr(e, 'food_purchased', 0) + available
                        food_needed -= available

            # Cash-paid workers can purchase a meal from the same real stock.
            cash_units = min(food_needed, max(0, int(a.inv_get(Goods.food, 0))),
                             max(0, int(e.cash // tommy_price))) if tommy_price > 0 else 0
            if cash_units:
                from state_handler import adjust_cash
                cost = cash_units * tommy_price
                adjust_cash(e, -cost, kind='company_store_purchase',
                            source_writer='region_finance.redeem_company_scrip')
                adjust_cash(a, cost, kind='company_store_receipt',
                            source_writer='region_finance.redeem_company_scrip')
                a.inv_add(Goods.food, -cash_units)
                e.inv_add(Goods.food, cash_units)
                e.food_purchased += cash_units
                food_needed -= cash_units
                from economy.actor_accounts import record as record_economic_event
                record_economic_event(region, 'spot_sale', turn=t, payer_id=e.id,
                                      recipient_id=a.id, good=Goods.food,
                                      quantity=cash_units, amount=cost,
                                      detail={'tender': 'cash', 'unit_price': tommy_price,
                                              'channel': 'company_store', 'seller_receipt': cost})

            # 2. Debt Peonage Credit Advance (The Slate). Defaults preserve the
            # existing one-unit agreement; an explicit contract can cover a meal
            # within its cumulative credit ceiling.
            if food_needed > 0 and e.inv_get(Goods.food, 0) < 2 and e.cash < food_price and e.scrip_wallet < tommy_price:
                ceiling = max(0, getattr(a, 'company_food_credit_limit', 4 * tommy_price))
                allowance = max(0, int((ceiling - e.company_debt) // tommy_price)) if tommy_price > 0 else 0
                units = min(food_needed, max(0, int(a.inv_get(Goods.food, 0))), allowance,
                            max(0, int(getattr(a, 'company_food_credit_units', 1))))
                if units > 0:
                    a.inv_add(Goods.food, -units)
                    e.inv_add(Goods.food, units)
                    e.food_purchased = getattr(e, 'food_purchased', 0) + units
                    e.company_debt += units * tommy_price
                    from economy.actor_accounts import record as record_economic_event
                    record_economic_event(region, 'scrip_food_credit', turn=t,
                                          payer_id=a.id, recipient_id=e.id,
                                          good=Goods.food, quantity=units,
                                          amount=units * tommy_price, debt_credit=units * tommy_price,
                                          detail={'tender': 'company_store_credit',
                                                  'company_debt_after': e.company_debt})
                    e.despair = min(1.0, getattr(e, 'despair', 0.0) + 0.15)
                    e.alienation = min(1.0, getattr(e, 'alienation', 0.0) + 0.10)
                    try:
                        from economy.true_cost_ledger import get_true_cost_ledger
                        get_true_cost_ledger().record_bank(
                            bank=a, region=region, turn=t,
                            interest_and_discounts=0.0, funding_costs=0.0,
                            scrip_debt_issued=units * tommy_price
                        )
                    except Exception:
                        pass


def credit_owner_pay(region, owner, amount):
    """Credit an owner's share, routing through the FX wallet when
    the owner lives on a DIFFERENT (or wilderness) tile so the
    per-currency audit still counts the money."""
    if amount <= 0:
        return {'tender': 'none', 'currency': None,
                'balance_before': 0.0, 'balance_after': 0.0,
                'public_write_event_ids': []}
    if getattr(owner, '_bank_ref', None) is region.bank:
        balance_before = float(owner.cash)
        _trace_cash_write = _trace_public_begin(None, owner)
        owner.cash += amount
        public_write_event_ids = _trace_public_finish(
            _trace_cash_write, 'region_finance:credit_owner_pay',
            inputs={"source_writer": 'region_finance.py:credit_owner_pay:1fa42d3efa7da89c:1'})
        return {'tender': 'cash', 'currency': getattr(region, 'home_currency', None),
                'balance_before': balance_before,
                'balance_after': float(owner.cash),
                'public_write_event_ids': public_write_event_ids}
    else:
        if region.home_currency:
            balance_before = float(_fx.fx_balance(owner, region.home_currency))
            _fx.fx_add(owner, region.home_currency, amount)
            return {'tender': 'wallet', 'currency': region.home_currency,
                    'balance_before': balance_before,
                    'balance_after': float(_fx.fx_balance(owner, region.home_currency)),
                    'public_write_event_ids': []}
        else:
            balance_before = float(owner.cash)
            _trace_cash_write = _trace_public_begin(None, owner)
            owner.cash += amount
            public_write_event_ids = _trace_public_finish(
                _trace_cash_write, 'region_finance:credit_owner_pay',
                inputs={"source_writer": 'region_finance.py:credit_owner_pay:6be844980406d2e6:1'})
            return {'tender': 'cash', 'currency': None,
                    'balance_before': balance_before,
                    'balance_after': float(owner.cash),
                    'public_write_event_ids': public_write_event_ids}


def _record_owner_payment(region, kind, payer, owner, amount, settlement, t=None,
                          owner_loan_before=None, owner_loan_after=None):
    """Post a firm's cash payment and the owner's cash or wallet receipt."""
    from economy.actor_accounts import record as record_economic_event

    turn = int(t if t is not None else getattr(region, '_last_turn', 0))
    currency = settlement.get('currency') or getattr(region, 'home_currency', None)
    transfer_id = f'owner-payment:{kind}:{turn}:{payer.id}:{owner.id}'
    detail = {'transfer_id': transfer_id, 'payment_kind': kind,
              'tender': settlement.get('tender', 'cash'),
              'payment_currency': currency,
              'owner_balance_before': settlement.get('balance_before', 0.0),
              'owner_balance_after': settlement.get('balance_after', 0.0),
              'payer_id': payer.id, 'owner_id': owner.id}
    if owner_loan_before is not None:
        detail['owner_loan_before'] = float(owner_loan_before)
    if owner_loan_after is not None:
        detail['owner_loan_after'] = float(owner_loan_after)
    if settlement.get('tender') == 'wallet':
        record_economic_event(
            region, kind, turn=turn, payer_id=payer.id, amount=amount,
            asset_id=transfer_id, currency=currency,
            detail={**detail, 'recipient_settlement': 'foreign_wallet'})
        record_economic_event(
            region, 'wallet_transfer_in', turn=turn, recipient_id=owner.id,
            amount=amount, asset_id=transfer_id, source_id=transfer_id,
            currency=currency, detail=detail)
    else:
        record_economic_event(
            region, kind, turn=turn, payer_id=payer.id,
            recipient_id=owner.id, amount=amount, asset_id=transfer_id,
            currency=currency, detail=detail)

    from run_trace import emit
    payer_cash_after = float(payer.cash)
    payer_cash_before = payer_cash_after + float(amount)
    value_before = (detail['owner_balance_before']
                    if settlement.get('tender') == 'wallet'
                    else payer_cash_before)
    value_after = (detail['owner_balance_after']
                   if settlement.get('tender') == 'wallet'
                   else payer_cash_after)
    public_write_event_ids = list(settlement.get('public_write_event_ids') or ())
    payment_event_id = emit(
        region, kind='owner_payment_settled', record_class='transfer',
        phase='finance',
        subject={'type': 'owner_payment', 'id': transfer_id,
                 'payer_id': payer.id, 'owner_id': owner.id,
                 'tile': region.name},
        metric_id='finance.owner_transfer', unit=currency or 'local_currency',
        before=value_before, after=value_after,
        inputs={**detail, 'amount': float(amount),
                'payer_cash_before': payer_cash_before,
                'payer_cash_after': payer_cash_after},
        cause_event_ids=public_write_event_ids)
    _trace_government_owner_payment(
        region, payer=payer, owner=owner, amount=amount, payment_kind=kind,
        settlement=settlement, turn=turn,
        payer_cash_before=payer_cash_before,
        payer_cash_after=payer_cash_after,
        payment_event_id=payment_event_id)


def _trace_government_owner_payment(
        region, *, payer, owner, amount, payment_kind, settlement, turn,
        payer_cash_before, payer_cash_after, payment_event_id):
    """Record owner cash receipts that increase a counted public account."""
    government = getattr(region, 'gov', None)
    owner_nation = getattr(region, 'owner_nation', None)
    public_write_event_ids = list(settlement.get('public_write_event_ids') or ())
    if (government is None or getattr(government, 'agent', None) is not owner
            or owner_nation is None or not public_write_event_ids
            or settlement.get('tender') != 'cash'):
        return None
    # A payment between two accounts already included in the same national
    # treasury is internal and has no net nation-level flow.
    public_government_ids = {
        row.get('government_id') for row in owner_nation.treasury().get('accounts', ())}
    if getattr(payer, 'is_government', False) and payer.id in public_government_ids:
        return None
    receipt = (float(settlement.get('balance_after', 0.0))
               - float(settlement.get('balance_before', 0.0)))
    if receipt <= 0.0:
        return None

    from finance_trace import account_ref, emit_treasury_leg, transfer_contract

    currency = (getattr(owner_nation, 'currency', None)
                or getattr(region, 'home_currency', None) or 'local_currency')
    payer_account = account_ref(
        'agent', payer.id, currency,
        balance_before=float(payer_cash_before),
        balance_after=float(payer_cash_after), balance_scope='cash')
    payee_account = account_ref(
        'government_treasury', government.name, currency,
        nation_id=owner_nation.name, subaccount='government_agent.cash',
        balance_before=float(settlement['balance_before']),
        balance_after=float(settlement['balance_after']),
        balance_scope='government_agent.cash')
    payer_debit = float(payer_cash_before) - float(payer_cash_after)
    matches = math.isclose(payer_debit, receipt, rel_tol=1e-10, abs_tol=1e-8)
    operation_id = (
        f'government-owner-payment:{payment_kind}:{turn}:{payer.id}:{owner.id}')
    contract = transfer_contract(
        operation_id, 'government_owner_payment_receipt', side='payee',
        amount=receipt, amount_currency=currency,
        payer_account=payer_account, payee_account=payee_account,
        local_cash_leg_amount=receipt, local_cash_leg_currency=currency,
        counterparty_leg_status=(
            'payer_cash_balance_captured' if matches
            else 'payer_cash_balance_differs_from_public_receipt'),
        payment_kind=payment_kind,
        owner_payment_event_id=payment_event_id)
    return emit_treasury_leg(
        region, kind='government_owner_payment_received',
        nation_name=owner_nation.name, currency=currency,
        signed_amount=receipt, contract=contract, phase='finance',
        subject_type='nation',
        cause_event_ids=[*public_write_event_ids, payment_event_id],
        inputs={'payer_id': payer.id, 'owner_id': owner.id,
                'payment_kind': payment_kind,
                'amount': float(amount), 'receipt': receipt,
                'turn': int(turn), 'payer_cash_debit': payer_debit})


def _record_owner_funding(region, owner, firm, amount, tender, currency,
                          source_before, source_after, firm_cash_before,
                          firm_cash_after, owner_loan_before, owner_loan_after,
                          t):
    """Record an owner's cash or wallet loan into a firm."""
    from economy.actor_accounts import record as record_economic_event

    turn = int(t if t is not None else getattr(region, '_last_turn', 0))
    transfer_id = f'owner-financing:{turn}:{owner.id}:{firm.id}'
    detail = {'transfer_id': transfer_id, 'tender': tender,
              'currency': currency, 'amount': float(amount),
              'owner_id': owner.id, 'firm_id': firm.id,
              'source_balance_before': float(source_before),
              'source_balance_after': float(source_after),
              'firm_cash_before': float(firm_cash_before),
              'firm_cash_after': float(firm_cash_after),
              'owner_loan_before': float(owner_loan_before),
              'owner_loan_after': float(owner_loan_after),
              'reason': 'owner_payroll_bailout'}
    if tender == 'wallet':
        record_economic_event(
            region, 'owner_financing', turn=turn, recipient_id=firm.id,
            amount=amount, asset_id=transfer_id, currency=currency,
            detail={**detail, 'funding_source': 'owner_wallet'})
        record_economic_event(
            region, 'wallet_transfer_out', turn=turn, payer_id=owner.id,
            amount=amount, asset_id=transfer_id, source_id=transfer_id,
            currency=currency, detail=detail)
    else:
        record_economic_event(
            region, 'owner_financing', turn=turn, payer_id=owner.id,
            recipient_id=firm.id, amount=amount, asset_id=transfer_id,
            currency=currency, detail=detail)

    from run_trace import emit
    emit(region, kind='owner_financing_settled', record_class='transfer',
         phase='finance',
         subject={'type': 'owner_financing', 'id': transfer_id,
                  'owner_id': owner.id, 'firm_id': firm.id,
                  'tile': region.name},
         metric_id='finance.owner_transfer',
         unit=currency or 'local_currency',
         before=float(source_before), after=float(source_after),
         inputs=detail)


def repay_owner_loan(region, agent, owner, payroll, t=None):
    """Repay debt owed by corporation back to its owner."""
    if agent.owner_loan <= 0:
        return
    repay = min(agent.owner_loan, max(0, agent.cash - payroll * 2))
    if repay > 0:
        owner_loan_before = float(agent.owner_loan)
        _trace_cash_write = _trace_public_begin(None, agent)
        agent.cash -= repay
        _trace_public_finish(_trace_cash_write, 'region_finance:repay_owner_loan',
                             inputs={"source_writer": 'region_finance.py:repay_owner_loan:f27a3166006d4aa7:1'})
        settlement = credit_owner_pay(region, owner, repay)
        agent.owner_loan -= repay
        _record_owner_payment(
            region, 'owner_loan_repayment', agent, owner, repay, settlement,
            t=t, owner_loan_before=owner_loan_before,
            owner_loan_after=agent.owner_loan)


def pay_base_salary(region, agent, owner, payroll, t=None):
    """Pay owner's executive base salary if cash reserve allows."""
    if agent.cash > payroll * 2 + agent.wage:
        _trace_cash_write = _trace_public_begin(None, agent)
        agent.cash -= agent.wage
        _trace_public_finish(_trace_cash_write, 'region_finance:pay_base_salary',
                             inputs={"source_writer": 'region_finance.py:pay_base_salary:61aad4fb00bfbab7:1'})
        settlement = credit_owner_pay(region, owner, agent.wage)
        _record_owner_payment(region, 'owner_salary', agent, owner, agent.wage,
                              settlement, t=t)


def pay_profit_share(region, agent, owner, payroll, t=None):
    """Distribute retained earnings / profit dividends to the owner."""
    if agent.retained_earnings <= 0 or agent.cash <= payroll * 2:
        return
    operating_expenses = payroll * 2
    ratio = agent.retained_earnings / operating_expenses
    share_rate = 0.25 * ratio / (ratio + 5)
    profit_draw = min(share_rate * agent.retained_earnings, max(0, agent.cash - payroll * 2))
    if profit_draw > 0:
        _trace_cash_write = _trace_public_begin(None, agent)
        agent.cash -= profit_draw
        _trace_public_finish(_trace_cash_write, 'region_finance:pay_profit_share',
                             inputs={"source_writer": 'region_finance.py:pay_profit_share:0801a602f78d43e0:1'})
        settlement = credit_owner_pay(region, owner, profit_draw)
        agent.retained_earnings -= profit_draw
        _record_owner_payment(region, 'dividend', agent, owner, profit_draw,
                              settlement, t=t)
        try:
            from economy.true_cost_ledger import get_true_cost_ledger
            get_true_cost_ledger().record_finance_deductions(
                agent, region, getattr(region, '_last_turn', 0), dividend_paid=profit_draw
            )
        except Exception:
            pass


def bailout_owner(region, agent, owner, payroll, t=None):
    """Owner injects cash into the firm to cover payroll shortfall."""
    if agent.cash >= payroll:
        return
    food_price = region.food_price
    if getattr(owner, '_bank_ref', None) is region.bank:
        avail = max(0.0, owner.cash - food_price * 4)
        inject = min(payroll - agent.cash, avail)
        if inject > 0:
            source_before = float(owner.cash)
            firm_cash_before = float(agent.cash)
            owner_loan_before = float(agent.owner_loan)
            _trace_cash_write = _trace_public_begin(None, owner)
            owner.cash -= inject
            _trace_public_finish(_trace_cash_write, 'region_finance:bailout_owner',
                                 inputs={"source_writer": 'region_finance.py:bailout_owner:94eaa84947694b23:1'})
            _trace_cash_write = _trace_public_begin(None, agent)
            agent.cash += inject
            _trace_public_finish(_trace_cash_write, 'region_finance:bailout_owner',
                                 inputs={"source_writer": 'region_finance.py:bailout_owner:cf149883c274348d:1'})
            agent.owner_loan += inject
            _record_owner_funding(
                region, owner, agent, inject, 'cash',
                getattr(region, 'home_currency', None),
                source_before, owner.cash, firm_cash_before, agent.cash,
                owner_loan_before, agent.owner_loan, t)
    else:
        if region.home_currency:
            avail = _fx.fx_balance(owner, region.home_currency)
            inject = min(payroll - agent.cash, max(0.0, avail))
            if inject > 0:
                source_before = float(avail)
                firm_cash_before = float(agent.cash)
                owner_loan_before = float(agent.owner_loan)
                _fx.fx_add(owner, region.home_currency, -inject)
                _trace_cash_write = _trace_public_begin(None, agent)
                agent.cash += inject
                _trace_public_finish(_trace_cash_write, 'region_finance:bailout_owner',
                                     inputs={"source_writer": 'region_finance.py:bailout_owner:8153274f226dc6d8:1'})
                agent.owner_loan += inject
                _record_owner_funding(
                    region, owner, agent, inject, 'wallet', region.home_currency,
                    source_before, _fx.fx_balance(owner, region.home_currency),
                    firm_cash_before, agent.cash, owner_loan_before,
                    agent.owner_loan, t)


def distribute_profits(region, t):
    """Distribute firm profits to owners, service owner loans, or execute bailouts."""
    for a in region.agents:
        if not a.is_corporation or not a.alive:
            continue
        if a.owner is None or not a.owner.alive:
            continue
        owner = a.owner
        payroll = max(1, len(a.employees) * a.wage)
        repay_owner_loan(region, a, owner, payroll, t=t)
        profit = max(0, a._delta_cash + a._delta_deposits)
        if profit > 0 or a.cash > payroll * 2:
            a.retained_earnings += profit
        pay_base_salary(region, a, owner, payroll, t=t)
        pay_profit_share(region, a, owner, payroll, t=t)
        bailout_owner(region, a, owner, payroll, t=t)


def collect_tax(region, t):
    """Budget-balanced taxation with deficit financing."""
    if getattr(region, 'province', None) is not None \
            and not getattr(region, '_seat_gov_agent', True):
        return
    gov = region.gov.agent
    bank = region.bank
    food_price = region.food_price

    # ---- 1. Service existing government debt ----
    debt_service_trace_ids = []
    for loan in gov.loans[:]:
        remaining = loan.principle - loan.principle_paid
        if remaining <= 0:
            gov.loans.remove(loan)
            if loan in bank.loans:
                bank.loans.remove(loan)
            continue
        amount_due = remaining + loan.getInterest()
        available = gov.cash + bank.deposits.get(gov, 0)
        payment = min(amount_due, available)
        if payment > 0:
            if gov.cash < payment:
                bank.Withdraw(gov, payment - gov.cash, trace_region=region, t=t,
                              reason='government_debt_service')
            public_change = begin_public_change(region, gov, cash=True)
            gov.cash -= payment
            debt_service_write_ids = finish_public_change(
                public_change, 'fiscal_debt_service',
                inputs={'amount': payment, 'loan_principal_remaining_before': remaining})
            loan.pay(payment)
            from economy.actor_accounts import record as record_economic_event
            record_economic_event(region, 'bank_loan_repayment', turn=t,
                                  payer_id=gov.id, amount=payment,
                                  detail={'public_debt_service': True,
                                          'principal_remaining_before': remaining})
            service_id = _trace_treasury_flow(
                region, 'government_loan_service', -payment,
                {'loan_principal_remaining_before': remaining,
                 'amount_due': amount_due},
                cause_event_ids=debt_service_write_ids)
            if service_id is not None:
                debt_service_trace_ids.append(service_id)
        if loan.isPaid():
            gov.loans.remove(loan)
            if loan in bank.loans:
                bank.loans.remove(loan)

    # ---- 2. Compute deficit against target reserve ----
    loans_outstanding = sum(l.principle - l.principle_paid for l in gov.loans)
    net_worth = (gov.cash + bank.deposits.get(gov, 0)
                 + region.gov.food_inventory * food_price - loans_outstanding)
    reserve = region.gov.target_food_reserve * food_price * 2
    deficit = max(0.0, reserve - net_worth)
    from run_trace import emit
    budget_trace_id = emit(
        region, kind='government_reserve_deficit_calculation',
        record_class='calculation', phase='finance',
        subject={'type': 'tile', 'id': region.name},
        metric_id='finance.fiscal_deficit',
        unit=getattr(region, 'home_currency', None) or 'local_currency',
        after=deficit, formula_id='fiscal.reserve_deficit.v1',
        inputs={'government': region.gov.name, 'turn': int(t),
                'cash_after_debt_service': float(gov.cash),
                'deposits_after_debt_service': float(bank.deposits.get(gov, 0)),
                'food_inventory': float(region.gov.food_inventory),
                'food_price': float(food_price),
                'loans_outstanding': float(loans_outstanding),
                'target_food_reserve': float(region.gov.target_food_reserve),
                'reserve_multiplier': 2.0, 'net_worth': float(net_worth),
                'target_cash_reserve': float(reserve),
                'sample_point': 'after debt service, before income tax and borrowing'},
        cause_event_ids=debt_service_trace_ids or None)

    # ---- 3. Tax top 10% just enough to cover the deficit ----
    tax_collected = 0.0
    turn_nat_tax = 0.0
    turn_prov_tax = 0.0
    turn_tile_tax = 0.0
    top_count = 0
    tax_bill_evidence = []
    tax_receipts = []
    wealth_ranking = []
    living_count = None
    total_taxable = 0.0
    effective_rate = None
    assessment_reason = 'no_reserve_deficit'
    if deficit > 0:
        living = [a for a in region.agents if a.alive]
        living_count = len(living)
        assessment_reason = 'population_at_most_ten'
        if len(living) > 10:
            observed_wealth = {}

            def tax_rank_wealth(agent):
                wealth = agent.wealth()
                observed_wealth[agent.id] = float(wealth)
                return wealth

            sorted_agents = sorted(living, key=tax_rank_wealth, reverse=True)
            wealth_ranking = [{'agent_id': agent.id,
                               'wealth': observed_wealth[agent.id]}
                              for agent in sorted_agents]
            top_count = max(1, int(len(sorted_agents) * 0.1))
            top = sorted_agents[:top_count]
            tax_bills = []
            assessment_reason = 'no_positive_tax_base'
            for a in top:
                net_income = a._delta_cash + a._delta_deposits
                taxable = max(0.0, net_income + a.tax_loss_carryforward)
                child_deduction = 0.0
                if hasattr(region.gov, 'compute_child_tax_deduction'):
                    child_deduction = region.gov.compute_child_tax_deduction(a)
                    taxable = max(0.0, taxable - child_deduction)
                bill = {'agent_id': a.id, 'net_income': float(net_income),
                        'loss_carryforward_before': float(a.tax_loss_carryforward),
                        'child_deduction': float(child_deduction),
                        'taxable_income': float(taxable), 'amount_paid': 0.0,
                        'cash_before_payment': None, 'deposit_before_payment': None,
                        'payment_status': 'no_positive_total_tax_base'}
                tax_bill_evidence.append(bill)
                tax_bills.append((a, taxable, net_income, bill))
                total_taxable += taxable
            if total_taxable > 0:
                effective_rate = min(region.gov.tax_rate, deficit / total_taxable)
                assessment_reason = 'income_tax_assessed'
                for a, taxable, net_income, bill in tax_bills:
                    if taxable <= 0:
                        a.tax_loss_carryforward += net_income
                        bill.update(loss_carryforward_after=float(a.tax_loss_carryforward),
                                    payment_status='no_positive_tax_base')
                        continue
                    tax_amount = taxable * effective_rate
                    bank_balance = bank.deposits.get(a, 0)
                    bill.update(cash_before_payment=float(a.cash),
                                deposit_before_payment=float(bank_balance),
                                assessed_amount=float(tax_amount))
                    actual = min(tax_amount, a.cash + bank_balance)
                    payer_public_write_ids = []
                    if actual > 0:
                        cash_taken = min(a.cash, actual)
                        public_change=begin_public_change(region,a,cash=True)
                        a.cash -= cash_taken
                        payer_public_write_ids.extend(finish_public_change(
                            public_change, 'public_taxpayer_cash_debit',
                            inputs={'assessed_amount': tax_amount,
                                    'paid_cash': cash_taken}))
                        deposit_taken = min(bank_balance, actual - cash_taken)
                        if deposit_taken > 0:
                            bank.Withdraw(a, deposit_taken, trace_region=region, t=t,
                                          reason='income_tax_payment')
                            public_change=begin_public_change(region,a,cash=True)
                            a.cash -= deposit_taken
                            payer_public_write_ids.extend(finish_public_change(
                                public_change,
                                'public_taxpayer_withdrawn_cash_debit',
                                inputs={'assessed_amount': tax_amount,
                                        'paid_cash': deposit_taken}))
                        try:
                            from economy.true_cost_ledger import get_true_cost_ledger
                            get_true_cost_ledger().record_finance_deductions(
                                a, region, t, taxes_paid=actual
                            )
                        except Exception:
                            pass
                    a.tax_loss_carryforward = 0.0
                    bill.update(amount_paid=float(actual),
                                cash_after_debit=float(a.cash),
                                deposit_after_debit=float(bank.deposits.get(a, 0)),
                                loss_carryforward_after=float(a.tax_loss_carryforward),
                                payment_status=('paid' if actual >= tax_amount else
                                                'limited_by_cash_and_deposits'))

                    # Multi-Tier Statutory Split: 50% National Sovereign, 30% Provincial, 20% Municipal
                    owner_nation = getattr(region, 'owner_nation', None)
                    province = getattr(region, 'province', None)
                    nat_gov = getattr(owner_nation, 'government', None) if owner_nation else None
                    prov_gov = getattr(province, 'gov', None) if province else None
                    tile_gov = region.gov
                    nat_share = prov_share = tile_share = 0.0
                    public_write_event_ids = []

                    if nat_gov is not None and nat_gov is not tile_gov:
                        if prov_gov is not None and prov_gov is not tile_gov and prov_gov is not nat_gov:
                            split_rule = 'national_50_provincial_30_municipal_residual'
                            nat_share = round(actual * 0.50, 6)
                            prov_share = round(actual * 0.30, 6)
                            tile_share = actual - nat_share - prov_share

                            public_change = begin_public_change(region, nat_gov.agent, cash=True)
                            nat_gov.agent.cash += nat_share
                            public_write_event_ids.extend(finish_public_change(
                                public_change, 'national_income_tax_receipt',
                                inputs={'payer_id': a.id, 'amount': nat_share,
                                        'tax_tier': 'national'}))
                            nat_gov.record_income(t, 'tax', nat_share)

                            public_change = begin_public_change(region, prov_gov.agent, cash=True)
                            prov_gov.agent.cash += prov_share
                            public_write_event_ids.extend(finish_public_change(
                                public_change, 'provincial_income_tax_receipt',
                                inputs={'payer_id': a.id, 'amount': prov_share,
                                        'tax_tier': 'provincial'}))
                            prov_gov.record_income(t, 'tax', prov_share)

                            public_change = begin_public_change(region, tile_gov.agent, cash=True)
                            tile_gov.agent.cash += tile_share
                            public_write_event_ids.extend(finish_public_change(
                                public_change, 'local_income_tax_receipt',
                                inputs={'payer_id': a.id, 'amount': tile_share,
                                        'tax_tier': 'municipal'}))
                            tile_gov.record_income(t, 'tax', tile_share)

                            turn_nat_tax += nat_share
                            turn_prov_tax += prov_share
                            turn_tile_tax += tile_share
                        else:
                            # 2-Tier: 50% National, 50% Local/Provincial
                            split_rule = 'national_50_municipal_residual'
                            nat_share = round(actual * 0.50, 6)
                            tile_share = actual - nat_share

                            public_change = begin_public_change(region, nat_gov.agent, cash=True)
                            nat_gov.agent.cash += nat_share
                            public_write_event_ids.extend(finish_public_change(
                                public_change, 'national_income_tax_receipt',
                                inputs={'payer_id': a.id, 'amount': nat_share,
                                        'tax_tier': 'national'}))
                            nat_gov.record_income(t, 'tax', nat_share)

                            public_change = begin_public_change(region, tile_gov.agent, cash=True)
                            tile_gov.agent.cash += tile_share
                            public_write_event_ids.extend(finish_public_change(
                                public_change, 'local_income_tax_receipt',
                                inputs={'payer_id': a.id, 'amount': tile_share,
                                        'tax_tier': 'municipal'}))
                            tile_gov.record_income(t, 'tax', tile_share)

                            turn_nat_tax += nat_share
                            turn_tile_tax += tile_share
                    else:
                        # Single-Tier / Independent
                        split_rule = 'municipal_only'
                        tile_share = actual
                        public_change = begin_public_change(region, tile_gov.agent, cash=True)
                        tile_gov.agent.cash += actual
                        public_write_event_ids.extend(finish_public_change(
                            public_change, 'local_income_tax_receipt',
                            inputs={'payer_id': a.id, 'amount': actual,
                                    'tax_tier': 'municipal'}))
                        tile_gov.record_income(t, 'tax', actual)
                        turn_tile_tax += actual

                    from finance_trace import emit_public_account_flow
                    emit_public_account_flow(
                        region, a, kind='government_income_tax_payment',
                        signed_amount=-actual,
                        inputs={'tax_turn': int(t), 'assessed_amount': tax_amount,
                                'paid_amount': actual,
                                'tax_recipient_split': split_rule},
                        cause_event_ids=payer_public_write_ids or None)

                    allocations = {'national': float(nat_share),
                                   'provincial': float(prov_share),
                                   'municipal': float(tile_share)}
                    bill.update(split_rule=split_rule, allocations=allocations)
                    tax_receipts.append({
                        'payer_id': a.id, 'amount': float(actual),
                        'allocations': allocations, 'split_rule': split_rule,
                        'public_write_event_ids': public_write_event_ids,
                        'recipient_governments': {
                            tier: getattr(treasury, 'name', None) for tier, treasury in
                            (('national', nat_gov), ('provincial', prov_gov),
                             ('municipal', tile_gov))}})

                    from economy.actor_accounts import record as record_economic_event
                    for treasury, share in ((nat_gov, nat_share), (prov_gov, prov_share),
                                            (tile_gov, tile_share)):
                        if treasury is not None and share > 0:
                            record_economic_event(region, 'tax', turn=t, payer_id=a.id,
                                                  recipient_id=treasury.agent.id,
                                                  amount=share,
                                                  detail={'tax_base': taxable})

                    tax_collected += actual

    assessment_trace_id = emit(
        region, kind='income_tax_assessment_calculation',
        record_class='calculation', phase='finance',
        subject={'type': 'tile', 'id': region.name},
        metric_id='finance.tax_assessment',
        unit=getattr(region, 'home_currency', None) or 'local_currency',
        after=tax_collected, formula_id='fiscal.income_tax_assessment.v1',
        inputs={'turn': int(t), 'government': region.gov.name,
                'reason': assessment_reason, 'reserve_deficit': float(deficit),
                'statutory_tax_rate': float(region.gov.tax_rate),
                'eligible_living_count': living_count, 'minimum_population_exclusive': 10,
                'eligibility_rule': 'all living agents, including institutions and corporations',
                'wealth_ranking': wealth_ranking, 'top_population_fraction': 0.1,
                'selected_count': top_count, 'bills': tax_bill_evidence,
                'total_taxable_income': float(total_taxable),
                'effective_rate': effective_rate,
                'ranking_tie_rule': 'stable input-agent order'},
        cause_event_ids=([budget_trace_id] if budget_trace_id else None))
    if not hasattr(region, 'tax_distribution_log'):
        region.tax_distribution_log = []
    region.tax_distribution_log.append({
        'total': tax_collected,
        'municipal': turn_tile_tax,
        'provincial': turn_prov_tax,
        'national': turn_nat_tax,
    })
    tax_trace_id = _trace_treasury_flow(region, 'income_tax_collected', tax_collected,
                         {'municipal': turn_tile_tax, 'provincial': turn_prov_tax,
                          'national': turn_nat_tax, 'tax_rate': region.gov.tax_rate,
                          'deficit_before_tax': deficit, 'taxpayer_count': top_count},
                         cause_event_ids=([assessment_trace_id]
                                          if assessment_trace_id else None))
    from finance_trace import emit_tax_distribution
    emit_tax_distribution(
        region, turn=t, closing=region.tax_distribution_log[-1],
        receipts=tax_receipts, reason='income_tax_new_turn_total',
        cause_event_ids=[event_id for event_id in (assessment_trace_id, tax_trace_id)
                         if event_id is not None])

    # ---- 4. If still short, borrow from the bank ----
    gap = max(0.0, deficit - tax_collected)
    previous_gap = region.gov.borrow_log[-1] if region.gov.borrow_log else None
    region.gov.borrow_log.append(gap)
    gap_trace_id = emit(
        region, kind='government_remaining_financing_gap',
        record_class='calculation', phase='finance',
        subject={'type': 'tile', 'id': region.name},
        metric_id='finance.fiscal_gap',
        unit=getattr(region, 'home_currency', None) or 'local_currency',
        before=previous_gap, after=gap,
        formula_id='fiscal.remaining_tax_gap.v1',
        inputs={'government': region.gov.name, 'turn': int(t),
                'reserve_deficit': float(deficit),
                'tax_collected': float(tax_collected),
                'borrow_request_threshold': 0.01,
                'borrowing_requested': bool(gap > 0.01),
                'meaning': 'requested financing need before bank approval'},
        cause_event_ids=[event_id for event_id in (budget_trace_id, assessment_trace_id,
                                                  tax_trace_id)
                         if event_id is not None] or None)
    if gap > 0.01:
        before_liab = bank.total_liabilities
        bank.Borrow(t, gov, gap, trace_region=region, trace_treasury=False)
        borrowed = bank.total_liabilities - before_liab
        _trace_treasury_flow(region, 'government_bank_borrowing', borrowed,
                             {'requested_gap': gap, 'bank_liabilities_before': before_liab,
                              'bank_liabilities_after': bank.total_liabilities},
                             cause_event_ids=([gap_trace_id] if gap_trace_id else None))
        if borrowed > 0:
            loginfo(t, f"Government({region.gov.name}) borrowed ${borrowed:.2f} "
                    f"to cover deficit (gap ${gap:.2f})")
        else:
            logwarning(t, f"Government({region.gov.name}) could not borrow "
                          f"${gap:.2f} (bank capacity exhausted)")

    # ---- 5. Re-evaluate tax rate every interval ----
    tax_rate_before = region.gov.tax_rate
    interval_due = t % region.gov.tax_adjust_interval == 0
    history_ready = len(region.gov.borrow_log) >= region.gov.tax_adjust_interval
    recent_gaps = []
    avg_gap = None
    new_rate = tax_rate_before
    rate_reason = 'interval_not_due' if not interval_due else 'insufficient_gap_history'
    if interval_due and history_ready:
        recent_gaps = region.gov.borrow_log[-region.gov.tax_adjust_interval:]
        avg_gap = sum(recent_gaps) / len(recent_gaps)
        if avg_gap > reserve * 0.1:
            new_rate = region.gov.tax_rate * 1.5
            rate_reason = 'persistent_financing_gap'
        elif avg_gap == 0 and net_worth > reserve * 2:
            new_rate = region.gov.tax_rate * 0.7
            rate_reason = 'zero_gap_and_large_reserve_surplus'
        else:
            new_rate = region.gov.tax_rate
            rate_reason = 'within_fiscal_band'
        region.gov.tax_rate = max(0.05, min(0.75, new_rate))
        region.gov.tax_rate_log.append((t, region.gov.tax_rate))
        print(f"  Region '{region.name}' fiscal: gov_net=${net_worth:.0f}, "
              f"reserve=${reserve:.0f}, avg_gap=${avg_gap:.2f}, "
              f"tax_rate={region.gov.tax_rate:.2f}")

    emit(region, kind='government_tax_rate_decision',
         record_class='calculation', phase='finance',
         subject={'type': 'tile', 'id': region.name},
         metric_id='finance.tax_rate', unit='ratio',
         before=tax_rate_before, after=region.gov.tax_rate,
         formula_id='fiscal.tax_rate_adjustment.v1',
         inputs={'government': region.gov.name, 'turn': int(t),
                 'prior_tax_rate': float(tax_rate_before),
                 'adjust_interval': int(region.gov.tax_adjust_interval),
                 'borrow_history_count': len(region.gov.borrow_log),
                 'interval_due': bool(interval_due),
                 'history_ready': bool(history_ready),
                 'recent_requested_gaps': list(recent_gaps),
                 'mean_requested_gap': avg_gap,
                 'target_cash_reserve': float(reserve),
                 'net_worth_before_tax_and_borrowing': float(net_worth),
                 'gap_threshold_fraction': 0.1, 'surplus_reserve_multiplier': 2.0,
                 'increase_multiplier': 1.5, 'decrease_multiplier': 0.7,
                 'unclamped_rate': float(new_rate),
                 'rate_floor': 0.05, 'rate_ceiling': 0.75,
                 'clamp_applied': bool(interval_due and history_ready),
                 'reason': rate_reason},
         cause_event_ids=[event_id for event_id in (budget_trace_id, gap_trace_id)
                          if event_id is not None] or None)

    if tax_collected > 0 and t % 50 == 0:
        print(f"  Region '{region.name}' TAX: ${tax_collected:.2f} from top "
              f"{top_count}, gov=${region.gov.agent.cash:.2f}, "
              f"debt=${loans_outstanding:.2f}")


def recalculate_multipliers(region):
    """Update consumption multipliers based on agent wealth vs cost of living."""
    cost_of_living = region.cost_of_living
    for a in region.agents:
        if not a.alive or a.is_corporation:
            continue
        wealth = a.wealth()
        a.consumption_multiplier = max(1.0, min(10.0, math.sqrt(wealth / cost_of_living))) if wealth > cost_of_living else 1.0
