"""
Factions, grievances, and unrest metrics for a Region.
"""

import math

from goods import Goods
from faction import Faction


def build_identity_factions(region):
    """Create one faction per M1 identity tag kind (ethnicity, religion, politics)."""
    from agent import _ETHNICITIES, _RELIGIONS, _POLITICS
    for pool in (_ETHNICITIES, _RELIGIONS, _POLITICS):
        for tag in pool:
            kind = ('ethnicity' if pool is _ETHNICITIES
                    else 'religion' if pool is _RELIGIONS
                    else 'political')
            f = Faction(tag.capitalize(), kind)
            if kind == 'ethnicity':
                f.add_demand('native_rights', weight=1.2)
            else:
                f.add_demand('welfare', weight=1.0)
                f.add_demand('tax_cut', weight=0.8)
                f.add_demand('tariff', weight=0.6)
                if kind == 'political':
                    f.add_demand('immigration', weight=0.9)
            region.factions.register(f)

    # Class factions (P1.4)
    class_factions = [
        ('Gentry', [('tax_cut', 1.2), ('enclosure', 1.5), ('wage_cap', 1.3)]),
        ('Peasantry', [('welfare', 1.0), ('commons_protection', 1.5)]),
        ('Proletariat', [('welfare', 1.2), ('wage_subsidy', 1.0), ('free_labor', 1.3)]),
        ('Bourgeoisie', [('tariff', 0.8), ('tax_cut', 1.0), ('wage_cap', 0.8)]),
    ]
    for cname, demands in class_factions:
        cf = Faction(cname, 'class')
        for dname, dweight in demands:
            cf.add_demand(dname, weight=dweight)
        region.factions.register(cf)


def refresh_faction_membership(region):
    """Overwrite each identity faction's membership from live agent identity tags and social class."""
    for f in region.factions.factions.values():
        f.membership = set()
    for a in region.agents:
        if not getattr(a, 'alive', True):
            continue
        for attr, kind in (('ethnicity', 'ethnicity'),
                           ('religion', 'religion'),
                           ('politics', 'political')):
            tag = getattr(a, attr, None)
            if tag is None:
                continue
            f = region.factions.get(tag.capitalize())
            if f is not None:
                f.membership.add(a.id)

        # Class faction mapping
        sclass = getattr(a, 'social_class', None)
        if sclass in ('lord', 'landlord'):
            cf = region.factions.get('Gentry')
            if cf: cf.membership.add(a.id)
        elif sclass in ('serf', 'tenant'):
            cf = region.factions.get('Peasantry')
            if cf: cf.membership.add(a.id)
        elif sclass in ('proletarian', 'dispossessed'):
            cf = region.factions.get('Proletariat')
            if cf: cf.membership.add(a.id)
        elif sclass in ('industrialist', 'petty_bourgeois'):
            cf = region.factions.get('Bourgeoisie')
            if cf: cf.membership.add(a.id)


def apply_policy_satisfaction(region, *, evidence=None):
    """Map the tile government's existing policy knobs and land tenure to faction demand satisfaction."""
    gov = region.gov
    tax_sat = max(0.0, min(1.0, 1.0 - gov.tax_rate / 0.75))
    welfare_sat = 1.0 if getattr(gov, 'ubi_enabled', False) else 0.35
    tariff_sat = max(0.0, min(1.0, gov.import_tariff_rate / 0.15))
    imm_sat = 1.0 if getattr(gov, 'immigration_enabled', False) else 0.2
    native_sat = 0.3

    # Land tenure satisfaction (P1.4)
    commons = region.tenure.commons_access if getattr(region, 'tenure', None) else 1.0
    enclosure_sat = 1.0 - commons
    commons_sat = commons

    # Labor & wage policy satisfaction
    statute_active = getattr(region, 'statute_of_laborers', False)
    wage_cap_sat = 1.0 if statute_active else 0.2
    free_labor_sat = 0.1 if statute_active else 1.0

    for f in region.factions.factions.values():
        for d in f.demands:
            if d.name == 'tax_cut':
                d.satisfied = tax_sat
            elif d.name == 'welfare':
                d.satisfied = welfare_sat
            elif d.name == 'tariff':
                d.satisfied = tariff_sat
            elif d.name == 'immigration':
                d.satisfied = imm_sat
            elif d.name == 'enclosure':
                d.satisfied = enclosure_sat
            elif d.name == 'commons_protection':
                d.satisfied = commons_sat
            elif d.name == 'wage_subsidy':
                d.satisfied = welfare_sat
            elif d.name == 'native_rights':
                d.satisfied = native_sat
            elif d.name == 'wage_cap':
                d.satisfied = wage_cap_sat
            elif d.name == 'free_labor':
                d.satisfied = free_labor_sat
            if d.name in getattr(region, 'compromise_concessions', ()):
                d.satisfied = max(d.satisfied, 0.85)
    if evidence is not None:
        evidence.update(
            tax_rate=gov.tax_rate, tax_cut_satisfaction=tax_sat,
            welfare_satisfaction=welfare_sat, tariff_satisfaction=tariff_sat,
            immigration_satisfaction=imm_sat, native_rights_satisfaction=native_sat,
            commons_access=commons, enclosure_satisfaction=enclosure_sat,
            commons_protection_satisfaction=commons_sat,
            statute_active=bool(statute_active), wage_cap_satisfaction=wage_cap_sat,
            free_labor_satisfaction=free_labor_sat,
            compromise_concessions=sorted(getattr(region, 'compromise_concessions', ())))


def accumulate_grievances(region, t):
    """Add per-turn grievance sources to each faction (M2.3)."""
    agents = region.agents
    adds = {}
    if not agents:
        return adds
    grievance_scale = float(getattr(region, 'scenario_grievance_scale', 1.0))
    prior_grievances = ({f.name: dict(f.grievances) for f in region.factions.factions.values()}
                        if grievance_scale != 1.0 else {})
    # hunger
    from nutrition import deficit_fraction
    hungry_now = sum(deficit_fraction(a) for a in agents
                     if not a.is_corporation and not a.is_government)
    mem_hunger = sum(a.mem_avg('mem_hunger', 0.0)
                     for a in agents
                     if not a.is_corporation and not a.is_government)
    hunger_pressure = hungry_now / 30.0 + mem_hunger / 120.0
    hunger_score = 3.0 * (1.0 - math.exp(-hunger_pressure / 3.0))
    # repression memory
    trauma = sum(a.mem_avg('mem_casualties', 0.0)
                 + a.mem_avg('mem_promises', 0.0)
                 for a in agents
                 if not a.is_corporation and not a.is_government)
    trauma_score = min(2.0, trauma / 60.0)
    # gini
    gini = 0.0
    for g in (Goods.food, Goods.wood, Goods.furniture):
        vals = sorted(a.cash for a in agents if a.output == g)
        if len(vals) > 5:
            n = len(vals)
            s = sum(vals)
            if s > 0:
                wsum = sum((i + 1) * v for i, v in enumerate(vals))
                gini = max(gini, (2 * wsum) / (n * s) - (n + 1) / n)
    # tax (effective)
    tax = region.gov.tax_rate
    levy_units = float(getattr(region, 'emergency_grain_levy_units', 0.0))
    levy_score = min(3.0, 2.0 * levy_units / max(1, len(agents)))
    # unemployment
    adults = [a for a in agents
              if not a.is_corporation and not a.is_government
              and (a.birth_round == 0 or a.age(t) > 20)]
    unemp = (sum(1 for a in adults if a.employer is None
                 and not a.is_trader) / max(1, len(adults)))

    # eviction / enclosure memory (P1)
    eviction = sum(a.mem_avg('mem_eviction', 0.0)
                   for a in agents
                   if not a.is_corporation and not a.is_government)
    eviction_score = min(2.5, eviction / 40.0)

    # labor exploitation, shift hours & casualties (P2.3)
    shifts = getattr(region, 'avg_shift_hours_log', [])
    avg_shift = shifts[-1] if shifts else 8.0
    shift_score = min(2.0, max(0.0, (avg_shift - 8.0) / 4.0))

    accidents = getattr(region, 'workplace_accidents_log', [])
    accident_count = accidents[-1] if accidents else 0
    accident_score = min(2.0, accident_count * 0.4)

    strikers_count = sum(1 for a in agents if getattr(a, 'is_striking', False))
    strike_score = min(2.5, strikers_count / 8.0)
    labor_grievance = shift_score + accident_score + strike_score

    # Wage inflation panic vs statutory wage suppression grievance
    corp_wages = [a.wage for a in agents if getattr(a, 'is_corporation', False)]
    avg_wage = sum(corp_wages) / max(1, len(corp_wages)) if corp_wages else 1.0

    statute_active = getattr(region, 'statute_of_laborers', False)
    wage_cap = getattr(region, 'maximum_wage_cap', 1.20)

    wage_panic_score = 0.0
    wage_suppression_score = 0.0

    if not statute_active:
        if avg_wage > 1.60:
            wage_panic_score = min(3.0, (avg_wage - 1.60) * 2.0)
    else:
        food_price = region.recipes.get(Goods.food, {}).get('price', 1.0)
        if food_price > wage_cap:
            wage_suppression_score = min(3.0, 1.0 + (food_price - wage_cap) * 2.0)
        else:
            wage_suppression_score = 0.8

    for f in region.factions.factions.values():
        extra_add = 0.0
        if f.name in ('Gentry', 'Bourgeoisie'):
            f.add_grievance('wage_inflation', wage_panic_score * 1.5)
            extra_add += wage_panic_score * 1.5
        elif f.name in ('Proletariat', 'Peasantry'):
            f.add_grievance('wage_suppression', wage_suppression_score * 1.5)
            extra_add += wage_suppression_score * 1.5

        if f.kind == 'political':
            n_add = (hunger_score * 0.6 + gini * 1.2
                     + tax * 1.5 + unemp * 1.5 + trauma_score + eviction_score * 1.2
                     + labor_grievance * 1.2
                     + wage_panic_score * 0.5 + wage_suppression_score * 0.8)
            f.add_grievance('hunger', hunger_score * 0.6)
            f.add_grievance('gini', gini * 1.2)
            f.add_grievance('tax', tax * 1.5)
            f.add_grievance('unemployment', unemp * 1.5)
            f.add_grievance('repression', trauma_score)
            f.add_grievance('enclosure', eviction_score * 1.2)
            f.add_grievance('labor', labor_grievance * 1.2)
            f.add_grievance('wage_inflation', wage_panic_score * 0.5)
            f.add_grievance('wage_suppression', wage_suppression_score * 0.8)
        else:
            n_add = (hunger_score + gini + tax + unemp + trauma_score
                     + eviction_score * 1.5 + labor_grievance * 1.5
                     + extra_add)
            f.add_grievance('hunger', hunger_score)
            f.add_grievance('gini', gini)
            f.add_grievance('tax', tax)
            f.add_grievance('unemployment', unemp)
            f.add_grievance('repression', trauma_score)
            f.add_grievance('enclosure', eviction_score * 1.5)
            f.add_grievance('labor', labor_grievance * 1.5)
        owner_levy = (2.0 if f.name in ('Gentry', 'Bourgeoisie') else
                      0.5 if f.name == 'Peasantry' else 0.25)
        f.add_grievance('grain_levy', levy_score * owner_levy)
        n_add += levy_score * owner_levy
        pollution = getattr(region, 'pollution_health_state', {})
        pollution_score = (5.0 * pollution.get('rate', 0.0)
                           if pollution.get('stage', 'quiet') != 'quiet' else 0.0)
        f.add_grievance('pollution_illness', pollution_score)
        n_add += pollution_score
        adds[f.name] = n_add

    if grievance_scale != 1.0:
        for faction in region.factions.factions.values():
            prior = prior_grievances[faction.name]
            for key, value in faction.grievances.items():
                faction.grievances[key] = prior.get(key, 0.0) + (value - prior.get(key, 0.0)) * grievance_scale
        adds = {key: value * grievance_scale for key, value in adds.items()}

    # Record isolated grievance breakdown for analytical comparison
    sources = {
        'pollution_illness': 5.0 * getattr(region, 'pollution_health_state', {}).get('rate', 0.0)
        if getattr(region, 'pollution_health_state', {}).get('stage', 'quiet') != 'quiet' else 0.0,
        'overworked': float(shift_score),
        'rent_enclosure': float(eviction_score * 1.5),
        'hunger': float(hunger_score),
        'labor_resistance': float(accident_score + strike_score),
        'unemployment': float(unemp),
        'tax': float(tax),
        'grain_levy': float(levy_score),
        'repression': float(trauma_score),
        'inequality': float(gini),
        'wage_inflation': float(wage_panic_score),
        'wage_suppression': float(wage_suppression_score),
    }
    if grievance_scale != 1.0:
        sources = {key: value * grievance_scale for key, value in sources.items()}
    total_g = sum(sources.values())
    pcts = {k: (v / total_g * 100.0) if total_g > 0 else 0.0 for k, v in sources.items()}
    if not hasattr(region, 'grievance_sources_log'):
        region.grievance_sources_log = []
    region.grievance_sources_log.append({
        'raw': sources,
        'pct': pcts,
        'total': total_g,
        'protest': 0.0,
    })
    from run_trace import emit
    emit(region, kind='grievance_sources', record_class='calculation',
         subject={'type': 'tile', 'id': region.name},
         metric_id='politics.grievance', unit='score', after=total_g,
         formula_id='factions.grievance_sources.v1',
         inputs={'raw_sources': sources, 'faction_additions': adds,
                 'grievance_scale': grievance_scale, 'hungry_now': hungry_now,
                 'hunger_memory': mem_hunger, 'trauma_memory': trauma,
                 'gini': gini, 'tax_rate': tax, 'unemployment_share': unemp,
                 'eviction_memory': eviction, 'average_shift_hours': avg_shift,
                 'accident_count': accident_count, 'strikers': strikers_count,
                 'average_corporate_wage': avg_wage, 'wage_statute': statute_active})

    return adds


def protest_energy(adds):
    """M2.4: per-tile protest score from the rate of fresh grievance."""
    if not adds:
        return 0.0
    avg = sum(adds.values()) / len(adds)
    score = min(10.0, avg * 2.0)
    return max(0.0, score)


def step_factions(region, t):
    """One turn of faction bookkeeping: membership, policy satisfaction, support, and grievances."""
    from faction_trace import faction_state, record_faction_histories

    trace_enabled = (getattr(region, '_run_trace', None) is not None
                     and getattr(region, '_collective_trace_clock', None) is not None)
    opening = ({name: faction_state(faction) for name, faction in region.factions.factions.items()}
               if trace_enabled else None)
    refresh_faction_membership(region)
    policy_inputs = {} if trace_enabled else None
    apply_policy_satisfaction(region, evidence=policy_inputs)
    eligible = {a.id for a in region.agents if getattr(a, 'alive', True)}
    adds = accumulate_grievances(region, t)
    prepared = ({name: faction_state(faction) for name, faction in region.factions.factions.items()}
                if trace_enabled else None)
    region.factions.step(eligible)
    snap = {name: f.support for name, f in region.factions.factions.items()}
    region.faction_support_log.append(snap)
    gv = {name: f.total_grievance() for name, f in region.factions.factions.items()}
    region.faction_grievance_log.append(gv)
    if trace_enabled:
        record_faction_histories(region, t, opening, prepared, eligible, policy_inputs)
    pe = protest_energy(adds)
    region.protest_energy_log.append(pe)
    from run_trace import emit
    emit(region, kind='protest_energy_update', record_class='calculation',
         subject={'type': 'tile', 'id': region.name},
         metric_id='politics.protest_energy', unit='score',
         before=region.protest_energy_log[-2] if len(region.protest_energy_log) > 1 else 0.0,
         after=pe, formula_id='factions.protest_energy.v1',
         inputs={'faction_additions': adds, 'average_addition':
                 sum(adds.values()) / len(adds) if adds else 0.0},
         constraints={'floor': 0.0, 'cap': 10.0})
    if region.grievance_sources_log:
        region.grievance_sources_log[-1]['protest'] = pe
