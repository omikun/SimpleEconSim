#!/usr/bin/env python3
"""
render_island_micropolys.py — Interactive CLI & Generator for High-Poly Polygonal Islands.

Allows tweaking:
- Target polygon count (e.g., 2,000, 8,000, 16,000, 32,000, 64,000+)
- Subdivision methods:
    1. 'adaptive'  : Isotropic 1-to-4 recursive subdivision prioritized by area (default)
    2. 'depth'     : Uniform 1-to-4 recursive subdivision with fixed depth (4x per depth)
    3. 'spokes'    : Radial perimeter fan subdivision along fractal noisy edges
    4. 'redblob'   : Red Blob Games 2-way fold (mountain ridges vs river valleys)
- Fractal elevation roughness
- Corner ridge elevation boost alpha (Red Blob model)
- Island seeds and point density

Usage examples:
    ./venv/bin/python3 render_island_micropolys.py --polys 16000
    ./venv/bin/python3 render_island_micropolys.py --polys 32000 --roughness 6.0
    ./venv/bin/python3 render_island_micropolys.py --mode spokes --polys 12000
    ./venv/bin/python3 render_island_micropolys.py --mode redblob --seed 42
    ./venv/bin/python3 render_island_micropolys.py --help
"""

import argparse
import math
import os
import sys
import time
from typing import List, Tuple
from collections import defaultdict
import concurrent.futures
from scipy.spatial import cKDTree

os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"

# Enable headless pygame rendering by default unless window is requested
if "--window" not in sys.argv:
    os.environ["SDL_AUDIODRIVER"] = "dummy"
    os.environ["SDL_VIDEODRIVER"] = "dummy"

import numpy as np
import pygame

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from polygon_map import PolygonMapGenerator, BIOME_COLORS


def procedural_fbm_elevation(x, y, seed=42, amplitude=1.0):
    """Continuous multi-scale procedural elevation noise to break piecewise planar ramps."""
    fx = x * 0.006 + seed * 0.17
    fy = y * 0.006 + seed * 0.23
    return amplitude * (
        (math.sin(fx * 1.0) * math.cos(fy * 1.0)) * 4.0 +
        (math.sin(fx * 2.3 + 1.2) * math.cos(fy * 2.1 - 0.7)) * 2.2 +
        (math.sin(fx * 4.7 - 2.1) * math.cos(fy * 4.9 + 1.4)) * 1.1 +
        (math.sin(fx * 9.3 + 0.5) * math.cos(fy * 9.1 - 1.9)) * 0.55
    )


def procedural_ridged_elevation(x, y, base_elevation, seed=42, amplitude=1.0, ridge_roughness=0.35):
    """
    Musgrave ridged multifractal noise with domain warping and elevation weighting.
    Computes inverted noise ridges: (1.0 - |noise|)^2, attenuated on lowlands so only
    mountain peaks and high plateaus form razor-sharp arêtes.
    """
    if ridge_roughness <= 1e-4 or base_elevation <= 0.20:
        return 0.0

    # Domain warping to give organic geological strata folds
    warp_x = math.sin(x * 0.004 + seed * 0.31) * 12.0
    warp_y = math.cos(y * 0.004 + seed * 0.47) * 12.0
    wx = x + warp_x
    wy = y + warp_y

    fx = wx * 0.008 + seed * 0.13
    fy = wy * 0.008 + seed * 0.29

    # Multi-octave ridged noise accumulation: (1 - |noise|)^2
    n1 = 1.0 - abs(math.sin(fx * 1.0) * math.cos(fy * 1.0))
    n2 = 1.0 - abs(math.sin(fx * 2.1 + 0.9) * math.cos(fy * 2.3 - 0.5))
    n3 = 1.0 - abs(math.sin(fx * 4.4 - 1.7) * math.cos(fy * 4.2 + 1.1))
    n4 = 1.0 - abs(math.sin(fx * 8.9 + 0.4) * math.cos(fy * 8.7 - 1.3))

    ridged = (n1 * n1 * 4.0 + n2 * n2 * 2.2 + n3 * n3 * 1.2 + n4 * n4 * 0.6) - 3.2

    # Attenuation factor: 0 on lowlands/coast, ramp up nonlinearly on mountain peaks
    crag_weight = max(0.0, (base_elevation - 0.25) / 0.75) ** 1.35
    return amplitude * ridge_roughness * ridged * crag_weight


COAST_TRANSITION_WIDTH = 32.0  # units (~1.0 - 1.2 Voronoi cell radius)

def calc_coastal_envelope(dist: float) -> float:
    """Smooth C^2 quintic Hermite coastal envelope: 0 at shoreline, 1 in interior."""
    if dist <= 0.05:
        return 0.0
    if dist >= COAST_TRANSITION_WIDTH:
        return 1.0
    t = dist / COAST_TRANSITION_WIDTH
    return (6.0 * t**2 - 15.0 * t + 10.0) * (t**3)


# Dynamic micropoly beach colors (wet sand, dry golden sand, and dune grass)
COLOR_WET_SAND = np.array([168, 152, 122], dtype=np.float64)
COLOR_GOLDEN_SAND = np.array([214, 198, 152], dtype=np.float64)
COLOR_DUNE_SAND = np.array([192, 188, 142], dtype=np.float64)


def calc_vertex_color(x: float, y: float, z: float, dist: float, base_col: np.ndarray,
                      gen_seed: int = 42, is_beach_cell: bool = False, is_river: bool = False) -> np.ndarray:
    """Calculates organic shoreline, dune, and inland biome vertex coloring."""
    if is_river:
        return base_col

    fx = x * 0.08 + gen_seed * 0.13
    fy = y * 0.08 + gen_seed * 0.27
    noise_var = (math.sin(fx) * math.cos(fy)) * 2.5 + (math.sin(fx * 2.3 + 1.1) * math.cos(fy * 2.1 - 0.7)) * 1.2

    eff_dist = max(0.0, dist + noise_var)
    eff_z = max(0.0, z + noise_var * 0.15)

    if is_beach_cell:
        max_beach_dist = 42.0
        max_beach_z = 4.2
    else:
        max_beach_dist = 22.0
        max_beach_z = 2.6

    if eff_dist < max_beach_dist and eff_z < max_beach_z:
        dist_factor = 1.0 - (eff_dist / max_beach_dist)
        z_factor = 1.0 - (eff_z / max_beach_z)
        beach_weight = min(1.0, max(0.0, dist_factor * z_factor * 1.3))
        beach_weight = beach_weight * beach_weight * (3.0 - 2.0 * beach_weight)

        if eff_z < 0.6:
            sand_col = COLOR_WET_SAND * (1.0 - eff_z / 0.6) + COLOR_GOLDEN_SAND * (eff_z / 0.6)
        elif eff_z < 1.8:
            sand_col = COLOR_GOLDEN_SAND
        else:
            t_dune = min(1.0, (eff_z - 1.8) / 0.8)
            sand_col = COLOR_GOLDEN_SAND * (1.0 - t_dune) + COLOR_DUNE_SAND * t_dune

        return base_col * (1.0 - beach_weight) + sand_col * beach_weight
    return base_col


def carve_continuous_valley_standalone(pt_x: float, pt_y: float, z_val: float, coast_dist: float,
                                      river_kdtree, dense_riv_z_arr, dense_riv_flux_arr,
                                      w_bed_base: float, w_val_base: float, canyon_depth_param: float,
                                      elev_scale: float = 70.0) -> float:
    """Continuous smooth 3D riverbed and canyon carving along river stream lines."""
    if river_kdtree is None or coast_dist <= 0.05:
        return z_val
    d_riv, r_idx = river_kdtree.query([pt_x, pt_y])
    if d_riv > w_val_base * 1.6:
        return z_val

    r_z = dense_riv_z_arr[r_idx]
    r_flux = dense_riv_flux_arr[r_idx]
    flux_w = math.sqrt(max(1.0, r_flux))
    w_bed = w_bed_base * (0.8 + 0.30 * flux_w)
    w_val = w_val_base * (0.8 + 0.30 * flux_w)

    c_factor = (0.8 + 3.0 * canyon_depth_param) * (0.8 + 0.35 * flux_w) * (elev_scale / 60.0) if canyon_depth_param > 0 else 0.0
    bed_drop = max(0.8, c_factor * 0.45) if canyon_depth_param > 0 else 0.2
    canyon_cut = c_factor

    coast_env = min(1.0, max(0.0, coast_dist / 6.0))
    z_bed = max(0.04, r_z - bed_drop * coast_env)

    if d_riv <= w_bed:
        return min(z_val, z_bed)
    if d_riv <= w_val:
        t = (d_riv - w_bed) / (w_val - w_bed)
        s = t * t * (3.0 - 2.0 * t)
        wall_h = z_bed + s * max(0.0, z_val - z_bed)
        bank_gouge = canyon_cut * (1.0 - s) * (1.0 - s) * coast_env
        z_carved = min(z_val, max(z_bed, wall_h - bank_gouge * 0.35))
        return min(z_val, z_carved)
    return z_val


def _subdivide_chunk_worker(task_data: Tuple) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Subdivides a chunk of base triangles independently across CPU worker processes.
    Uses canonical deterministic edge hashing to guarantee 100% watertight boundaries
    with zero cracks, seams, or T-junctions between worker chunk borders.
    """
    chunk_base_triangles, worker_params = task_data
    (gen_seed, target_depth, scale_x, scale_y, elev_scale, lateral_jitter, roughness, ridge_noise,
     river_kdtree, dense_riv_z_arr, dense_riv_flux_arr, w_bed_base, w_val_base, canyon_depth_param, erosion_field) = worker_params

    local_vertices = []
    local_vert_map = {}
    local_is_bnd = {}
    local_coast_dist = {}
    local_is_beach = {}
    local_base_color = {}
    local_is_patch_boundary = {}

    def get_or_add(p, is_bnd, dist, is_beach, col, is_patch_bnd=True):
        key = (round(float(p[0]), 2), round(float(p[1]), 2))
        if key in local_vert_map:
            idx = local_vert_map[key]
            if is_bnd:
                local_is_bnd[idx] = True
                local_coast_dist[idx] = 0.0
            elif dist is not None:
                local_coast_dist[idx] = min(local_coast_dist.get(idx, 999.0), dist)
            if is_beach:
                local_is_beach[idx] = True
            return idx
        idx = len(local_vertices)
        local_vertices.append(np.array(p, dtype=np.float64))
        local_vert_map[key] = idx
        local_is_bnd[idx] = is_bnd
        local_coast_dist[idx] = 0.0 if is_bnd else dist
        local_is_beach[idx] = is_beach
        local_base_color[idx] = np.array(col, dtype=np.float64)
        local_is_patch_boundary[idx] = is_patch_bnd
        return idx

    chunk_tris = []
    base_edges = set()
    for tri in chunk_base_triangles:
        (pa, pb, pc, col, avg_elev, is_riv,
         is_bnd_a, is_bnd_b, is_bnd_c,
         dist_a, dist_b, dist_c,
         beach_a, beach_b, beach_c,
         col_a, col_b, col_c) = tri

        ia = get_or_add(pa, is_bnd_a, dist_a, beach_a, col_a, is_patch_bnd=True)
        ib = get_or_add(pb, is_bnd_b, dist_b, beach_b, col_b, is_patch_bnd=True)
        ic = get_or_add(pc, is_bnd_c, dist_c, beach_c, col_c, is_patch_bnd=True)

        base_edges.add((min(ia, ib), max(ia, ib)))
        base_edges.add((min(ib, ic), max(ib, ic)))
        base_edges.add((min(ic, ia), max(ic, ia)))

        chunk_tris.append((ia, ib, ic, col, avg_elev, is_riv))

    edge_midpoints = {}

    def get_midpoint(i_a, i_b, depth, is_base_edge):
        edge_key = (min(i_a, i_b), max(i_a, i_b))
        if edge_key in edge_midpoints:
            return edge_midpoints[edge_key]

        pa = local_vertices[i_a]
        pb = local_vertices[i_b]

        qa = (round(float(pa[0]), 3), round(float(pa[1]), 3))
        qb = (round(float(pb[0]), 3), round(float(pb[1]), 3))
        k0, k1 = min(qa, qb), max(qa, qb)
        ix0, iy0 = int(round(k0[0] * 100.0)), int(round(k0[1] * 100.0))
        ix1, iy1 = int(round(k1[0] * 100.0)), int(round(k1[1] * 100.0))
        h0 = (ix0 * 73856093 ^ iy0 * 19349663) & 0xFFFFFFFF
        h1 = (ix1 * 83492791 ^ iy1 * 39916801) & 0xFFFFFFFF
        edge_seed = (h0 ^ (h1 * 31) ^ (depth * 1009) ^ gen_seed) & 0xFFFFFFFF
        edge_rng = np.random.RandomState(edge_seed)

        if qa > qb:
            p_start, p_end = pb, pa
            dist_start, dist_end = local_coast_dist.get(i_b, 999.0), local_coast_dist.get(i_a, 999.0)
        else:
            p_start, p_end = pa, pb
            dist_start, dist_end = local_coast_dist.get(i_a, 999.0), local_coast_dist.get(i_b, 999.0)

        c_xy = p_end[:2] - p_start[:2]
        length = float(np.linalg.norm(c_xy))
        mid = (pa + pb) * 0.5

        mid_dist = (dist_start + dist_end) * 0.5
        mid_env = calc_coastal_envelope(mid_dist)
        is_bnd = (local_is_bnd.get(i_a, False) and local_is_bnd.get(i_b, False)) or (mid_dist <= 0.05)
        is_beach = local_is_beach.get(i_a, False) or local_is_beach.get(i_b, False)

        if is_bnd:
            if length > 0.15:
                n_perp = np.array([-c_xy[1], c_xy[0]], dtype=np.float64) / length
                bnd_decay = 0.85 ** depth
                bnd_disp = edge_rng.uniform(-0.45, 0.45) * length * bnd_decay
                disp_long = edge_rng.uniform(-0.06, 0.06) * length * bnd_decay
                mid[0] += n_perp[0] * bnd_disp + (c_xy[0] / length) * disp_long
                mid[1] += n_perp[1] * bnd_disp + (c_xy[1] / length) * disp_long
            mid[2] = 0.0
            mid_dist = 0.0
        else:
            if length > 0.35:
                n_perp = np.array([-c_xy[1], c_xy[0]], dtype=np.float64) / length
                decay = 0.70 ** depth
                jitter_env = 0.40 + 0.60 * mid_env
                disp_lat = edge_rng.uniform(-lateral_jitter, lateral_jitter) * length * decay * jitter_env
                disp_long = edge_rng.uniform(-0.08, 0.08) * length * decay * jitter_env

                mid[0] += n_perp[0] * disp_lat + (c_xy[0] / length) * disp_long
                mid[1] += n_perp[1] * disp_lat + (c_xy[1] / length) * disp_long

                base_h = erosion_field.sample_elevation(mid[0] / scale_x, mid[1] / scale_y) * elev_scale * mid_env
                fbm_val = procedural_fbm_elevation(mid[0], mid[1], gen_seed, amplitude=elev_scale / 70.0) * (decay * 0.35) * mid_env
                mid_norm_elev = base_h / max(1.0, elev_scale)
                rdg_val = procedural_ridged_elevation(mid[0], mid[1], mid_norm_elev, gen_seed, amplitude=elev_scale / 45.0, ridge_roughness=ridge_noise) * (decay * 0.5) * mid_env
                disp_z = (edge_rng.uniform(-0.35, 0.35) * roughness * (length / 24.0) + fbm_val + rdg_val) * mid_env
                mid[2] = max(0.0, (0.70 * base_h + 0.30 * mid[2] + disp_z) * mid_env)
                mid[2] = carve_continuous_valley_standalone(mid[0], mid[1], mid[2], mid_dist, river_kdtree, dense_riv_z_arr, dense_riv_flux_arr, w_bed_base, w_val_base, canyon_depth_param, elev_scale)

        idx_mid = len(local_vertices)
        local_vertices.append(mid)
        local_is_bnd[idx_mid] = is_bnd
        local_coast_dist[idx_mid] = 0.0 if is_bnd else mid_dist
        local_is_beach[idx_mid] = is_beach or is_bnd
        local_is_patch_boundary[idx_mid] = is_base_edge

        c_a = local_base_color.get(i_a, np.array([120, 160, 100], dtype=np.float64))
        c_b = local_base_color.get(i_b, np.array([120, 160, 100], dtype=np.float64))
        if is_bnd:
            local_base_color[idx_mid] = COLOR_WET_SAND
        else:
            local_base_color[idx_mid] = (c_a + c_b) * 0.5

        edge_midpoints[edge_key] = idx_mid
        return idx_mid

    current_base_edges = set(base_edges)
    for depth in range(target_depth):
        new_triangles = []
        new_base_edges = set()
        for i_a, i_b, i_c, col, el, riv in chunk_tris:
            ab_is_base = (min(i_a, i_b), max(i_a, i_b)) in current_base_edges
            bc_is_base = (min(i_b, i_c), max(i_b, i_c)) in current_base_edges
            ca_is_base = (min(i_c, i_a), max(i_c, i_a)) in current_base_edges

            m_ab = get_midpoint(i_a, i_b, depth, ab_is_base)
            m_bc = get_midpoint(i_b, i_c, depth, bc_is_base)
            m_ca = get_midpoint(i_c, i_a, depth, ca_is_base)

            if ab_is_base:
                new_base_edges.add((min(i_a, m_ab), max(i_a, m_ab)))
                new_base_edges.add((min(m_ab, i_b), max(m_ab, i_b)))
            if bc_is_base:
                new_base_edges.add((min(i_b, m_bc), max(i_b, m_bc)))
                new_base_edges.add((min(m_bc, i_c), max(m_bc, i_c)))
            if ca_is_base:
                new_base_edges.add((min(i_c, m_ca), max(i_c, m_ca)))
                new_base_edges.add((min(m_ca, i_a), max(m_ca, i_a)))

            new_triangles.append((i_a, m_ab, m_ca, col, el, riv))
            new_triangles.append((i_b, m_bc, m_ab, col, el, riv))
            new_triangles.append((i_c, m_ca, m_bc, col, el, riv))
            new_triangles.append((m_ab, m_bc, m_ca, col, el, riv))

        chunk_tris = new_triangles
        current_base_edges = new_base_edges

        # Multi-level vertex elevation relaxation on interior vertices
        adj_map = defaultdict(set)
        for i_a, i_b, i_c, _, _, _ in chunk_tris:
            adj_map[i_a].add(i_b)
            adj_map[i_a].add(i_c)
            adj_map[i_b].add(i_a)
            adj_map[i_b].add(i_c)
            adj_map[i_c].add(i_a)
            adj_map[i_c].add(i_b)

        relax_weight = 0.20 * (0.75 ** depth)
        for v_idx in list(adj_map.keys()):
            if local_is_bnd.get(v_idx, False) or local_is_patch_boundary.get(v_idx, False):
                continue
            v_dist = local_coast_dist.get(v_idx, 999.0)
            if v_dist <= 0.05:
                local_vertices[v_idx][2] = 0.0
                continue
            v_env = calc_coastal_envelope(v_dist)
            neighbors = list(adj_map[v_idx])
            if len(neighbors) >= 3:
                neighbor_z_mean = float(np.mean([local_vertices[n][2] for n in neighbors]))
                v_rng = np.random.RandomState((v_idx * 1013 ^ depth * 31 ^ gen_seed) & 0xFFFFFFFF)
                new_z = (1.0 - relax_weight * 1.5) * local_vertices[v_idx][2] + (relax_weight * 1.5) * neighbor_z_mean
                new_z += v_rng.uniform(-0.5, 0.5) * (roughness * 0.15 * (0.65 ** depth)) * v_env
                local_vertices[v_idx][2] = max(0.0, new_z)
                local_vertices[v_idx][2] = carve_continuous_valley_standalone(
                    local_vertices[v_idx][0], local_vertices[v_idx][1], local_vertices[v_idx][2],
                    v_dist, river_kdtree, dense_riv_z_arr, dense_riv_flux_arr, w_bed_base, w_val_base, canyon_depth_param, elev_scale
                )

    num_out_tris = len(chunk_tris)
    out_coords = np.zeros((num_out_tris, 3, 3), dtype=np.float64)
    out_cols = np.zeros((num_out_tris, 3), dtype=np.float64)
    out_elevs = np.zeros(num_out_tris, dtype=np.float64)
    out_is_rivs = np.zeros(num_out_tris, dtype=bool)

    for tri_idx, (i_a, i_b, i_c, col_base, avg_elev, is_riv) in enumerate(chunk_tris):
        pa = local_vertices[i_a]
        pb = local_vertices[i_b]
        pc = local_vertices[i_c]

        # Enforce consistent counter-clockwise orientation
        if (pb[0] - pa[0]) * (pc[1] - pa[1]) - (pb[1] - pa[1]) * (pc[0] - pa[0]) < 0.0:
            pb, pc = pc, pb

        tri_mid_x = (pa[0] + pb[0] + pc[0]) / 3.0
        tri_mid_y = (pa[1] + pb[1] + pc[1]) / 3.0
        tri_mid_z = (pa[2] + pb[2] + pc[2]) / 3.0
        tri_dist = (local_coast_dist.get(i_a, 999.0) + local_coast_dist.get(i_b, 999.0) + local_coast_dist.get(i_c, 999.0)) / 3.0
        tri_is_beach = local_is_beach.get(i_a, False) or local_is_beach.get(i_b, False) or local_is_beach.get(i_c, False)

        tri_is_riv = is_riv
        if river_kdtree is not None:
            d_riv_mid, _ = river_kdtree.query([tri_mid_x, tri_mid_y])
            if d_riv_mid <= w_bed_base * 1.3:
                tri_is_riv = True

        base_c = (local_base_color.get(i_a, col_base) + local_base_color.get(i_b, col_base) + local_base_color.get(i_c, col_base)) / 3.0
        tri_col = calc_vertex_color(tri_mid_x, tri_mid_y, tri_mid_z, tri_dist, base_c, gen_seed, is_beach_cell=tri_is_beach, is_river=tri_is_riv)

        out_coords[tri_idx, 0] = pa
        out_coords[tri_idx, 1] = pb
        out_coords[tri_idx, 2] = pc
        out_cols[tri_idx] = tri_col
        out_elevs[tri_idx] = avg_elev
        out_is_rivs[tri_idx] = tri_is_riv

    return (out_coords, out_cols, out_elevs, out_is_rivs)



def build_detailed_river_streams(gen, scale_x: float, scale_y: float, elev_scale: float, substeps: int = 6) -> List[List[List[float]]]:
    """
    Computes organic, fractal downhill river paths following the natural valleys
    formed by polygon cell boundaries (NoisyEdges).
    Guarantees:
    - Every river stream flows naturally through the lowest valley paths between cell peaks.
    - Tributaries fuse cleanly into receiving mainstems at confluences with zero duplicate edges.
    - Water elevations are strictly monotonic downhill with ocean coast tapering.
    """
    if not hasattr(gen, "river_paths") or not gen.river_paths:
        return []

    detailed_streams = []
    for path in gen.river_paths:
        if len(path) < 2:
            continue
        stream = []
        is_ocean = bool(path[-1][4] > 0.5) if len(path[-1]) > 4 else (path[-1][2] <= 0.01)
        for i in range(len(path) - 1):
            cn0 = path[i]
            cn1 = path[i + 1]
            flux = cn1[3]

            edge = None
            for c in gen.corners:
                if abs(c.x - cn0[0]) < 0.01 and abs(c.y - cn0[1]) < 0.01:
                    for e in c.protrudes:
                        if (abs(e.v0.x - cn1[0]) < 0.01 and abs(e.v0.y - cn1[1]) < 0.01) or (abs(e.v1.x - cn1[0]) < 0.01 and abs(e.v1.y - cn1[1]) < 0.01):
                            edge = e
                            break
            # If this edge lies along the ocean coastline (separating land and ocean), terminate immediately!
            if edge and edge.d0 and edge.d1 and (edge.d0.ocean != edge.d1.ocean):
                is_cn1_ocean = bool(cn1[4] > 0.5 if len(cn1) > 4 else cn1[2] <= 0.01)
                if is_cn1_ocean:
                    stream.append([float(cn1[0] * scale_x), float(cn1[1] * scale_y), 0.04, float(flux), True])
                break

            if edge and getattr(gen, "noisy_edges", None):
                start_corner = edge.v0 if (abs(edge.v0.x - cn0[0]) < 0.01 and abs(edge.v0.y - cn0[1]) < 0.01) else edge.v1
                edge_pts = gen.noisy_edges.get_edge_path(edge, start_corner=start_corner)
                n_ep = len(edge_pts)
                for k in range(n_ep if i == len(path) - 2 else n_ep - 1):
                    t = k / float(max(1, n_ep - 1))
                    z = (cn0[2] * (1.0 - t) + cn1[2] * t) * elev_scale
                    stream.append([float(edge_pts[k][0] * scale_x), float(edge_pts[k][1] * scale_y), float(z), float(flux), is_ocean])
            else:
                stream.append([float(cn0[0] * scale_x), float(cn0[1] * scale_y), float(cn0[2] * elev_scale), float(flux), is_ocean])

        if not stream:
            continue

        if not (edge and getattr(gen, "noisy_edges", None)) and len(stream) < len(path):
            stream.append([float(path[-1][0] * scale_x), float(path[-1][1] * scale_y), float(path[-1][2] * elev_scale), float(path[-1][3]), is_ocean])

        if len(stream) >= 2:
            n_st = len(stream)
            end_z = 0.04 if is_ocean else float(stream[-1][2])
            stream[-1][2] = end_z
            for k in range(n_st - 2, -1, -1):
                stream[k][2] = max(stream[k][2], stream[k + 1][2] + 0.005)
            detailed_streams.append(stream)

    return detailed_streams


# Backwards-compatibility alias
compute_catmull_rom_river_streams = build_detailed_river_streams


def build_island_mesh(
    gen: PolygonMapGenerator,
    width: int = 1000,
    height: int = 1000,
    mode: str = "fractal",
    target_polys: int = 16000,
    subdivision_depth: int = 1,
    roughness: float = 3.0,
    lateral_jitter: float = 0.22,
    elevation_alpha: float = 0.0,
    elev_scale: float = 70.0,
    normal_smooth_ratio: float = 0.70,
    quad_fold: bool = True,
    ridge_noise: float = 0.35,
    erosion_strength: float = 0.30,
    erosion_droplets: int = 15000,
) -> Tuple[List[Tuple], int]:
    """
    Builds and subdivides the island's 3D micropoly mesh according to the chosen mode.
    Integrates:
    1. Global Continuous Island Heightmap Interpolation (eliminating per-polygon domes/pyramids).
    2. Continuous Particle-based Hydraulic & Thermal Erosion Field sampling.
    3. Musgrave Ridged Multifractal Elevation Noise with Domain Warping.
    Returns: (triangles_list, total_poly_count)
    """
    scale_x = width / gen.width
    scale_y = height / gen.height

    # 1. Global Continuous Hydraulic & Thermal Erosion Simulation
    from hydraulic_erosion import simulate_global_erosion
    erosion_field = simulate_global_erosion(
        gen,
        grid_size=192,
        num_droplets=int(erosion_droplets) if (erosion_strength > 0 and erosion_droplets > 0) else 0,
        carving_scale=erosion_strength,
        thermal_iterations=2,
        seed=gen.seed,
    )

    # Precompute discretized ocean shoreline points for continuous coastal distance envelope
    from scipy.spatial import cKDTree
    coastline_pts = []
    for edge in gen.edges:
        d0, d1 = edge.d0, edge.d1
        v0, v1 = edge.v0, edge.v1
        if not d0 or not d1 or not v0 or not v1:
            continue
        if (d0.water != d1.water) and (d0.ocean or d1.ocean):
            if getattr(gen, "noisy_edges", None):
                pts = gen.noisy_edges.get_edge_path(edge, start_corner=v0)
                for p in pts:
                    coastline_pts.append(np.array([p[0] * scale_x, p[1] * scale_y], dtype=np.float64))
            else:
                p0 = np.array([v0.x * scale_x, v0.y * scale_y], dtype=np.float64)
                p1 = np.array([v1.x * scale_x, v1.y * scale_y], dtype=np.float64)
                edge_len = float(np.linalg.norm(p1 - p0))
                n_samples = max(2, int(edge_len / 2.5))
                for t in np.linspace(0.0, 1.0, n_samples):
                    coastline_pts.append(p0 * (1.0 - t) + p1 * t)

    coast_tree = cKDTree(coastline_pts) if coastline_pts else None

    # Continuous Catmull-Rom River Network KDTree for 3D physical valley & canyon carving
    river_streams = compute_catmull_rom_river_streams(gen, scale_x, scale_y, elev_scale, substeps=6)

    dense_riv_pts = []
    dense_riv_z = []
    dense_riv_flux = []
    for stream in river_streams:
        n_st = len(stream)
        for k in range(n_st - 1):
            p0 = stream[k]
            p1 = stream[k + 1]
            seg_len = math.hypot(p1[0] - p0[0], p1[1] - p0[1])
            n_sub = max(1, int(math.ceil(seg_len / 1.2)))
            for s in range(n_sub):
                t_s = s / float(n_sub)
                dense_riv_pts.append([p0[0] * (1.0 - t_s) + p1[0] * t_s, p0[1] * (1.0 - t_s) + p1[1] * t_s])
                dense_riv_z.append(p0[2] * (1.0 - t_s) + p1[2] * t_s)
                dense_riv_flux.append(p0[3] * (1.0 - t_s) + p1[3] * t_s)
        dense_riv_pts.append([stream[-1][0], stream[-1][1]])
        dense_riv_z.append(stream[-1][2])
        dense_riv_flux.append(stream[-1][3])

    river_kdtree = cKDTree(dense_riv_pts) if dense_riv_pts else None
    dense_riv_z_arr = np.array(dense_riv_z, dtype=np.float64) if dense_riv_z else None
    dense_riv_flux_arr = np.array(dense_riv_flux, dtype=np.float64) if dense_riv_flux else None

    canyon_depth_param = float(getattr(gen, "canyon_depth", 1.5))
    valley_width_param = float(getattr(gen, "valley_width", 1.0))
    river_width_param = float(getattr(gen, "river_width", 1.0))

    w_bed_base = (4.0 + 3.0 * max(0.4, river_width_param))
    w_val_base = max(w_bed_base + 16.0, (18.0 + 24.0 * max(0.5, valley_width_param)))

    def carve_continuous_valley(pt_x, pt_y, z_val, coast_dist=999.0):
        if river_kdtree is None or coast_dist <= 0.05:
            return z_val
        d_riv, r_idx = river_kdtree.query([pt_x, pt_y])
        if d_riv > w_val_base * 1.6:
            return z_val

        r_z = dense_riv_z_arr[r_idx]
        r_flux = dense_riv_flux_arr[r_idx]
        flux_w = math.sqrt(max(1.0, r_flux))
        w_bed = w_bed_base * (0.8 + 0.30 * flux_w)
        w_val = w_val_base * (0.8 + 0.30 * flux_w)

        c_factor = (0.8 + 3.0 * canyon_depth_param) * (0.8 + 0.35 * flux_w) * (elev_scale / 60.0) if canyon_depth_param > 0 else 0.0
        bed_drop = max(0.8, c_factor * 0.45) if canyon_depth_param > 0 else 0.2
        canyon_cut = c_factor

        coast_env = min(1.0, max(0.0, coast_dist / 6.0))
        z_bed = max(0.04, r_z - bed_drop * coast_env)

        if d_riv <= w_bed:
            return min(z_val, z_bed)
        if d_riv <= w_val:
            t = (d_riv - w_bed) / (w_val - w_bed)
            s = t * t * (3.0 - 2.0 * t)
            wall_h = z_bed + s * max(0.0, z_val - z_bed)
            bank_gouge = canyon_cut * (1.0 - s) * (1.0 - s) * coast_env
            z_carved = min(z_val, max(z_bed, wall_h - bank_gouge * 0.35))
            return min(z_val, z_carved)
        return z_val

    COAST_TRANSITION_WIDTH = 32.0  # units (~1.0 - 1.2 Voronoi cell radius)

    def calc_coastal_envelope(dist):
        if dist <= 0.05:
            return 0.0
        if dist >= COAST_TRANSITION_WIDTH:
            return 1.0
        t = dist / COAST_TRANSITION_WIDTH
        # Quintic Hermite envelope with C^2 continuity: first and second derivatives are 0 at t=0 and t=1
        return (6.0 * t**2 - 15.0 * t + 10.0) * (t**3)

    # Dynamic micropoly beach colors (wet sand, dry golden sand, and dune grass)
    COLOR_WET_SAND = np.array([168, 152, 122], dtype=np.float64)
    COLOR_GOLDEN_SAND = np.array([214, 198, 152], dtype=np.float64)
    COLOR_DUNE_SAND = np.array([192, 188, 142], dtype=np.float64)

    def calc_vertex_color(x, y, z, dist, base_col, is_beach_cell=False, is_river=False):
        if is_river:
            # Riverbed and carved valley stays river channel base color, not turned into beach sand
            return base_col

        # High-frequency procedural sand ripple & shoreline undulation noise
        fx = x * 0.08 + gen.seed * 0.13
        fy = y * 0.08 + gen.seed * 0.27
        noise_var = (math.sin(fx) * math.cos(fy)) * 2.5 + (math.sin(fx * 2.3 + 1.1) * math.cos(fy * 2.1 - 0.7)) * 1.2

        eff_dist = max(0.0, dist + noise_var)
        eff_z = max(0.0, z + noise_var * 0.15)

        if is_beach_cell:
            max_beach_dist = 42.0
            max_beach_z = 4.2
        else:
            max_beach_dist = 22.0
            max_beach_z = 2.6

        if eff_dist < max_beach_dist and eff_z < max_beach_z:
            dist_factor = 1.0 - (eff_dist / max_beach_dist)
            z_factor = 1.0 - (eff_z / max_beach_z)
            beach_weight = min(1.0, max(0.0, dist_factor * z_factor * 1.3))
            # Smoothstep curve for soft organic transition into vegetation
            beach_weight = beach_weight * beach_weight * (3.0 - 2.0 * beach_weight)

            if eff_z < 0.6:
                sand_col = COLOR_WET_SAND * (1.0 - eff_z / 0.6) + COLOR_GOLDEN_SAND * (eff_z / 0.6)
            elif eff_z < 1.8:
                sand_col = COLOR_GOLDEN_SAND
            else:
                t_dune = min(1.0, (eff_z - 1.8) / 0.8)
                sand_col = COLOR_GOLDEN_SAND * (1.0 - t_dune) + COLOR_DUNE_SAND * t_dune

            return base_col * (1.0 - beach_weight) + sand_col * beach_weight
        return base_col

    # Mode: Fractal Watertight Edge-Cached 2D+3D Subdivision (Default)
    if mode == "fractal":
        from collections import defaultdict
        vertices = []
        vertex_map = {}
        is_boundary_vertex = {}
        vertex_coast_dist = {}
        vertex_base_color = {}
        vertex_is_beach = {}

        def get_or_add_vertex(pt3d, is_fixed=False, dist=None, base_col=None, is_beach=False):
            key = (round(float(pt3d[0]), 1), round(float(pt3d[1]), 1))
            if key in vertex_map:
                idx = vertex_map[key]
                if is_fixed:
                    is_boundary_vertex[idx] = True
                    vertex_coast_dist[idx] = 0.0
                elif dist is not None:
                    vertex_coast_dist[idx] = min(vertex_coast_dist.get(idx, 999.0), dist)
                if is_beach:
                    vertex_is_beach[idx] = True
                return idx
            idx = len(vertices)
            vertices.append(np.array(pt3d, dtype=np.float64))
            vertex_map[key] = idx
            is_boundary_vertex[idx] = is_fixed
            if is_fixed:
                vertex_coast_dist[idx] = 0.0
            elif dist is not None:
                vertex_coast_dist[idx] = dist
            else:
                vertex_coast_dist[idx] = float(coast_tree.query(pt3d[:2])[0]) if coast_tree else 999.0
            vertex_base_color[idx] = base_col if base_col is not None else np.array([120, 160, 100], dtype=np.float64)
            vertex_is_beach[idx] = is_beach
            return idx

        base_triangles = []
        max_river_flux = max((e.river for e in gen.edges), default=1)

        for edge in gen.edges:
            d0, d1 = edge.d0, edge.d1
            v0, v1 = edge.v0, edge.v1
            if not d0 or not d1 or not v0 or not v1:
                continue
            if d0.water and d1.water:
                continue

            # Normalize edge direction so that (v0 -> v1 -> d0) is consistently counter-clockwise
            cross2d = (v1.x - v0.x) * (d0.y - v0.y) - (v1.y - v0.y) * (d0.x - v0.x)
            if cross2d < 0:
                v0, v1 = v1, v0

            # An edge is an ocean coastline if it separates land from ocean water
            is_ocean_coast = (d0.water != d1.water) and (d0.ocean or d1.ocean)

            dist_v0 = 0.0 if (v0.ocean or v0.coast or is_ocean_coast) else (float(coast_tree.query([v0.x * scale_x, v0.y * scale_y])[0]) if coast_tree else 999.0)
            dist_v1 = 0.0 if (v1.ocean or v1.coast or is_ocean_coast) else (float(coast_tree.query([v1.x * scale_x, v1.y * scale_y])[0]) if coast_tree else 999.0)
            dist_d0 = 0.0 if d0.water else (float(coast_tree.query([d0.x * scale_x, d0.y * scale_y])[0]) if coast_tree else 999.0)
            dist_d1 = 0.0 if d1.water else (float(coast_tree.query([d1.x * scale_x, d1.y * scale_y])[0]) if coast_tree else 999.0)

            env_v0 = calc_coastal_envelope(dist_v0)
            env_v1 = calc_coastal_envelope(dist_v1)
            env_d0 = calc_coastal_envelope(dist_d0)
            env_d1 = calc_coastal_envelope(dist_d1)

            # Corners on the coastline (land touching sea) stay strictly at sea level (0.0)
            raw_v0 = max(0.0, erosion_field.sample_elevation(v0.x, v0.y) * elev_scale)
            raw_v1 = max(0.0, erosion_field.sample_elevation(v1.x, v1.y) * elev_scale)
            z_v0 = 0.0 if (v0.ocean or v0.coast or is_ocean_coast or dist_v0 <= 0.05) else (raw_v0 * env_v0)
            z_v1 = 0.0 if (v1.ocean or v1.coast or is_ocean_coast or dist_v1 <= 0.05) else (raw_v1 * env_v1)

            # Center of land polygons: beaches gently slope up to dunes (<= 1.8 units); other land retains natural height
            if d0.water or dist_d0 <= 0.05:
                z_d0 = 0.0
            elif getattr(d0, "biome", "") == "BEACH":
                z_d0 = min(1.8, max(0.1, erosion_field.sample_elevation(d0.x, d0.y) * elev_scale)) * env_d0
            else:
                z_d0 = max(0.0, erosion_field.sample_elevation(d0.x, d0.y) * elev_scale) * env_d0

            if d1.water or dist_d1 <= 0.05:
                z_d1 = 0.0
            elif getattr(d1, "biome", "") == "BEACH":
                z_d1 = min(1.8, max(0.1, erosion_field.sample_elevation(d1.x, d1.y) * elev_scale)) * env_d1
            else:
                z_d1 = max(0.0, erosion_field.sample_elevation(d1.x, d1.y) * elev_scale) * env_d1

            if elevation_alpha > 0.0 and not is_ocean_coast:
                if not (v0.ocean or v0.coast) and dist_v0 > 0.05:
                    adj_v0 = [erosion_field.sample_elevation(c.x, c.y) * elev_scale for c in v0.touches if not c.water]
                    if adj_v0:
                        z_v0 += elevation_alpha * (max(adj_v0) - min(adj_v0)) * 0.5 * env_v0
                if not (v1.ocean or v1.coast) and dist_v1 > 0.05:
                    adj_v1 = [erosion_field.sample_elevation(c.x, c.y) * elev_scale for c in v1.touches if not c.water]
                    if adj_v1:
                        z_v1 += elevation_alpha * (max(adj_v1) - min(adj_v1)) * 0.5 * env_v1

            # Continuous physical river valley & canyon bed carving
            z_v0 = carve_continuous_valley(v0.x * scale_x, v0.y * scale_y, z_v0, dist_v0)
            z_v1 = carve_continuous_valley(v1.x * scale_x, v1.y * scale_y, z_v1, dist_v1)
            z_d0 = carve_continuous_valley(d0.x * scale_x, d0.y * scale_y, z_d0, dist_d0)
            z_d1 = carve_continuous_valley(d1.x * scale_x, d1.y * scale_y, z_d1, dist_d1)

            p_v0 = np.array([v0.x * scale_x, v0.y * scale_y, z_v0], dtype=np.float64)
            p_v1 = np.array([v1.x * scale_x, v1.y * scale_y, z_v1], dtype=np.float64)
            p_d0 = np.array([d0.x * scale_x, d0.y * scale_y, z_d0], dtype=np.float64)
            p_d1 = np.array([d1.x * scale_x, d1.y * scale_y, z_d1], dtype=np.float64)

            is_b0 = getattr(d0, "biome", "") == "BEACH"
            is_b1 = getattr(d1, "biome", "") == "BEACH"

            col0 = np.array(BIOME_COLORS.get(d0.biome, (120, 160, 100)), dtype=np.float64)
            col1 = np.array(BIOME_COLORS.get(d1.biome, (120, 160, 100)), dtype=np.float64)
            if not d1.water:
                col0 = col0 * 0.70 + col1 * 0.30
                col1 = col1 * 0.70 + col0 * 0.30

            if edge.river > 0:
                col0 = col0 * 0.75 + np.array([35, 115, 210], dtype=np.float64) * 0.25
                col1 = col1 * 0.75 + np.array([35, 115, 210], dtype=np.float64) * 0.25

            idx_d0 = get_or_add_vertex(p_d0, is_fixed=(d0.water or dist_d0 <= 0.05), dist=dist_d0, base_col=col0, is_beach=is_b0)
            idx_d1 = get_or_add_vertex(p_d1, is_fixed=(d1.water or dist_d1 <= 0.05), dist=dist_d1, base_col=col1, is_beach=is_b1)

            if is_ocean_coast and getattr(gen, "noisy_edges", None):
                # Fractal noisy edge path for organic, high-resolution beaches and coastlines
                noisy_pts = gen.noisy_edges.get_edge_path(edge, start_corner=v0)
                path_indices = []
                for p in noisy_pts:
                    p_3d = np.array([p[0] * scale_x, p[1] * scale_y, 0.0], dtype=np.float64)
                    idx_p = get_or_add_vertex(p_3d, is_fixed=True, dist=0.0, base_col=COLOR_WET_SAND, is_beach=True)
                    path_indices.append(idx_p)

                # Fan triangles to the land cell center
                if not d0.water:
                    for k in range(len(path_indices) - 1):
                        base_triangles.append((path_indices[k], path_indices[k+1], idx_d0, col0, z_d0 / (3.0 * elev_scale), edge.river > 0))
                if not d1.water:
                    for k in range(len(path_indices) - 1):
                        base_triangles.append((path_indices[k+1], path_indices[k], idx_d1, col1, z_d1 / (3.0 * elev_scale), edge.river > 0))
            elif d0.water != d1.water or edge.river > 0:
                idx_v0 = get_or_add_vertex(p_v0, is_fixed=(v0.ocean or v0.coast or is_ocean_coast or dist_v0 <= 0.05), dist=dist_v0, base_col=col0, is_beach=(is_b0 or is_b1))
                idx_v1 = get_or_add_vertex(p_v1, is_fixed=(v1.ocean or v1.coast or is_ocean_coast or dist_v1 <= 0.05), dist=dist_v1, base_col=col1, is_beach=(is_b0 or is_b1))
                if not d0.water:
                    base_triangles.append((idx_v0, idx_v1, idx_d0, col0, (z_v0 + z_v1 + z_d0) / (3.0 * elev_scale), edge.river > 0))
                if not d1.water:
                    base_triangles.append((idx_v1, idx_v0, idx_d1, col1, (z_v1 + z_v0 + z_d1) / (3.0 * elev_scale), edge.river > 0))
            else:
                idx_v0 = get_or_add_vertex(p_v0, is_fixed=(v0.ocean or v0.coast or is_ocean_coast or dist_v0 <= 0.05), dist=dist_v0, base_col=col0, is_beach=(is_b0 or is_b1))
                idx_v1 = get_or_add_vertex(p_v1, is_fixed=(v1.ocean or v1.coast or is_ocean_coast or dist_v1 <= 0.05), dist=dist_v1, base_col=col1, is_beach=(is_b0 or is_b1))
                diag_v = np.linalg.norm(p_v0 - p_v1)
                diag_d = np.linalg.norm(p_d0 - p_d1)
                if diag_v < diag_d:
                    base_triangles.append((idx_v0, idx_v1, idx_d0, col0, (z_v0 + z_v1 + z_d0) / (3.0 * elev_scale), False))
                    base_triangles.append((idx_v1, idx_v0, idx_d1, col1, (z_v1 + z_v0 + z_d1) / (3.0 * elev_scale), False))
                else:
                    base_triangles.append((idx_v0, idx_d1, idx_d0, col0, (z_v0 + z_d1 + z_d0) / (3.0 * elev_scale), False))
                    base_triangles.append((idx_v1, idx_d0, idx_d1, col1, (z_v1 + z_d0 + z_d1) / (3.0 * elev_scale), False))

        # Multi-core parallel subdivision across all available CPU cores
        target_depth = 0
        cur_count = len(base_triangles)
        while cur_count < target_polys:
            cur_count *= 4
            target_depth += 1

        num_workers = min(12, os.cpu_count() or 4)

        if target_depth >= 1 and num_workers > 1 and len(base_triangles) >= num_workers:
            try:
                packed_base_tris = []
                for ia, ib, ic, col, avg_elev, is_riv in base_triangles:
                    packed_base_tris.append((
                        vertices[ia], vertices[ib], vertices[ic], col, avg_elev, is_riv,
                        is_boundary_vertex.get(ia, False), is_boundary_vertex.get(ib, False), is_boundary_vertex.get(ic, False),
                        vertex_coast_dist.get(ia, 999.0), vertex_coast_dist.get(ib, 999.0), vertex_coast_dist.get(ic, 999.0),
                        vertex_is_beach.get(ia, False), vertex_is_beach.get(ib, False), vertex_is_beach.get(ic, False),
                        vertex_base_color.get(ia, col), vertex_base_color.get(ib, col), vertex_base_color.get(ic, col)
                    ))

                worker_params = (
                    gen.seed, target_depth, scale_x, scale_y, elev_scale, lateral_jitter, roughness, ridge_noise,
                    river_kdtree, dense_riv_z_arr, dense_riv_flux_arr, w_bed_base, w_val_base, canyon_depth_param, erosion_field
                )

                chunk_size = int(math.ceil(len(packed_base_tris) / float(num_workers)))
                chunks = [packed_base_tris[i : i + chunk_size] for i in range(0, len(packed_base_tris), chunk_size)]
                tasks = [(chunk, worker_params) for chunk in chunks]

                with concurrent.futures.ProcessPoolExecutor(max_workers=num_workers) as executor:
                    results = list(executor.map(_subdivide_chunk_worker, tasks))

                # Assemble results
                all_coords = np.concatenate([r[0] for r in results], axis=0)
                all_cols = np.concatenate([r[1] for r in results], axis=0)
                all_elevs = np.concatenate([r[2] for r in results], axis=0)
                all_is_rivs = np.concatenate([r[3] for r in results], axis=0)
                num_tris = len(all_coords)

                # Vectorized face normals & areas
                pa_all = all_coords[:, 0, :]
                pb_all = all_coords[:, 1, :]
                pc_all = all_coords[:, 2, :]

                va_all = pb_all - pa_all
                vb_all = pc_all - pa_all
                cross_norms = np.cross(va_all, vb_all)

                neg_z = cross_norms[:, 2] < 0
                cross_norms[neg_z] = -cross_norms[neg_z]

                double_areas = np.linalg.norm(cross_norms, axis=1, keepdims=True)
                areas = double_areas * 0.5
                safe_double_areas = np.where(double_areas > 1e-6, double_areas, 1.0)
                face_normals = np.where(double_areas > 1e-6, cross_norms / safe_double_areas, np.array([0.0, 0.0, 1.0]))

                # Deduplicate vertices across chunk boundaries for seamless normal smoothing
                flat_verts = all_coords.reshape(-1, 3)
                rounded_verts = np.round(flat_verts, 2)
                _, inverse_indices = np.unique(
                    rounded_verts.view(np.dtype((np.void, rounded_verts.dtype.itemsize * 3))),
                    return_inverse=True
                )
                num_unique_verts = int(np.max(inverse_indices)) + 1
                tri_indices = inverse_indices.reshape(-1, 3)

                weighted_face_norms = face_normals * areas
                vertex_normals = np.zeros((num_unique_verts, 3), dtype=np.float64)
                np.add.at(vertex_normals, tri_indices[:, 0], weighted_face_norms)
                np.add.at(vertex_normals, tri_indices[:, 1], weighted_face_norms)
                np.add.at(vertex_normals, tri_indices[:, 2], weighted_face_norms)

                vn_lens = np.linalg.norm(vertex_normals, axis=1, keepdims=True)
                safe_vn_lens = np.where(vn_lens > 1e-6, vn_lens, 1.0)
                vertex_normals = np.where(vn_lens > 1e-6, vertex_normals / safe_vn_lens, np.array([0.0, 0.0, 1.0]))

                avg_vert_norms = (vertex_normals[tri_indices[:, 0]] + vertex_normals[tri_indices[:, 1]] + vertex_normals[tri_indices[:, 2]]) / 3.0
                avg_vn_lens = np.linalg.norm(avg_vert_norms, axis=1, keepdims=True)
                safe_avg_vn_lens = np.where(avg_vn_lens > 1e-6, avg_vn_lens, 1.0)
                avg_vert_norms = np.where(avg_vn_lens > 1e-6, avg_vert_norms / safe_avg_vn_lens, face_normals)

                blended_norms = avg_vert_norms * normal_smooth_ratio + face_normals * (1.0 - normal_smooth_ratio)
                bn_lens = np.linalg.norm(blended_norms, axis=1, keepdims=True)
                safe_bn_lens = np.where(bn_lens > 1e-6, bn_lens, 1.0)
                blended_norms = np.where(bn_lens > 1e-6, blended_norms / safe_bn_lens, face_normals)

                final_triangles = []
                for i in range(num_tris):
                    final_triangles.append((
                        pa_all[i], pb_all[i], pc_all[i],
                        all_cols[i], float(all_elevs[i]), bool(all_is_rivs[i]),
                        float(areas[i, 0]), blended_norms[i]
                    ))
                return final_triangles, len(final_triangles)
            except Exception as e:
                import traceback
                print(f"[Warning] Multi-core subdivision failed ({e}), falling back to single-thread: {traceback.format_exc()}")

        triangles_idx = list(base_triangles)
        edge_midpoints = {}
        rng = np.random.RandomState(gen.seed)

        def get_midpoint(i_a, i_b, depth):
            edge_key = (min(i_a, i_b), max(i_a, i_b))
            if edge_key in edge_midpoints:
                return edge_midpoints[edge_key]

            pa = vertices[i_a]
            pb = vertices[i_b]
            e_xy = pb[:2] - pa[:2]
            length = float(np.linalg.norm(e_xy))
            mid = (pa + pb) * 0.5

            dist_a = vertex_coast_dist.get(i_a, 999.0)
            dist_b = vertex_coast_dist.get(i_b, 999.0)
            mid_dist = (dist_a + dist_b) * 0.5
            mid_env = calc_coastal_envelope(mid_dist)
            is_bnd = (is_boundary_vertex.get(i_a, False) and is_boundary_vertex.get(i_b, False)) or (mid_dist <= 0.05)
            is_beach = vertex_is_beach.get(i_a, False) or vertex_is_beach.get(i_b, False)

            if is_bnd:
                # Island perimeter / coastline boundary: 2D fractal edge subdivision down to micro-lengths
                if length > 0.15:
                    n_perp = np.array([-e_xy[1], e_xy[0]], dtype=np.float64) / length
                    bnd_decay = 0.85 ** depth
                    bnd_disp = rng.uniform(-0.45, 0.45) * length * bnd_decay
                    disp_long = rng.uniform(-0.06, 0.06) * length * bnd_decay
                    mid[0] += n_perp[0] * bnd_disp + (e_xy[0] / length) * disp_long
                    mid[1] += n_perp[1] * bnd_disp + (e_xy[1] / length) * disp_long
                mid[2] = 0.0
                mid_dist = 0.0
            else:
                # Interior edge: 2D lateral displacement + continuous 3D elevation sampling
                if length > 0.35:
                    n_perp = np.array([-e_xy[1], e_xy[0]], dtype=np.float64) / length
                    decay = 0.70 ** depth
                    jitter_env = 0.40 + 0.60 * mid_env
                    disp_lat = rng.uniform(-lateral_jitter, lateral_jitter) * length * decay * jitter_env
                    disp_long = rng.uniform(-0.08, 0.08) * length * decay * jitter_env

                    mid[0] += n_perp[0] * disp_lat + (e_xy[0] / length) * disp_long
                    mid[1] += n_perp[1] * disp_lat + (e_xy[1] / length) * disp_long

                    # Continuous global height sampling at subdivided midpoint modulated by coastal envelope
                    base_h = erosion_field.sample_elevation(mid[0] / scale_x, mid[1] / scale_y) * elev_scale * mid_env
                    fbm_val = procedural_fbm_elevation(mid[0], mid[1], gen.seed, amplitude=elev_scale / 70.0) * (decay * 0.35) * mid_env
                    mid_norm_elev = base_h / max(1.0, elev_scale)
                    rdg_val = procedural_ridged_elevation(mid[0], mid[1], mid_norm_elev, gen.seed, amplitude=elev_scale / 45.0, ridge_roughness=ridge_noise) * (decay * 0.5) * mid_env
                    disp_z = (rng.uniform(-0.35, 0.35) * roughness * (length / 24.0) + fbm_val + rdg_val) * mid_env
                    mid[2] = max(0.0, (0.70 * base_h + 0.30 * mid[2] + disp_z) * mid_env)
                    mid[2] = carve_continuous_valley(mid[0], mid[1], mid[2], mid_dist)

            idx_mid = len(vertices)
            vertices.append(mid)
            is_boundary_vertex[idx_mid] = is_bnd
            vertex_coast_dist[idx_mid] = 0.0 if is_bnd else mid_dist
            vertex_is_beach[idx_mid] = is_beach or is_bnd

            c_a = vertex_base_color.get(i_a, np.array([120, 160, 100], dtype=np.float64))
            c_b = vertex_base_color.get(i_b, np.array([120, 160, 100], dtype=np.float64))
            if is_bnd:
                vertex_base_color[idx_mid] = COLOR_WET_SAND
            else:
                vertex_base_color[idx_mid] = (c_a + c_b) * 0.5

            edge_midpoints[edge_key] = idx_mid
            return idx_mid

        depth = 0
        while len(triangles_idx) < target_polys:
            new_triangles = []
            for i_a, i_b, i_c, col, el, riv in triangles_idx:
                m_ab = get_midpoint(i_a, i_b, depth)
                m_bc = get_midpoint(i_b, i_c, depth)
                m_ca = get_midpoint(i_c, i_a, depth)

                new_triangles.append((i_a, m_ab, m_ca, col, el, riv))
                new_triangles.append((i_b, m_bc, m_ab, col, el, riv))
                new_triangles.append((i_c, m_ca, m_bc, col, el, riv))
                new_triangles.append((m_ab, m_bc, m_ca, col, el, riv))

            triangles_idx = new_triangles

            # Multi-level vertex elevation relaxation for smooth natural transitions
            adj_map = defaultdict(set)
            for i_a, i_b, i_c, _, _, _ in triangles_idx:
                adj_map[i_a].add(i_b)
                adj_map[i_a].add(i_c)
                adj_map[i_b].add(i_a)
                adj_map[i_b].add(i_c)
                adj_map[i_c].add(i_a)
                adj_map[i_c].add(i_b)

            relax_weight = 0.20 * (0.75 ** depth)
            for v_idx in list(adj_map.keys()):
                if is_boundary_vertex.get(v_idx, False):
                    continue
                v_dist = vertex_coast_dist.get(v_idx, 999.0)
                if v_dist <= 0.05:
                    vertices[v_idx][2] = 0.0
                    continue
                v_env = calc_coastal_envelope(v_dist)
                neighbors = list(adj_map[v_idx])
                if len(neighbors) >= 3:
                    neighbor_z_mean = float(np.mean([vertices[n][2] for n in neighbors]))
                    new_z = (1.0 - relax_weight * 1.5) * vertices[v_idx][2] + (relax_weight * 1.5) * neighbor_z_mean
                    new_z += rng.uniform(-0.5, 0.5) * (roughness * 0.15 * (0.65 ** depth)) * v_env
                    vertices[v_idx][2] = max(0.0, new_z)
                    vertices[v_idx][2] = carve_continuous_valley(vertices[v_idx][0], vertices[v_idx][1], vertices[v_idx][2], v_dist)

            depth += 1
            if len(triangles_idx) >= target_polys:
                break

        # Fast vectorized area-weighted vertex and face normals computation
        num_verts = len(vertices)
        num_tris = len(triangles_idx)

        verts_arr = np.asarray(vertices, dtype=np.float64)
        tri_indices = np.array([(t[0], t[1], t[2]) for t in triangles_idx], dtype=np.int32)

        pa_all = verts_arr[tri_indices[:, 0]]
        pb_all = verts_arr[tri_indices[:, 1]]
        pc_all = verts_arr[tri_indices[:, 2]]

        va_all = pb_all - pa_all
        vb_all = pc_all - pa_all
        cross_norms = np.cross(va_all, vb_all)

        # Ensure outward pointing normal
        neg_z = cross_norms[:, 2] < 0
        cross_norms[neg_z] = -cross_norms[neg_z]

        double_areas = np.linalg.norm(cross_norms, axis=1, keepdims=True)
        areas = double_areas * 0.5
        safe_double_areas = np.where(double_areas > 1e-6, double_areas, 1.0)
        face_normals = np.where(double_areas > 1e-6, cross_norms / safe_double_areas, np.array([0.0, 0.0, 1.0]))

        # Accumulate weighted normals at vertices
        weighted_face_norms = face_normals * areas
        vertex_normals = np.zeros((num_verts, 3), dtype=np.float64)
        np.add.at(vertex_normals, tri_indices[:, 0], weighted_face_norms)
        np.add.at(vertex_normals, tri_indices[:, 1], weighted_face_norms)
        np.add.at(vertex_normals, tri_indices[:, 2], weighted_face_norms)

        vn_lens = np.linalg.norm(vertex_normals, axis=1, keepdims=True)
        safe_vn_lens = np.where(vn_lens > 1e-6, vn_lens, 1.0)
        vertex_normals = np.where(vn_lens > 1e-6, vertex_normals / safe_vn_lens, np.array([0.0, 0.0, 1.0]))

        # Vectorized blended normals
        avg_vert_norms = (vertex_normals[tri_indices[:, 0]] + vertex_normals[tri_indices[:, 1]] + vertex_normals[tri_indices[:, 2]]) / 3.0
        avg_vn_lens = np.linalg.norm(avg_vert_norms, axis=1, keepdims=True)
        safe_avg_vn_lens = np.where(avg_vn_lens > 1e-6, avg_vn_lens, 1.0)
        avg_vert_norms = np.where(avg_vn_lens > 1e-6, avg_vert_norms / safe_avg_vn_lens, face_normals)

        blended_norms = avg_vert_norms * normal_smooth_ratio + face_normals * (1.0 - normal_smooth_ratio)
        bn_lens = np.linalg.norm(blended_norms, axis=1, keepdims=True)
        safe_bn_lens = np.where(bn_lens > 1e-6, bn_lens, 1.0)
        blended_norms = np.where(bn_lens > 1e-6, blended_norms / safe_bn_lens, face_normals)

        # Unpack indices into (pa, pb, pc, col, avg_elev, is_riv, area, blended_norm)
        final_triangles = []
        for tri_idx, (i_a, i_b, i_c, col_base, avg_elev, is_riv) in enumerate(triangles_idx):
            pa = pa_all[tri_idx]
            pb = pb_all[tri_idx]
            pc = pc_all[tri_idx]
            if (pb[0] - pa[0]) * (pc[1] - pa[1]) - (pb[1] - pa[1]) * (pc[0] - pa[0]) < 0.0:
                pb, pc = pc, pb
            area = float(areas[tri_idx, 0])
            blended_norm = blended_norms[tri_idx]

            tri_mid_x = (pa[0] + pb[0] + pc[0]) / 3.0
            tri_mid_y = (pa[1] + pb[1] + pc[1]) / 3.0
            tri_mid_z = (pa[2] + pb[2] + pc[2]) / 3.0
            tri_dist = (vertex_coast_dist.get(i_a, 999.0) + vertex_coast_dist.get(i_b, 999.0) + vertex_coast_dist.get(i_c, 999.0)) / 3.0
            tri_is_beach = vertex_is_beach.get(i_a, False) or vertex_is_beach.get(i_b, False) or vertex_is_beach.get(i_c, False)

            tri_is_riv = is_riv
            if river_kdtree is not None:
                d_riv_mid, _ = river_kdtree.query([tri_mid_x, tri_mid_y])
                if d_riv_mid <= w_bed_base * 1.3:
                    tri_is_riv = True

            base_c = (vertex_base_color.get(i_a, col_base) + vertex_base_color.get(i_b, col_base) + vertex_base_color.get(i_c, col_base)) / 3.0
            tri_col = calc_vertex_color(tri_mid_x, tri_mid_y, tri_mid_z, tri_dist, base_c, is_beach_cell=tri_is_beach, is_river=tri_is_riv)

            final_triangles.append((pa, pb, pc, tri_col, avg_elev, tri_is_riv, area, blended_norm))

        return final_triangles, len(final_triangles)

    # 3. Legacy base triangles for other modes
    base_triangles = []
    for edge in gen.edges:
        d0, d1 = edge.d0, edge.d1
        v0, v1 = edge.v0, edge.v1
        if not d0 or not d1 or not v0 or not v1:
            continue
        if d0.water and d1.water:
            continue

        is_ocean_coast = (d0.water != d1.water) and (d0.ocean or d1.ocean)

        dist_v0 = 0.0 if (v0.ocean or v0.coast or is_ocean_coast) else (float(coast_tree.query([v0.x * scale_x, v0.y * scale_y])[0]) if coast_tree else 999.0)
        dist_v1 = 0.0 if (v1.ocean or v1.coast or is_ocean_coast) else (float(coast_tree.query([v1.x * scale_x, v1.y * scale_y])[0]) if coast_tree else 999.0)
        dist_d0 = 0.0 if d0.water else (float(coast_tree.query([d0.x * scale_x, d0.y * scale_y])[0]) if coast_tree else 999.0)
        dist_d1 = 0.0 if d1.water else (float(coast_tree.query([d1.x * scale_x, d1.y * scale_y])[0]) if coast_tree else 999.0)

        env_v0 = calc_coastal_envelope(dist_v0)
        env_v1 = calc_coastal_envelope(dist_v1)
        env_d0 = calc_coastal_envelope(dist_d0)
        env_d1 = calc_coastal_envelope(dist_d1)

        raw_v0 = max(0.0, erosion_field.sample_elevation(v0.x, v0.y) * elev_scale)
        raw_v1 = max(0.0, erosion_field.sample_elevation(v1.x, v1.y) * elev_scale)
        z_v0 = 0.0 if (v0.ocean or v0.coast or is_ocean_coast or dist_v0 <= 0.05) else (raw_v0 * env_v0)
        z_v1 = 0.0 if (v1.ocean or v1.coast or is_ocean_coast or dist_v1 <= 0.05) else (raw_v1 * env_v1)
        z_mid = (z_v0 + z_v1) * 0.5

        p_v0 = np.array([v0.x * scale_x, v0.y * scale_y, z_v0], dtype=np.float64)
        p_v1 = np.array([v1.x * scale_x, v1.y * scale_y, z_v1], dtype=np.float64)
        p_mid = np.array([edge.midpoint[0] * scale_x, edge.midpoint[1] * scale_y, z_mid], dtype=np.float64)

        col0 = np.array(BIOME_COLORS.get(d0.biome, (120, 160, 100)), dtype=np.float64)
        col1 = np.array(BIOME_COLORS.get(d1.biome, (120, 160, 100)), dtype=np.float64)
        if not d1.water:
            col0 = col0 * 0.70 + col1 * 0.30
            col1 = col1 * 0.70 + col0 * 0.30

        if edge.river > 0:
            col0 = col0 * 0.75 + np.array([40, 105, 35], dtype=np.float64) * 0.25
            col1 = col1 * 0.75 + np.array([40, 105, 35], dtype=np.float64) * 0.25

        def add_base_tri(pa, pb, pc, c, el, riv):
            area = 0.5 * abs((pb[0] - pa[0]) * (pc[1] - pa[1]) - (pc[0] - pa[0]) * (pb[1] - pa[1]))
            base_triangles.append((pa, pb, pc, c, el, riv, area))

        if d0.water or dist_d0 <= 0.05:
            z_d0 = 0.0
        elif getattr(d0, "biome", "") == "BEACH":
            z_d0 = min(1.8, max(0.1, erosion_field.sample_elevation(d0.x, d0.y) * elev_scale)) * env_d0
        else:
            z_d0 = max(0.0, erosion_field.sample_elevation(d0.x, d0.y) * elev_scale) * env_d0

        if d1.water or dist_d1 <= 0.05:
            z_d1 = 0.0
        elif getattr(d1, "biome", "") == "BEACH":
            z_d1 = min(1.8, max(0.1, erosion_field.sample_elevation(d1.x, d1.y) * elev_scale)) * env_d1
        else:
            z_d1 = max(0.0, erosion_field.sample_elevation(d1.x, d1.y) * elev_scale) * env_d1

        p_d0 = np.array([d0.x * scale_x, d0.y * scale_y, z_d0], dtype=np.float64)
        p_d1 = np.array([d1.x * scale_x, d1.y * scale_y, z_d1], dtype=np.float64)

        if mode == "redblob":
            if edge.river > 0:
                c_mix = (col0 + col1) * 0.5
                add_base_tri(p_v0, p_d1, p_d0, c_mix, (v0.elevation + d0.elevation) * 0.5, True)
                add_base_tri(p_v1, p_d0, p_d1, c_mix, (v1.elevation + d1.elevation) * 0.5, True)
            else:
                if not d0.water:
                    add_base_tri(p_v0, p_v1, p_d0, col0, (v0.elevation + v1.elevation + d0.elevation) / 3.0, False)
                if not d1.water:
                    add_base_tri(p_v1, p_v0, p_d1, col1, (v0.elevation + v1.elevation + d1.elevation) / 3.0, False)
        else:
            if not d0.water:
                add_base_tri(p_d0, p_v0, p_mid, col0, (d0.elevation + v0.elevation) * 0.5, edge.river > 0)
                add_base_tri(p_d0, p_mid, p_v1, col0, (d0.elevation + v1.elevation) * 0.5, edge.river > 0)

            if not d1.water:
                add_base_tri(p_d1, p_v1, p_mid, col1, (d1.elevation + v1.elevation) * 0.5, edge.river > 0)
                add_base_tri(p_d1, p_mid, p_v0, col1, (d1.elevation + v0.elevation) * 0.5, edge.river > 0)

    # 3. Apply Chosen Subdivision Strategy
    if mode == "adaptive":
        triangles = list(base_triangles)
        rng_seed = 101
        while len(triangles) < target_polys:
            needed = target_polys - len(triangles)
            num_to_subdiv = min(len(triangles), max(1, needed // 3))

            triangles.sort(key=lambda t: t[6], reverse=True)
            to_split = triangles[:num_to_subdiv]
            untouched = triangles[num_to_subdiv:]

            new_triangles = list(untouched)
            for idx, (pa, pb, pc, c, el, riv, _) in enumerate(to_split):
                rng = np.random.RandomState(rng_seed + idx)
                m_ab = (pa + pb) * 0.5
                m_bc = (pb + pc) * 0.5
                m_ca = (pc + pa) * 0.5

                edge_len = (np.linalg.norm(pb[:2] - pa[:2]) + np.linalg.norm(pc[:2] - pb[:2]) + np.linalg.norm(pa[:2] - pc[:2])) / 3.0
                scale = roughness * (edge_len / 40.0)
                m_ab[2] += (rng.rand() - 0.5) * scale
                m_bc[2] += (rng.rand() - 0.5) * scale
                m_ca[2] += (rng.rand() - 0.5) * scale

                for sa, sb, sc in [(pa, m_ab, m_ca), (pb, m_bc, m_ab), (pc, m_ca, m_bc), (m_ab, m_bc, m_ca)]:
                    area = 0.5 * abs((sb[0] - sa[0]) * (sc[1] - sa[1]) - (sc[0] - sa[0]) * (sb[1] - sa[1]))
                    new_triangles.append((sa, sb, sc, c, el, riv, area))

            triangles = new_triangles
            rng_seed += 1000
            if len(triangles) >= target_polys or num_to_subdiv == len(to_split) == 0:
                break

        return triangles, len(triangles)

    elif mode == "depth":
        def subdivide_depth(tri, d, seed):
            if d <= 0:
                return [tri]
            pa, pb, pc, c, el, riv, _ = tri
            rng = np.random.RandomState(seed)
            m_ab = (pa + pb) * 0.5
            m_bc = (pb + pc) * 0.5
            m_ca = (pc + pa) * 0.5

            edge_len = (np.linalg.norm(pb[:2] - pa[:2]) + np.linalg.norm(pc[:2] - pb[:2]) + np.linalg.norm(pa[:2] - pc[:2])) / 3.0
            scale = (roughness / (2.0 ** (subdivision_depth - d))) * (edge_len / 40.0)
            m_ab[2] += (rng.rand() - 0.5) * scale
            m_bc[2] += (rng.rand() - 0.5) * scale
            m_ca[2] += (rng.rand() - 0.5) * scale

            res = []
            for i, (sa, sb, sc) in enumerate([(pa, m_ab, m_ca), (pb, m_bc, m_ab), (pc, m_ca, m_bc), (m_ab, m_bc, m_ca)]):
                area = 0.5 * abs((sb[0] - sa[0]) * (sc[1] - sa[1]) - (sc[0] - sa[0]) * (sb[1] - sa[1]))
                res.extend(subdivide_depth((sa, sb, sc, c, el, riv, area), d - 1, seed * 7 + i * 31 + 5))
            return res

        triangles = []
        for idx, tri in enumerate(base_triangles):
            triangles.extend(subdivide_depth(tri, subdivision_depth, idx * 13 + 7))
        return triangles, len(triangles)

    elif mode == "spokes":
        # Radial perimeter spoke fans
        triangles = []
        segs = max(1, target_polys // (max(1, len(base_triangles)) // 2))
        for p in gen.centers:
            if p.water or len(p.corners) < 3:
                continue
            p_pt3d = np.array([p.x * scale_x, p.y * scale_y, p.elevation * elev_scale], dtype=np.float64)
            base_color = np.array(BIOME_COLORS.get(p.biome, (120, 160, 100)), dtype=np.float64)

            for r in p.neighbors:
                edge = next((e for e in p.borders if e.d0 == r or e.d1 == r), None)
                if not edge or not edge.v0 or not edge.v1:
                    continue
                col = base_color.copy()
                if not r.water:
                    col = col * 0.70 + np.array(BIOME_COLORS.get(r.biome, col), dtype=np.float64) * 0.30
                if edge.river > 0:
                    col = col * 0.75 + np.array([40, 105, 35], dtype=np.float64) * 0.25

                z_v0 = v_elev.get(edge.v0.index, edge.v0.elevation) * elev_scale
                z_v1 = v_elev.get(edge.v1.index, edge.v1.elevation) * elev_scale
                p_v0 = np.array([edge.v0.x * scale_x, edge.v0.y * scale_y, z_v0], dtype=np.float64)
                p_v1 = np.array([edge.v1.x * scale_x, edge.v1.y * scale_y, z_v1], dtype=np.float64)
                p_mid = np.array([edge.midpoint[0] * scale_x, edge.midpoint[1] * scale_y, (z_v0 + z_v1) * 0.5], dtype=np.float64)

                for start, end in [(p_v0, p_mid), (p_mid, p_v1)]:
                    for s in range(segs):
                        t0 = s / segs
                        t1 = (s + 1) / segs
                        pa = p_pt3d
                        pb = (1.0 - t0) * start + t0 * end
                        pc = (1.0 - t1) * start + t1 * end
                        area = 0.5 * abs((pb[0] - pa[0]) * (pc[1] - pa[1]) - (pc[0] - pa[0]) * (pb[1] - pa[1]))
                        triangles.append((pa, pb, pc, col, p.elevation, edge.river > 0, area))

        return triangles, len(triangles)

    else:
        # Default 'redblob' fold without extra subdivision
        return base_triangles, len(base_triangles)


def render_mesh(
    gen: PolygonMapGenerator,
    triangles: List[Tuple],
    width: int = 1000,
    height: int = 1000,
    snow_threshold: float = 0.82,
    sun_azimuth: float = -135.0,
    sun_elevation: float = 42.0,
    sun_intensity: float = 1.15,
    ambient_intensity: float = 0.45,
    rot_pitch: float = 0.0,
    rot_yaw: float = 0.0,
) -> pygame.Surface:
    """Rasterizes the 3D micropoly mesh onto a Pygame surface with multi-light shading and 3D rotation."""
    surface = pygame.Surface((width, height))
    surface.fill((28, 48, 85))  # Deep ocean background

    scale_x = width / gen.width
    scale_y = height / gen.height
    is_rotated = (abs(rot_pitch) > 0.1 or abs(rot_yaw) > 0.1)

    # Draw ocean cells in top-down mode
    if not is_rotated:
        for c in gen.centers:
            if not c.water or len(c.corners) < 3:
                continue
            poly_pts = [(int(cn.x * scale_x), int(cn.y * scale_y)) for cn in c.corners]
            if len(poly_pts) >= 3:
                pygame.draw.polygon(surface, (28, 48, 85), poly_pts)

    # Dynamic Sun vector from azimuth & elevation (matching ModernGL GPU pipeline)
    az_rad = math.radians(sun_azimuth)
    el_rad = math.radians(max(5.0, min(88.0, sun_elevation)))
    sun_x = math.cos(el_rad) * math.cos(az_rad)
    sun_y = math.cos(el_rad) * math.sin(az_rad)
    sun_z = math.sin(el_rad)
    L_sun = np.array([sun_x, sun_y, sun_z], dtype=np.float64)
    L_sun /= (np.linalg.norm(L_sun) + 1e-6)

    # Ambient sky fill light
    L_fill = np.array([0.45, -0.65, 0.60], dtype=np.float64)
    L_fill /= np.linalg.norm(L_fill)

    # Setup 3D rotation projection helpers if rotated
    if is_rotated:
        yaw_rad = math.radians(rot_yaw)
        cos_y = math.cos(yaw_rad)
        sin_y = math.sin(yaw_rad)
        pitch_rad = math.radians(rot_pitch)
        cos_p = math.cos(pitch_rad)
        sin_p = math.sin(pitch_rad)

        scale_factor = 0.88
        cx = width * 0.5
        cy = height * 0.5
        R = max(cx, cy)

        def project_3d(pt):
            # Centered coordinates: +X East, +Y North, +Z Up
            px = pt[0] - cx
            py = cy - pt[1]
            pz = pt[2]

            # 1. Yaw around vertical Z
            x_yaw = px * cos_y - py * sin_y
            y_yaw = px * sin_y + py * cos_y
            z_yaw = pz

            # 2. Pitch camera tilt looking North from South
            x_rot = x_yaw
            y_rot = y_yaw * cos_p + z_yaw * sin_p
            z_rot = -y_yaw * sin_p + z_yaw * cos_p

            x_ndc = (x_rot / R) * scale_factor
            y_ndc = (y_rot / R) * scale_factor

            sx = int((x_ndc + 1.0) * 0.5 * width)
            sy = int((1.0 - y_ndc) * 0.5 * height)
            return sx, sy, z_rot

        def rotate_normal(norm_vec):
            nx = norm_vec[0]
            ny = -norm_vec[1]
            nz = norm_vec[2]

            nyaw_x = nx * cos_y - ny * sin_y
            nyaw_y = nx * sin_y + ny * cos_y
            nyaw_z = nz

            nrot_x = nyaw_x
            nrot_y = nyaw_y * cos_p + nyaw_z * sin_p
            nrot_z = -nyaw_y * sin_p + nyaw_z * cos_p

            nl = math.hypot(nrot_x, nrot_y, nrot_z)
            if nl > 1e-6:
                return np.array([nrot_x / nl, nrot_y / nl, nrot_z / nl], dtype=np.float64)
            return np.array([0.0, 0.0, 1.0], dtype=np.float64)

    draw_list = []

    for tri in triangles:
        if len(tri) == 8:
            pa, pb, pc, col_base, avg_elev, is_riv, _, norm = tri
        else:
            pa, pb, pc, col_base, avg_elev, is_riv, _ = tri
            va = pb - pa
            vb = pc - pa
            norm = np.cross(va, vb)
            if norm[2] < 0:
                norm = -norm
            n_len = np.linalg.norm(norm)
            norm = norm / n_len if n_len > 1e-6 else np.array([0.0, 0.0, 1.0], dtype=np.float64)

        if is_rotated:
            norm_active = rotate_normal(norm)
        else:
            norm_active = norm

        # Multi-light illumination relative to the plane of the map (sun fixed in sky over island)
        NdotL_sun = max(0.0, float(np.dot(norm, L_sun)))
        NdotL_fill = max(0.0, float(np.dot(norm, L_fill)))
        diffuse_sun = 0.44 * sun_intensity * math.pow(NdotL_sun, 1.05)
        diffuse_fill = 0.14 * NdotL_fill
        ambient = (0.65 + 0.15 * (norm[2] - 0.7)) * (ambient_intensity / 0.45)
        shade = ambient + diffuse_sun + diffuse_fill

        col = col_base.copy()

        # Dynamic steep cliff scree (relative to horizontal map plane)
        slope_val = 1.0 - norm[2]
        if slope_val > 0.14:
            cliff_w = min(0.60, (slope_val - 0.14) / 0.22)
            col = col * (1.0 - cliff_w) + np.array([66, 64, 71], dtype=np.float64) * cliff_w

        # Snow on high peaks
        if avg_elev > snow_threshold:
            snow_w = min(0.95, math.pow((avg_elev - snow_threshold) / (1.0 - snow_threshold), 2.0))
            col = col * (1.0 - snow_w) + np.array([242, 244, 250], dtype=np.float64) * snow_w

        shaded_rgb = col * shade
        # Soft-knee highlight compression
        for k in range(3):
            if shaded_rgb[k] > 220.0:
                shaded_rgb[k] = 220.0 + (shaded_rgb[k] - 220.0) * 0.35

        final_rgb = (
            min(248, max(0, int(shaded_rgb[0]))),
            min(248, max(0, int(shaded_rgb[1]))),
            min(248, max(0, int(shaded_rgb[2]))),
        )

        if is_rotated:
            sxa, sya, za = project_3d(pa)
            sxb, syb, zb = project_3d(pb)
            sxc, syc, zc = project_3d(pc)
            z_eye = (za + zb + zc) / 3.0
            draw_list.append((z_eye, final_rgb, [(sxa, sya), (sxb, syb), (sxc, syc)]))
        else:
            pts2d = [
                (int(pa[0] * scale_x), int(pa[1] * scale_y)),
                (int(pb[0] * scale_x), int(pb[1] * scale_y)),
                (int(pc[0] * scale_x), int(pc[1] * scale_y)),
            ]
            if len(pts2d) >= 3:
                pygame.draw.polygon(surface, final_rgb, pts2d)

    # If 3D rotated, sort back-to-front (Painter's algorithm)
    if is_rotated:
        draw_list.sort(key=lambda item: item[0])
        for _, final_rgb, pts2d in draw_list:
            if len(pts2d) >= 3:
                pygame.draw.polygon(surface, final_rgb, pts2d)

    # Build spatial KD-tree on terrain triangle vertices for surface elevation sampling in 3D
    mesh_tree = None
    mesh_pts = None
    if is_rotated and triangles:
        try:
            from scipy.spatial import cKDTree
            mesh_pts = np.asarray([v for t in triangles for v in (t[0], t[1], t[2])], dtype=np.float32)
            mesh_tree = cKDTree(mesh_pts[:, :2])
        except Exception:
            mesh_tree = None

    def sample_cpu_elevation(coords_2d):
        if mesh_tree is None or len(coords_2d) == 0:
            return None
        dists, idxs = mesh_tree.query(coords_2d, k=min(3, len(mesh_pts)))
        if dists.ndim == 1 or (dists.ndim == 2 and dists.shape[1] == 1):
            z_vals = mesh_pts[idxs.flatten(), 2]
        else:
            weights = 1.0 / np.maximum(dists, 1e-4)
            weights /= np.sum(weights, axis=1, keepdims=True)
            z_vals = np.sum(mesh_pts[idxs, 2] * weights, axis=1)
        return np.maximum(0.0, z_vals) + 0.12

    # Rivers along noisy paths (oriented strictly upstream -> downstream, monotonic downhill)
    for e in gen.edges:
        if e.river > 0 and gen.noisy_edges and e.v0 and e.v1:
            if (e.d0 and e.d1 and e.d0.water and e.d1.water):
                continue
            if (getattr(e.v0, "ocean", False) and getattr(e.v1, "ocean", False)):
                continue

            # Consistent flow direction: upstream (higher elevation) -> downstream (lower elevation)
            if e.v0.elevation >= e.v1.elevation:
                upstream, downstream = e.v0, e.v1
            else:
                upstream, downstream = e.v1, e.v0

            pts = gen.noisy_edges.get_edge_path(e, start_corner=upstream)
            n_p = len(pts)
            if n_p >= 2:
                w = min(5, max(2, int(1 + math.sqrt(e.river))))
                if is_rotated:
                    coords = np.array([[p[0] * scale_x, p[1] * scale_y] for p in pts], dtype=np.float32)
                    z_sampled = sample_cpu_elevation(coords)
                    if z_sampled is not None:
                        z_vals = np.array(z_sampled, dtype=np.float32)
                        z_start_corner = float(upstream.elevation * 28.0)
                        z_end_corner = float(downstream.elevation * 28.0)
                        z_start = max(z_vals[0], z_start_corner * 0.5)
                        z_end = min(z_vals[-1], z_end_corner)
                        if z_end > z_start:
                            z_end = z_start * 0.95

                        t = np.linspace(0.0, 1.0, n_p, dtype=np.float32)
                        z_linear = z_start * (1.0 - t) + z_end * t
                        z_vals = np.minimum(z_vals, z_linear + 0.05)
                        z_vals[0] = z_start
                        z_vals[-1] = z_end

                        # Strictly non-increasing elevation along the downhill flow path
                        for i in range(1, n_p):
                            if z_vals[i] > z_vals[i - 1]:
                                z_vals[i] = z_vals[i - 1]

                        for i in range(n_p - 1):
                            sx0, sy0, _ = project_3d((coords[i, 0], coords[i, 1], float(z_vals[i])))
                            sx1, sy1, _ = project_3d((coords[i+1, 0], coords[i+1, 1], float(z_vals[i+1])))
                            pygame.draw.line(surface, (28, 75, 135), (sx0, sy0), (sx1, sy1), width=w)
                    else:
                        z0 = float(getattr(upstream, "elevation", 0.0) * 28.0) + 0.3
                        z1 = float(getattr(downstream, "elevation", 0.0) * 28.0) + 0.3
                        for i in range(n_p - 1):
                            t_a = i / (n_p - 1)
                            t_b = (i + 1) / (n_p - 1)
                            za = z0 * (1.0 - t_a) + z1 * t_a
                            zb = z0 * (1.0 - t_b) + z1 * t_b
                            sx0, sy0, _ = project_3d((coords[i, 0], coords[i, 1], za))
                            sx1, sy1, _ = project_3d((coords[i+1, 0], coords[i+1, 1], zb))
                            pygame.draw.line(surface, (28, 75, 135), (sx0, sy0), (sx1, sy1), width=w)
                else:
                    r_pts = [(int(pt[0] * scale_x), int(pt[1] * scale_y)) for pt in pts]
                    pygame.draw.lines(surface, (28, 75, 135), False, r_pts, width=w)

    # Volcanic lava fissures
    for e in gen.edges:
        if getattr(e, 'lava', False):
            if is_rotated:
                coords = np.array([[e.v0.x * scale_x, e.v0.y * scale_y],
                                   [e.v1.x * scale_x, e.v1.y * scale_y]], dtype=np.float32)
                z_sampled = sample_cpu_elevation(coords)
                if z_sampled is not None:
                    za = float(z_sampled[0])
                    zb = float(z_sampled[1])
                else:
                    za = float(getattr(e.v0, "elevation", 0.0) * 28.0) + 0.3
                    zb = float(getattr(e.v1, "elevation", 0.0) * 28.0) + 0.3
                sx0, sy0, _ = project_3d((coords[0, 0], coords[0, 1], za))
                sx1, sy1, _ = project_3d((coords[1, 0], coords[1, 1], zb))
                pygame.draw.line(surface, (255, 60, 0), (sx0, sy0), (sx1, sy1), 4)
                pygame.draw.line(surface, (255, 210, 50), (sx0, sy0), (sx1, sy1), 2)
            else:
                p0 = (int(e.v0.x * scale_x), int(e.v0.y * scale_y))
                p1 = (int(e.v1.x * scale_x), int(e.v1.y * scale_y))
                pygame.draw.line(surface, (255, 60, 0), p0, p1, 4)
                pygame.draw.line(surface, (255, 210, 50), p0, p1, 2)

    return surface


def export_island_wireframe_usdz(
    gen: PolygonMapGenerator,
    triangles: List[Tuple],
    usdz_path: str,
    wire_width: float = 0.8,
) -> str:
    """
    Exports the 3D micropoly wireframe mesh as an Apple Quick Look & AR compliant USDZ package.
    Each triangle edge is extruded into a thin quad strut mesh with Whittaker biome colors,
    oriented Y-up and centered so it spins cleanly in macOS Finder / Quick Look.
    """
    try:
        from pxr import Usd, UsdGeom, Sdf, Gf, UsdUtils
    except ImportError:
        print("Error: 'usd-core' (pxr) is required to export USDZ files. Install via: pip install usd-core", file=sys.stderr)
        return ""

    t0 = time.time()
    # 1. Extract unique edges with shared color
    unique_edges = {}
    for tri in triangles:
        pa, pb, pc = tri[0], tri[1], tri[2]
        pt_a = (round(float(pa[0]), 2), round(float(pa[1]), 2), round(float(pa[2]), 2))
        pt_b = (round(float(pb[0]), 2), round(float(pb[1]), 2), round(float(pb[2]), 2))
        pt_c = (round(float(pc[0]), 2), round(float(pc[1]), 2), round(float(pc[2]), 2))

        col_arr = np.array(tri[3], dtype=np.float64)
        for p1, p2 in [(pt_a, pt_b), (pt_b, pt_c), (pt_c, pt_a)]:
            edge_key = (min(p1, p2), max(p1, p2))
            if edge_key not in unique_edges:
                unique_edges[edge_key] = col_arr

    print(f"Extracted {len(unique_edges):,} unique wireframe edges from {len(triangles):,} triangles.")

    # 2. Build USD stage using binary crate package (.usdc in .usdz)
    os.makedirs(os.path.dirname(os.path.abspath(usdz_path)), exist_ok=True)
    temp_usdc = usdz_path.replace(".usdz", ".usdc") if usdz_path.endswith(".usdz") else usdz_path + ".usdc"

    if os.path.exists(temp_usdc):
        os.remove(temp_usdc)

    stage = Usd.Stage.CreateNew(temp_usdc)
    UsdGeom.SetStageUpAxis(stage, UsdGeom.Tokens.y)  # Apple Quick Look Y-up standard
    UsdGeom.SetStageMetersPerUnit(stage, 0.01)       # Centimeters

    root = UsdGeom.Xform.Define(stage, "/Island")
    stage.SetDefaultPrim(root.GetPrim())

    mesh_prim = UsdGeom.Mesh.Define(stage, "/Island/WireframeMesh")

    points = []
    face_vertex_counts = []
    face_vertex_indices = []
    colors = []

    # Center model around origin (X: width/2, Z: height/2)
    cx = gen.width * 0.5
    cz = gen.height * 0.5
    half_w = wire_width * 0.5

    for (p1, p2), col in unique_edges.items():
        # Coordinate mapping to Y-up:
        # map X -> 3D X
        # map Y (screen downwards) -> 3D Z
        # map Z (elevation) -> 3D Y (up)
        p1_3d = np.array([p1[0] - cx, p1[2], p1[1] - cz], dtype=np.float64)
        p2_3d = np.array([p2[0] - cx, p2[2], p2[1] - cz], dtype=np.float64)

        edge_vec = p2_3d - p1_3d
        edge_len = np.linalg.norm(edge_vec)
        if edge_len < 1e-4:
            continue

        # Perpendicular horizontal vector in XZ plane
        horiz_dir = np.array([-edge_vec[2], 0.0, edge_vec[0]], dtype=np.float64)
        h_len = np.linalg.norm(horiz_dir)
        if h_len > 1e-6:
            perp = (horiz_dir / h_len) * half_w
        else:
            perp = np.array([half_w, 0.0, 0.0], dtype=np.float64)

        # 4 vertices for the thin quad strut
        v0 = p1_3d - perp
        v1 = p1_3d + perp
        v2 = p2_3d + perp
        v3 = p2_3d - perp

        base_idx = len(points)
        points.extend([
            Gf.Vec3f(float(v0[0]), float(v0[1]), float(v0[2])),
            Gf.Vec3f(float(v1[0]), float(v1[1]), float(v1[2])),
            Gf.Vec3f(float(v2[0]), float(v2[1]), float(v2[2])),
            Gf.Vec3f(float(v3[0]), float(v3[1]), float(v3[2])),
        ])

        # Double-sided quad (two triangles forward, two triangles reverse)
        face_vertex_counts.extend([3, 3, 3, 3])
        face_vertex_indices.extend([
            base_idx, base_idx + 1, base_idx + 2,
            base_idx, base_idx + 2, base_idx + 3,
            base_idx + 2, base_idx + 1, base_idx,
            base_idx + 3, base_idx + 2, base_idx,
        ])

        # Biome / elevation RGB in [0, 1]
        c_gf = Gf.Vec3f(float(col[0] / 255.0), float(col[1] / 255.0), float(col[2] / 255.0))
        colors.extend([c_gf, c_gf, c_gf, c_gf])

    mesh_prim.CreatePointsAttr().Set(points)
    mesh_prim.CreateFaceVertexCountsAttr().Set(face_vertex_counts)
    mesh_prim.CreateFaceVertexIndicesAttr().Set(face_vertex_indices)

    # Display colors per face
    color_primvar = mesh_prim.CreateDisplayColorPrimvar(UsdGeom.Tokens.uniform)
    color_primvar.Set(colors)

    # Double-sided attribute ensures strut faces render from any camera angle
    mesh_prim.CreateDoubleSidedAttr().Set(True)

    # Save binary layer
    stage.GetRootLayer().Save()

    # Package into USDZ
    success = UsdUtils.CreateNewUsdzPackage(Sdf.AssetPath(temp_usdc), usdz_path)
    if os.path.exists(temp_usdc):
        os.remove(temp_usdc)

    elapsed_ms = (time.time() - t0) * 1000.0
    if success:
        size_mb = os.path.getsize(usdz_path) / (1024 * 1024)
        print(f"USDZ Wireframe Export: {usdz_path} ({size_mb:.2f} MB, {elapsed_ms:.1f} ms)")
        return usdz_path
    else:
        print(f"Failed to package USDZ at: {usdz_path}", file=sys.stderr)
        return ""


def main():
    parser = argparse.ArgumentParser(
        description="Generate and render high-resolution polygonal terrain with custom micropoly subdivision knobs.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--polys", "-p", type=int, default=16000, help="Target polygon count (e.g. 2,000, 16,000, 64,000, 250,000, 1,000,000)")
    parser.add_argument(
        "--mode",
        "-m",
        type=str,
        default="fractal",
        choices=["fractal", "adaptive", "depth", "spokes", "redblob"],
        help="Subdivision algorithm: 'fractal' (watertight 2D+3D edge-cached), 'adaptive' (1-to-4 area-priority), 'depth' (uniform 1-to-4), 'spokes' (radial fan), 'redblob' (2-way ridge/valley fold)",
    )
    parser.add_argument("--depth", "-d", type=int, default=1, help="Subdivision depth for 'depth' mode (each level quadruples poly count)")
    parser.add_argument("--height-scale", "--elev-scale", dest="height_scale", type=float, default=70.0, help="Vertical elevation scale in 3D world units (default: 70.0, down from exaggerated 320.0)")
    parser.add_argument("--mountain-sharpness", "--sharpness", dest="mountain_sharpness", type=float, default=1.0, help="Mountain sharpness power exponent (default: 1.0 for Amit's exact curve, >1.0 for sharper peaks / flatter plains)")
    parser.add_argument("--roughness", "-r", type=float, default=3.0, help="Fractal midpoint displacement height roughness")
    parser.add_argument("--lateral-jitter", "-j", type=float, default=0.22, help="2D lateral displacement ratio perpendicular to edges (dissolves straight polygon seams)")
    parser.add_argument("--normal-smooth", type=float, default=0.70, help="Ratio of smoothed vertex normals to micro-facet normals (eliminates stair-step shading)")
    parser.add_argument("--alpha", "-a", type=float, default=0.25, help="Red Blob corner ridge elevation boost alpha")
    parser.add_argument("--quad-fold", dest="quad_fold", action="store_true", default=True, help="Enable dynamic quad folding (v0-v1 for ridges, d0-d1 for river ravines)")
    parser.add_argument("--no-quad-fold", dest="quad_fold", action="store_false", help="Disable dynamic quad folding")
    parser.add_argument("--ridge-noise", type=float, default=0.35, help="Musgrave ridged multifractal roughness factor (0.0 to 1.0)")
    parser.add_argument("--erosion-strength", type=float, default=0.30, help="Hydraulic erosion bedrock carving scale (0.0 to 1.0)")
    parser.add_argument("--erosion-droplets", type=int, default=15000, help="Number of hydraulic erosion simulation particles")
    parser.add_argument("--seed", "-s", type=int, default=777, help="Random seed for map generator")
    parser.add_argument("--points", "-n", type=int, default=1000, help="Number of Voronoi seed points")
    parser.add_argument("--size", type=int, default=1000, help="Render resolution in pixels (width=height)")
    parser.add_argument("--output", "-o", type=str, default="island_output.png", help="Output PNG file path")
    parser.add_argument("--usdz", type=str, default="", help="Optional output path to export 3D wireframe model (.usdz)")
    parser.add_argument("--wire-width", type=float, default=0.8, help="Strut width for 3D wireframe export")
    parser.add_argument("--window", "--gui", action="store_true", help="Launch interactive graphical Mapgen2 GUI explorer")

    args = parser.parse_args()

    if args.window:
        from mapgen_gui import MapgenGUI
        gui = MapgenGUI(seed=args.seed, num_points=args.points, target_polys=args.polys)
        gui.run()
        return

    print(f"\n========================================================")
    print(f"  Polygonal Terrain Micropoly Generator")
    print(f"========================================================")
    print(f"  • Target Polygons : {args.polys:,}")
    print(f"  • Subdivision Mode: {args.mode}")
    print(f"  • World Seed      : {args.seed}")
    print(f"  • Voronoi Points  : {args.points}")
    print(f"  • Height Scale    : {args.height_scale}")
    print(f"  • Sharpness Power : {args.mountain_sharpness}")
    print(f"  • Roughness       : {args.roughness}")
    print(f"  • Lateral Jitter  : {args.lateral_jitter}")
    print(f"  • Normal Smooth   : {args.normal_smooth}")
    print(f"  • Ridge Alpha (α) : {args.alpha}")
    print(f"  • Quad-Folding    : {'ON (Adaptive)' if args.quad_fold else 'OFF'}")
    print(f"  • Ridge Noise     : {args.ridge_noise}")
    print(f"  • Erosion Strength: {args.erosion_strength} ({args.erosion_droplets:,} drops)")
    print(f"  • Resolution      : {args.size} x {args.size}")
    if args.usdz:
        print(f"  • USDZ Wireframe  : {args.usdz}")
    print(f"--------------------------------------------------------")

    t_start = time.time()
    print("Generating base Voronoi dual-mesh & hydrology...")
    gen = PolygonMapGenerator(
        seed=args.seed,
        width=args.size,
        height=args.size,
        num_points=args.points,
        mountain_sharpness=args.mountain_sharpness,
        enable_corner_improvement=True,
        enable_roads=True,
        enable_lava=True,
    )
    t_gen = time.time()

    print(f"Subdividing mesh with '{args.mode}' method...")
    triangles, actual_poly_count = build_island_mesh(
        gen,
        width=args.size,
        height=args.size,
        mode=args.mode,
        target_polys=args.polys,
        subdivision_depth=args.depth,
        roughness=args.roughness,
        lateral_jitter=args.lateral_jitter,
        normal_smooth_ratio=args.normal_smooth,
        elevation_alpha=args.alpha,
        elev_scale=args.height_scale,
        quad_fold=args.quad_fold,
        ridge_noise=args.ridge_noise,
        erosion_strength=args.erosion_strength,
        erosion_droplets=args.erosion_droplets,
    )
    t_subdiv = time.time()

    print(f"Rasterizing {actual_poly_count:,} micropolygons with multi-light shading...")
    surface = render_mesh(gen, triangles, width=args.size, height=args.size)
    t_render = time.time()

    # Save output image
    output_path = os.path.abspath(args.output)
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    pygame.image.save(surface, output_path)

    # Optional 3D USDZ wireframe export
    if args.usdz:
        usdz_out = os.path.abspath(args.usdz)
        export_island_wireframe_usdz(gen, triangles, usdz_out, wire_width=args.wire_width)

    print(f"\n[DONE] Successfully generated {actual_poly_count:,} micropolygons!")
    print(f"  - Map Generation : {(t_gen - t_start)*1000:.1f} ms")
    print(f"  - Subdivision    : {(t_subdiv - t_gen)*1000:.1f} ms")
    print(f"  - Shading/Render : {(t_render - t_subdiv)*1000:.1f} ms")
    print(f"  - Total Elapsed  : {(t_render - t_start)*1000:.1f} ms")
    print(f"  - Saved Image to : {output_path}")
    if args.usdz:
        print(f"  - Saved USDZ to  : {os.path.abspath(args.usdz)}")

    # Also copy to artifact directory if inside antigravity environment
    artifact_dir = "/Users/sli/.gemini/antigravity/brain/11eb900e-54d0-4082-b924-ee19cb7c9759"
    if os.path.isdir(artifact_dir):
        art_path = os.path.join(artifact_dir, "custom_island_render.png")
        pygame.image.save(surface, art_path)
        print(f"  - Artifact Saved : {art_path}")

    print(f"========================================================\n")


if __name__ == "__main__":
    main()
