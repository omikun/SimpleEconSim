"""
ForexDesk — central-bank quote with reserve constraints (Phase 1).

Real-world analog: managed float / Bretton Woods / gold standard.
The central bank (region's bank) quotes a mid rate with a spread and
holds foreign reserves.  Convertibility is hard-capped by available
reserves (can't print foreign currency), and the mid rate adjusts by
reserve pressure (reserve drain -> domestic currency weakens ->
imports become more expensive -> self-correcting).

Phase 3 (interbank order book) can layer on top by quoting inside the
band exposed here (mid / spread / band) without restructuring.
"""
from treasury_trace import begin_public_change as _trace_public_begin, finish_public_change as _trace_public_finish

import math


DESK_FX_POOL_SEED = 2000.0      # domestic money the bank sets aside for FX
DESK_FX_POOL_TARGET_FRAC = 0.15  # mean-revert fx_pool toward 15% of deposits
DESK_TARGET_RESERVES = 2500.0    # desired holdings of each foreign currency
DESK_INITIAL_RESERVES = 3000.0   # war-chest of foreign currency at start
# (raised from 1000/1200: 100-turn runs drained both desks to 0 reserves and
#  pinned the rate at the band ceiling — initial stock was far below the
#  realized trade volume, stalling convertibility)
DESK_ADJ_SPEED = 0.05            # per-turn rate adjustment speed
DESK_SPREAD = 0.02               # round-trip cost fraction (2%)
DESK_BAND = (0.4, 2.5)           # rate bounds (policy floor/ceiling);
# widened from (0.5, 2.0): sustained reserve pressure pinned both desks
# at the ceiling even after damping — more room lets the float express
# relative competitiveness instead of resting on the band wall


def fx_wallets(a):
    """Return a's wallet dict, lazily creating it if needed."""
    w = getattr(a, 'wallets', None)
    if w is None:
        w = {}
        a.wallets = w
    return w


def fx_balance(a, currency):
    """Balance of *currency* in a's wallet (None-safe, no allocation)."""
    w = getattr(a, 'wallets', None)
    return w.get(currency, 0.0) if w else 0.0


def fx_add(a, currency, amount):
    """Add to a's wallet balance; returns new balance. Lazy materialize."""
    if amount == 0:
        return fx_balance(a, currency)
    w = fx_wallets(a)
    w[currency] = w.get(currency, 0.0) + amount


def fx_sub(a, currency, amount):
    """Subtract from a's wallet balance (floored at 0). Returns new balance."""
    if amount == 0:
        return fx_balance(a, currency)
    w = getattr(a, 'wallets', None)
    if w is None:
        return 0.0
    w[currency] = max(0.0, w.get(currency, 0.0) - amount)
    return w[currency]


def fx_clear(a):
    """Drop a's wallet entirely (dead agents, no-heir escheat)."""
    w = getattr(a, 'wallets', None)
    if w is not None:
        w.clear()


def _record_cash_wallet_conversion(a, currency, amount, direction, region,
                                  cash_before, cash_after, wallet_before,
                                  wallet_after, t=None):
    """Journal a same-currency move between an agent's cash and wallet."""
    if region is None or amount <= 0:
        return None
    from economy.actor_accounts import record as record_economic_event
    turn = int(t if t is not None else getattr(region, '_last_turn', 0))
    next_event_id = int(getattr(region, '_next_economic_event_id', 1))
    transfer_id = (f'cash-wallet:{turn}:{region.name}:{a.id}:{currency}:'
                   f'{direction}:{next_event_id}')
    detail = {'transfer_id': transfer_id, 'direction': direction,
              'currency': currency, 'amount': float(amount),
              'cash_before': float(cash_before), 'cash_after': float(cash_after),
              'wallet_before': float(wallet_before),
              'wallet_after': float(wallet_after)}
    if direction == 'cash_to_wallet':
        cash_event = record_economic_event(
            region, 'fx_conversion', turn=turn, payer_id=a.id,
            amount=amount, asset_id=transfer_id, source_id=transfer_id,
            currency=currency, detail=detail)
        wallet_event = record_economic_event(
            region, 'wallet_transfer_in', turn=turn, recipient_id=a.id,
            amount=amount, asset_id=transfer_id, source_id=transfer_id,
            currency=currency, detail=detail)
    else:
        cash_event = record_economic_event(
            region, 'fx_conversion', turn=turn, recipient_id=a.id,
            amount=amount, asset_id=transfer_id, source_id=transfer_id,
            currency=currency, detail=detail)
        wallet_event = record_economic_event(
            region, 'wallet_transfer_out', turn=turn, payer_id=a.id,
            amount=amount, asset_id=transfer_id, source_id=transfer_id,
            currency=currency, detail=detail)
    from run_trace import emit
    emit(region, kind='cash_wallet_conversion', record_class='transfer',
         phase='finance', subject={'type': 'agent', 'id': a.id,
                                   'tile': region.name},
         metric_id='finance.cash_wallet_conversion', unit=currency,
         before=float(cash_before), after=float(cash_after),
         inputs={'direction': direction, 'amount': float(amount),
                 'currency': currency, 'transfer_id': transfer_id,
                 'wallet_before': float(wallet_before),
                 'wallet_after': float(wallet_after),
                 'cash_event': {'tile': region.name,
                                'event_id': cash_event['id']},
                 'wallet_event': {'tile': region.name,
                                  'event_id': wallet_event['id']}})
    return transfer_id


def walletize(a, currency, trace_region=None, t=None):
    """Move an agent's hand cash into its FX wallet for *currency* (v3).

    Wilderness tiles have no bank and no domestic currency, so resident
    homesteaders carry their money in their FX wallet instead of hand cash.
    Conservation: ``a.cash`` falls by exactly the amount added to the wallet,
    so the per-currency audit (which sums every agent's FX wallets across all
    tiles regardless of residence) sees the same total as before conversion.
    """
    cash = a.cash
    if cash > 0:
        cash_before = float(a.cash)
        wallet_before = float(fx_balance(a, currency))
        _trace_cash_write = _trace_public_begin(None, a)
        a.cash = 0.0
        _trace_public_finish(_trace_cash_write, 'forex:walletize',
                             inputs={"source_writer": 'forex.py:walletize:d4797b7b07c8146d:1'})
        fx_add(a, currency, cash)
        _record_cash_wallet_conversion(
            a, currency, cash, 'cash_to_wallet', trace_region,
            cash_before, float(a.cash), wallet_before,
            float(fx_balance(a, currency)), t=t)
    return cash


def decash_wallet(a, currency, trace_region=None, t=None):
    """Move an agent's FX wallet balance for *currency* back to hand cash (v3).

    Inverse of :func:`walletize`.  Used when a wilderness tile is claimed (the
    tile gains a home currency + bank) and when a homesteader migrates onto a
    claimed tile.  Returns the amount moved.
    """
    bal = fx_balance(a, currency)
    if bal > 0:
        cash_before = float(a.cash)
        wallet_before = float(bal)
        fx_sub(a, currency, bal)
        _trace_cash_write = _trace_public_begin(None, a)
        a.cash += bal
        _trace_public_finish(_trace_cash_write, 'forex:decash_wallet',
                             inputs={"source_writer": 'forex.py:decash_wallet:a8b4369053f8e4ae:1'})
        _record_cash_wallet_conversion(
            a, currency, bal, 'wallet_to_cash', trace_region,
            cash_before, float(a.cash), wallet_before,
            float(fx_balance(a, currency)), t=t)
    return bal


class ForexDesk:
    """A region's central-bank FX desk quoting home<->foreign rates.

    Convention: ``mid`` is *home units per 1 unit of foreign* currency.
    So for Region_A with partner Region_B, ``mid = 1.2`` means 1 B buys 1.2 A.
    """

    def __init__(self, home_currency, other_currency, bank=None, *,
                 mid=1.0, spread=DESK_SPREAD,
                 target_reserves=DESK_TARGET_RESERVES,
                 initial_reserves=DESK_INITIAL_RESERVES,
                 adj_speed=DESK_ADJ_SPEED, band=DESK_BAND,
                 seed_reserves=True):
        self.home = home_currency
        self.other = other_currency
        self.bank = bank
        self.mid = float(mid)
        self.spread = float(spread)
        self.target_reserves = float(target_reserves)
        self.adj_speed = float(adj_speed)
        self.band = band
        self.ppp_target = 1.0  # PPP anchor: home basket / foreign basket
        self.log = []  # (t, mid, reserves) history
        # Interbank order book (Phase 3): entries are
        #   {'kind': 'bid'|'ask', 'trader': trader, 'qty': float, 'rate': float}
        self.book = []
        if bank is not None and seed_reserves:
            self._seed_bank(bank, initial_reserves)

    def post_order(self, kind, trader, qty, rate):
        """Post a bid (buy foreign) or ask (sell foreign) to this desk's book."""
        if qty <= 0 or rate <= 0:
            return 0.0
        self.book.append({'kind': kind, 'trader': trader, 'qty': qty,
                          'rate': rate})
        return qty

    def clear_book(self, trace_region=None, t=None):
        """Match crossed orders inside the bank's rate band.

        A bid (buy foreign) at rate B crosses an ask (sell foreign) at rate A
        when B >= A.  Matching transfers foreign between the two traders'
        wallets bilaterally, and home cash between them:  the bidder pays
        (qty * A) home cash to the asker, both in home currency.  This is
        conservation-safe (home cash moves home-cash; foreign wallet moves
        foreign wallet).  Uses the ASK's rate A as the trade price so the
        bidder gets the more favorable fill for the market maker.
        Returns total home value matched.
        """
        total_home = 0.0
        bids = [o for o in self.book if o['kind'] == 'bid']
        asks = [o for o in self.book if o['kind'] == 'ask']
        # Sort: highest bids first, lowest asks first (best price)
        bids.sort(key=lambda o: -o['rate'])
        asks.sort(key=lambda o: o['rate'])
        i = j = 0
        match_index = 0
        _heartbeat = len(bids) + len(asks) + 1  # defensive: every iteration
        # must advance at least one pointer; cap anyway to avoid deadlock
        while i < len(bids) and j < len(asks) and _heartbeat > 0:
            _heartbeat -= 1
            b = bids[i]
            a = asks[j]
            if b['rate'] < a['rate']:
                i += 1
                continue  # no cross; move to next bid
            price = a['rate']  # match at ask rate
            btrader = b['trader']
            atrader = a['trader']
            # Cap the match by the asker's ACTUAL wallet balance (the posted
            # qty may exceed it if the ask persisted across turns while the
            # trader's wallet shrank).  Also cap by the bidder's home cash.
            avail_foreign = fx_balance(atrader, self.other)
            qty = min(b['qty'], a['qty'], avail_foreign)
            if qty <= 0:
                j += 1
                continue
            home = qty * price
            if btrader.cash < home:
                home = btrader.cash
                qty = home / price if price > 0 else 0.0
            if qty <= 0:
                i += 1
                continue
            # Home leg (both are home-region traders)
            buyer_cash_before = float(btrader.cash)
            seller_cash_before = float(atrader.cash)
            buyer_wallet_before = fx_balance(btrader, self.other)
            _trace_cash_write = _trace_public_begin(None, btrader)
            btrader.cash -= home
            _trace_public_finish(_trace_cash_write, 'forex:ForexDesk.clear_book',
                                 inputs={"source_writer": 'forex.py:ForexDesk.clear_book:78b57e589f1c9a90:1'})
            _trace_cash_write = _trace_public_begin(None, atrader)
            atrader.cash += home
            _trace_public_finish(_trace_cash_write, 'forex:ForexDesk.clear_book',
                                 inputs={"source_writer": 'forex.py:ForexDesk.clear_book:4f50702f8f4067c2:1'})
            # Foreign leg: transfer exactly what fx_sub actually removes
            before = fx_balance(atrader, self.other)
            fx_sub(atrader, self.other, qty)
            moved = before - fx_balance(atrader, self.other)
            fx_add(btrader, self.other, moved)
            buyer_wallet_after = fx_balance(btrader, self.other)
            seller_wallet_after = fx_balance(atrader, self.other)
            transfer_id = (
                f'fx-order:{int(t if t is not None else getattr(trace_region, "_last_turn", 0))}:'
                f'{getattr(trace_region, "name", self.home)}:{self.home}:{self.other}:'
                f'{match_index}:{btrader.id}:{atrader.id}')
            match_index += 1
            cash_event = wallet_out_event = wallet_in_event = None
            if trace_region is not None:
                from economy.actor_accounts import record as record_economic_event
                turn = int(t if t is not None else getattr(trace_region, '_last_turn', 0))
                cash_event = record_economic_event(
                    trace_region, 'fx_order_cash_transfer', turn=turn,
                    payer_id=btrader.id, recipient_id=atrader.id, amount=home,
                    asset_id=transfer_id, source_id=transfer_id,
                    currency=self.home,
                    detail={'transfer_id': transfer_id,
                            'buyer_id': btrader.id, 'seller_id': atrader.id,
                            'foreign_currency': self.other,
                            'foreign_quantity': float(moved),
                            'home_price_per_foreign': float(price),
                            'home_paid': float(home),
                            'tender': 'bilateral_fx_order'})
                wallet_out_event = record_economic_event(
                    trace_region, 'wallet_transfer_out', turn=turn,
                    payer_id=atrader.id, amount=moved,
                    asset_id=transfer_id, source_id=transfer_id,
                    currency=self.other,
                    detail={'transfer_id': transfer_id,
                            'payment_kind': 'fx_order_match',
                            'counterparty_id': btrader.id,
                            'foreign_quantity': float(moved),
                            'home_paid': float(home),
                            'home_currency': self.home})
                wallet_in_event = record_economic_event(
                    trace_region, 'wallet_transfer_in', turn=turn,
                    recipient_id=btrader.id, amount=moved,
                    asset_id=transfer_id, source_id=transfer_id,
                    currency=self.other,
                    detail={'transfer_id': transfer_id,
                            'payment_kind': 'fx_order_match',
                            'counterparty_id': atrader.id,
                            'foreign_quantity': float(moved),
                            'home_paid': float(home),
                            'home_currency': self.home})
            if trace_region is not None:
                from run_trace import emit
                emit(trace_region, kind='fx_order_match', record_class='transfer',
                     phase='trade', subject={'type': 'fx_desk', 'id': trace_region.name,
                                             'base_currency': self.home,
                                             'quote_currency': self.other},
                     metric_id='trade.fx_order_match', unit=self.home,
                     inputs={'buyer_id': btrader.id, 'seller_id': atrader.id,
                             'foreign_quantity': moved, 'home_price_per_foreign': price,
                             'home_paid': home, 'bid_rate': b['rate'],
                             'ask_rate': a['rate'],
                             'transfer_id': transfer_id,
                             'buyer_cash_before': buyer_cash_before,
                             'buyer_cash_after': float(btrader.cash),
                             'seller_cash_before': seller_cash_before,
                             'seller_cash_after': float(atrader.cash),
                             'buyer_wallet_before': float(buyer_wallet_before),
                             'buyer_wallet_after': float(buyer_wallet_after),
                             'seller_wallet_before': float(before),
                             'seller_wallet_after': float(seller_wallet_after),
                             'cash_event': {'tile': trace_region.name,
                                            'event_id': cash_event['id']},
                             'wallet_out_event': {'tile': trace_region.name,
                                                  'event_id': wallet_out_event['id']},
                             'wallet_in_event': {'tile': trace_region.name,
                                                 'event_id': wallet_in_event['id']}})
            total_home += moved * price
            b['qty'] -= moved
            a['qty'] -= moved
            if a['qty'] <= 0 or fx_balance(atrader, self.other) <= 0:
                j += 1
            if b['qty'] <= 0:
                i += 1
        self.book = [o for o in self.book if o['qty'] > 0]
        return total_home

    def _seed_bank(self, bank, initial_reserves):
        """Seed the bank's foreign-reserve war chest + domestic FX pool."""
        if initial_reserves > 0:
            bank.foreign_reserves.setdefault(self.other, float(initial_reserves))
        if bank.fx_pool <= 0 and DESK_FX_POOL_SEED > 0:
            bank.fx_pool = DESK_FX_POOL_SEED

    # ------------------------------------------------------------------
    # Quotes
    # ------------------------------------------------------------------

    def buy_rate(self):
        """Home units a trader receives per 1 unit of foreign (trader sells FX)."""
        return self.mid * (1.0 - self.spread / 2.0)

    def sell_rate(self):
        """Home units a trader must pay per 1 unit of foreign (trader buys FX)."""
        return self.mid * (1.0 + self.spread / 2.0)

    def expected_repatriate_rate(self):
        """Rate traders expect when converting foreign earnings home."""
        return self.buy_rate()

    def save_rate(self, region):
        """Sync this desk's mid into the region's legacy exchange_rate field."""
        region.exchange_rate = self.mid
        return self.mid

    # ------------------------------------------------------------------
    # Reserve-pressure update (managed float)
    # ------------------------------------------------------------------

    def update(self, t, bank=None, fx_regime='managed', ppp_target=None,
               trace_region=None):
        """Adjust mid from reserve pressure and record history.

        *fixed*: mid pinned at 1.0 (parity) — convertibility still reserve-capped.
        *managed* (default): mid moved by reserve-pressure rule.
        *floating*: Phase 3 order book; for now behaves like managed.

        Phase 6: log-space capped step (the old multiplicative update
        compounded past the band once a desk drained) + a slow PPP anchor so
        the rate tracks relative basket costs instead of drifting to the band.
        """
        bank = bank if bank is not None else self.bank
        if bank is None:
            return self.mid
        old_mid = self.mid

        # Mean-revert the domestic FX pool toward a fraction of deposits so
        # the desk doesn't permanently exhaust its ability to pay out.
        deposits = max(0.0, bank.total_deposits)
        target_pool = deposits * DESK_FX_POOL_TARGET_FRAC
        if False:
            bank.fx_pool += 0.0

        reserves = bank.foreign_reserves.get(self.other, 0.0)
        ratio = reserves / self.target_reserves if self.target_reserves > 0 else 1.0
        pressure = 0.0
        ppp_gap = 0.0
        pre_band = self.mid

        if fx_regime == 'fixed':
            self.mid = 1.0
        else:
            # Drain (ratio < 1) -> foreign scarce -> mid up (home weakens),
            # discouraging imports and encouraging exports / repatriation.
            # Log-space BOUNDED step: can't overshoot the band in one turn.
            pressure = self.adj_speed * (1.0 / max(0.05, ratio) - 1.0)
            pressure = max(-0.02, min(0.02, pressure))
            new_mid = self.mid * math.exp(pressure)
            # PPP anchor: slow pull toward partner/home basket-cost ratio.
            if ppp_target is not None and ppp_target > 0:
                self.ppp_target = ppp_target
            if self.ppp_target > 0:
                ppp_gap = math.log(self.ppp_target / max(0.01, self.mid))
                new_mid *= math.exp(0.005 * ppp_gap)
            pre_band = new_mid
            self.mid = max(self.band[0], min(self.band[1], new_mid))

        self.log.append((t, self.mid, reserves))
        if trace_region is not None:
            from run_trace import emit
            emit(trace_region, kind='fx_mid_update', record_class='calculation',
                 subject={'type': 'fx_desk', 'id': trace_region.name,
                          'base_currency': self.home, 'quote_currency': self.other},
                 metric_id='fx.bilateral_mid', unit='home_currency_per_foreign_currency',
                 before=old_mid, after=self.mid, formula_id='forex.reserve_ppp.v1',
                 inputs={'regime': fx_regime, 'adjustment_speed': self.adj_speed, 'domestic_fx_pool': bank.fx_pool,
                         'deposits': deposits, 'target_pool': target_pool,
                         'partner_reserves': reserves, 'target_reserves': self.target_reserves,
                         'reserve_ratio': ratio, 'pressure_term': pressure,
                         'ppp_target': self.ppp_target, 'ppp_gap': ppp_gap,
                         'pre_band_mid': pre_band},
                 constraints={'band': list(self.band),
                              'active': 'fixed_parity' if fx_regime == 'fixed' else
                              ('lower_band' if pre_band < self.band[0] else
                               'upper_band' if pre_band > self.band[1] else None)})
        return self.mid


# =============================================================================
# Bank-level conversion (booked on the Bank for conservation transparency)
# =============================================================================

def sell_fx_to_bank(bank, trader, currency, amount, rate, trace_region=None):
    """Trader sells *currency* (foreign) to the bank; bank pays home currency.

    Constraint: bank's domestic FX pool (fx_pool) caps the payout.
    Conservation: trader wallet -foreign; bank foreign_reserves +foreign;
    bank fx_pool -home; trader cash +home.  Both currencies conserved.
    Returns home amount actually paid.
    """
    requested = amount
    trader_cash_before = trader.cash
    trader_fx_before = fx_balance(trader, currency)
    pool_before = bank.fx_pool
    reserves_before = bank.foreign_reserves.get(currency, 0.0)
    amount = min(amount, trader_fx_before)
    if amount <= 0:
        return 0.0
    home = amount * rate
    max_pay = max(0.0, bank.fx_pool)
    if home > max_pay:
        home = max_pay
        amount = home / rate if rate > 0 else 0.0
    if amount <= 0:
        return 0.0
    fx_sub(trader, currency, amount)
    bank.foreign_reserves[currency] += amount
    bank.fx_pool -= home
    _trace_cash_write = _trace_public_begin(None, trader)
    trader.cash += home
    _trace_public_finish(_trace_cash_write, 'forex:sell_fx_to_bank',
                         inputs={"source_writer": 'forex.py:sell_fx_to_bank:824d3160762dd808:1'})
    if trace_region is not None:
        from economy.actor_accounts import record as record_economic_event
        record_economic_event(trace_region, 'fx_conversion', turn=getattr(trace_region, '_last_turn', 0),
                              recipient_id=trader.id, amount=home,
                              currency=trace_region.home_currency,
                              detail={'direction': 'sell_foreign', 'foreign_currency': currency,
                                      'foreign_amount': amount, 'rate_home_per_foreign': rate,
                                      'bank_fx_pool_delta': -home})
        from run_trace import emit
        emit(trace_region, kind='fx_conversion_executed', record_class='transfer',
             phase='trade', subject={'type': 'agent', 'id': trader.id, 'tile': trace_region.name},
             metric_id='trade.fx_conversion', unit=currency,
             before=trader_fx_before, after=fx_balance(trader, currency),
             formula_id='forex.bank_conversion.v1',
             inputs={'direction': 'sell_foreign', 'foreign_currency': currency,
                     'home_currency': trace_region.home_currency,
                     'requested_foreign': requested, 'executed_foreign': amount,
                     'rate_home_per_foreign': rate, 'home_paid': home,
                     'trader_cash_before': trader_cash_before, 'trader_cash_after': trader.cash,
                     'trader_fx_before': trader_fx_before,
                     'trader_fx_after': fx_balance(trader, currency),
                     'bank_fx_pool_before': pool_before, 'bank_fx_pool_after': bank.fx_pool,
                     'bank_foreign_reserves_before': reserves_before,
                     'bank_foreign_reserves_after': bank.foreign_reserves[currency]})
    return home


def buy_fx_from_bank(bank, trader, currency, amount, rate, trace_region=None):
    """Trader buys *currency* (foreign) from the bank, paying home currency.

    Constraint: bank's foreign reserves cap the sale.
    Returns amount of foreign currency actually bought.
    """
    requested = amount
    trader_cash_before = trader.cash
    trader_fx_before = fx_balance(trader, currency)
    pool_before = bank.fx_pool
    reserves_before = bank.foreign_reserves.get(currency, 0.0)
    amount = min(amount, reserves_before)
    if amount <= 0:
        return 0.0
    home = amount * rate
    if trader.cash < home:
        home = trader.cash
        amount = home / rate if rate > 0 else 0.0
    if amount <= 0:
        return 0.0
    fx_add(trader, currency, amount)
    bank.foreign_reserves[currency] -= amount
    bank.fx_pool += home
    _trace_cash_write = _trace_public_begin(None, trader)
    trader.cash -= home
    _trace_public_finish(_trace_cash_write, 'forex:buy_fx_from_bank',
                         inputs={"source_writer": 'forex.py:buy_fx_from_bank:8403a5dbc0964db3:1'})
    if trace_region is not None:
        from economy.actor_accounts import record as record_economic_event
        record_economic_event(trace_region, 'fx_conversion', turn=getattr(trace_region, '_last_turn', 0),
                              payer_id=trader.id, amount=home,
                              currency=trace_region.home_currency,
                              detail={'direction': 'buy_foreign', 'foreign_currency': currency,
                                      'foreign_amount': amount, 'rate_home_per_foreign': rate,
                                      'bank_fx_pool_delta': home})
        from run_trace import emit
        emit(trace_region, kind='fx_conversion_executed', record_class='transfer',
             phase='trade', subject={'type': 'agent', 'id': trader.id, 'tile': trace_region.name},
             metric_id='trade.fx_conversion', unit=currency,
             before=trader_fx_before, after=fx_balance(trader, currency),
             formula_id='forex.bank_conversion.v1',
             inputs={'direction': 'buy_foreign', 'foreign_currency': currency,
                     'home_currency': trace_region.home_currency,
                     'requested_foreign': requested, 'executed_foreign': amount,
                     'rate_home_per_foreign': rate, 'home_paid': home,
                     'trader_cash_before': trader_cash_before, 'trader_cash_after': trader.cash,
                     'trader_fx_before': trader_fx_before,
                     'trader_fx_after': fx_balance(trader, currency),
                     'bank_fx_pool_before': pool_before, 'bank_fx_pool_after': bank.fx_pool,
                     'bank_foreign_reserves_before': reserves_before,
                     'bank_foreign_reserves_after': bank.foreign_reserves[currency]})
    return amount


# =============================================================================
# Per-trader repatriation
# =============================================================================

def repatriate_trader(trader, region, t):
    """Convert a trader's foreign wallet back to home currency at region's desk.

    Returns home-currency value repatriated (and credited to _trader_revenue).
    """
    desk = getattr(region, 'forex', None)
    if desk is None or not getattr(trader, 'is_trader', False):
        return 0.0
    bal = fx_balance(trader, desk.other)
    if bal <= 0:
        return 0.0
    rate = desk.buy_rate()
    home = sell_fx_to_bank(region.bank, trader, desk.other, bal, rate, region)
    if home > 0:
        trader._trader_revenue += home
        return home
    return 0.0


def repatriate_traders(agents, region, t):
    """Repatriate all traders in *agents* belonging to *region*.

    Called at the end of foreign_sell so every audit point sees wallets ~ 0.
    Returns total home value repatriated.
    """
    total = 0.0
    for a in agents:
        if not getattr(a, 'is_trader', False):
            continue
        total += repatriate_trader(a, region, t)
    return total


def convert_non_trader_wallets(agents, region, t=0):
    """Convert foreign-currency wallet balances held by non-trader citizens to home cash.

    Uses the region bank's ForexDesks up to available bank fx_pool.
    Conservation-safe: citizen wallet -foreign, bank reserves +foreign,
    bank fx_pool -home, citizen cash +home.
    """
    bank = getattr(region, 'bank', None)
    if bank is None:
        return 0.0
    home_currency = getattr(region, 'home_currency', None)
    if home_currency is None:
        return 0.0
    total_converted = 0.0
    desks = getattr(region, 'forex_desks', {})
    for a in agents:
        if getattr(a, 'is_trader', False) or getattr(a, 'is_government', False):
            continue
        w = getattr(a, 'wallets', None)
        if not w:
            continue
        for foreign_cur, bal in list(w.items()):
            if foreign_cur == home_currency:
                decash_wallet(a, home_currency, trace_region=region, t=t)
                continue
            if bal <= 0:
                continue
            # Look for an active ForexDesk for this partner currency
            rate = 1.0 * (1.0 - DESK_SPREAD / 2.0)
            if desks:
                for desk in desks.values():
                    if getattr(desk, 'other', None) == foreign_cur:
                        rate = desk.buy_rate()
                        break
            elif getattr(region, 'forex', None) is not None and region.forex.other == foreign_cur:
                rate = region.forex.buy_rate()

            paid = sell_fx_to_bank(bank, a, foreign_cur, bal, rate, region)
            total_converted += paid
    return total_converted


# =============================================================================
# Setup + per-currency audit
# =============================================================================

def connect_regions(region_a, region_b, t=0):
    """Wire up bilateral ForexDesks between two regions.

    Creates a desk on each region (home=own, other=partner), seeds reserves
    and FX pools, and returns (desk_a, desk_b).
    """
    desk_a = ForexDesk(region_a.home_currency, region_b.home_currency,
                       bank=region_a.bank)
    desk_b = ForexDesk(region_b.home_currency, region_a.home_currency,
                       bank=region_b.bank)
    region_a.forex = desk_a
    region_b.forex = desk_b
    seed_trader_wallet(region_a, region_b, t)
    seed_trader_wallet(region_b, region_a, t)
    return desk_a, desk_b


def _give_working_capital(trader, bank, currency, amount, rate,
                          trace_region=None, t=None):
    """Trader buys *amount* of foreign *currency* from its home bank.

    Conservation-safe replacement for the old free seed: home money moves
    from the trader's deposit into the bank's fx_pool, and foreign money
    moves from the bank's reserves into the trader's wallet.  Both
    currencies are conserved; nothing is printed.
    Returns foreign amount actually obtained.
    """
    if amount <= 0:
        return 0.0
    cash_before = float(trader.cash)
    deposit_before = float(bank.deposits.get(trader, 0.0))
    wallet_before = float(fx_balance(trader, currency))
    fx_pool_before = float(bank.fx_pool)
    reserves_before = float(bank.foreign_reserves.get(currency, 0.0))
    amount = min(amount, bank.foreign_reserves.get(currency, 0.0))
    if amount <= 0:
        return 0.0
    home = amount * rate
    max_home = bank.deposits.get(trader, 0) + trader.cash
    if home > max_home:
        home = max_home
        amount = home / rate if rate > 0 else 0.0
    if amount <= 0:
        return 0.0
    # Home leg: draw from trader deposit first, then cash
    from_deposit = min(home, bank.deposits.get(trader, 0))
    if from_deposit > 0:
        from bank_trace import begin_change, finish_change
        bank_trace_change = begin_change(bank, trace_region)
        bank.total_deposits -= from_deposit
        finish_change(bank, bank_trace_change, 'trader_fx_float_deposit_debit',
                      inputs={'agent_id': trader.id, 'deposit_paid': from_deposit, 'foreign_currency': currency, 'foreign_amount': amount})
        bank.deposits[trader] -= from_deposit
    home_cash = home - from_deposit
    if home_cash > 0:
        _trace_cash_write = _trace_public_begin(None, trader)
        trader.cash -= home_cash
        _trace_public_finish(_trace_cash_write, 'forex:_give_working_capital',
                             inputs={"source_writer": 'forex.py:_give_working_capital:aec9dce3cf871e0b:1'})
    bank.fx_pool += home
    # Foreign leg: reserves -> wallet
    bank.foreign_reserves[currency] -= amount
    fx_add(trader, currency, amount)
    if trace_region is not None:
        from economy.actor_accounts import record as record_economic_event
        turn = int(t if t is not None else getattr(trace_region, '_last_turn', 0))
        next_event_id = int(getattr(trace_region, '_next_economic_event_id', 1))
        transfer_id = (f'trader-float:{turn}:{trace_region.name}:'
                       f'{trader.id}:{currency}:{next_event_id}')
        detail = {
            'transfer_id': transfer_id, 'direction': 'seed_foreign_float',
            'payment_kind': 'initial_trader_working_capital',
            'home_currency': getattr(trace_region, 'home_currency', None),
            'foreign_currency': currency, 'foreign_amount': float(amount),
            'home_amount': float(home), 'rate_home_per_foreign': float(rate),
            'cash_paid': float(home_cash), 'deposit_paid': float(from_deposit),
            'trader_cash_before': cash_before,
            'trader_cash_after': float(trader.cash),
            'trader_deposit_before': deposit_before,
            'trader_deposit_after': float(bank.deposits.get(trader, 0.0)),
            'trader_wallet_before': wallet_before,
            'trader_wallet_after': float(fx_balance(trader, currency)),
            'bank_fx_pool_before': fx_pool_before,
            'bank_fx_pool_after': float(bank.fx_pool),
            'bank_foreign_reserves_before': reserves_before,
            'bank_foreign_reserves_after': float(
                bank.foreign_reserves.get(currency, 0.0)),
        }
        cash_event = None
        if home_cash > 0:
            cash_event = record_economic_event(
                trace_region, 'fx_conversion', turn=turn,
                payer_id=trader.id, amount=home_cash,
                asset_id=transfer_id, source_id=transfer_id,
                currency=getattr(trace_region, 'home_currency', None),
                detail={**detail, 'home_tender': 'hand_cash'})
        deposit_event = None
        if from_deposit > 0:
            deposit_event = record_economic_event(
                trace_region, 'bank_fx_deposit_conversion', turn=turn,
                payer_id=trader.id, amount=from_deposit,
                asset_id=transfer_id, source_id=transfer_id,
                currency=getattr(trace_region, 'home_currency', None),
                detail={**detail, 'home_tender': 'bank_deposit'})
        wallet_event = record_economic_event(
            trace_region, 'wallet_transfer_in', turn=turn,
            recipient_id=trader.id, amount=amount,
            asset_id=transfer_id, source_id=transfer_id,
            currency=currency, detail=detail)
        trace_record = {
            'kind': 'fx_trader_float_seeded', 'record_class': 'transfer',
            'phase': 'setup',
            'subject': {'type': 'agent', 'id': trader.id,
                        'tile': trace_region.name},
            'metric_id': 'trade.fx_trader_float', 'unit': currency,
            'before': wallet_before,
            'after': float(fx_balance(trader, currency)),
            'formula_id': 'fx.trader_float.funded.v1',
            'inputs': {
                **detail,
                'cash_event': {'tile': trace_region.name,
                               'event_id': cash_event['id']} if cash_event else None,
                'deposit_event': {'tile': trace_region.name,
                                 'event_id': deposit_event['id']} if deposit_event else None,
                'wallet_event': {'tile': trace_region.name,
                                 'event_id': wallet_event['id']}}}
        from run_trace import emit
        if emit(trace_region, **trace_record) is None:
            pending = getattr(trace_region, '_pending_trader_float_traces', [])
            pending.append(trace_record)
            trace_region._pending_trader_float_traces = pending
    return amount


def seed_trader_wallet(region, partner, t=0, desk=None):
    """Give each trader an initial foreign float OUT OF WORKING CAPITAL.

    The old _seed_trader_wallets printed 100 of partner currency per trader
    out of thin air.  Now traders buy their float from the home bank:
      home deposit/cash -> fx_pool  (home currency conserved)
      reserves -> wallet            (foreign currency conserved)

    *desk* selects the conversion desk (defaults to region.forex).  In a
    multi-neighbor world each trader may float in several partner currencies,
    so callers pass the per-partner desk.

    Returns total foreign amount seeded.
    """
    desk = desk if desk is not None else region.forex
    total = 0.0
    for a in region.agents:
        if not getattr(a, 'is_trader', False):
            continue
        total += _give_working_capital(
            a, region.bank, partner.home_currency, 100.0, desk.sell_rate(),
            trace_region=region, t=t)
    return total


def flush_pending_trader_float_traces(region):
    """Write setup float records once the live recorder and clock are attached."""
    pending = list(getattr(region, '_pending_trader_float_traces', ()))
    if not pending:
        return 0
    from run_trace import emit
    written = 0
    for trace_record in pending:
        if emit(region, **trace_record) is not None:
            written += 1
    if written == len(pending):
        region._pending_trader_float_traces = []
    return written


def connect_desks(region, partner, t=0):
    """Wire a bilateral desk pair for a multi-neighbor setup.

    Creates a ForexDesk on each region (home=own, other=partner), stores it
    in the region's ``forex_desks[partner.name]``, seeds trader wallets with
    the partner currency, and — when the partner is the region's primary
    ``destination_region`` — keeps the legacy ``region.forex`` alias in sync.
    Returns (desk_region, desk_partner).
    """
    seed = (t == 0)
    init_res = DESK_INITIAL_RESERVES if seed else 0.0
    desk = ForexDesk(region.home_currency, partner.home_currency,
                     bank=region.bank, initial_reserves=init_res,
                     seed_reserves=seed)
    pdesk = ForexDesk(partner.home_currency, region.home_currency,
                      bank=partner.bank, initial_reserves=init_res,
                      seed_reserves=seed)
    region.forex_desks[partner.name] = desk
    partner.forex_desks[region.name] = pdesk
    if getattr(region, 'destination_region', None) is partner:
        region.forex = desk
    if getattr(partner, 'destination_region', None) is region:
        partner.forex = pdesk
    if seed:
        seed_trader_wallet(region, partner, t, desk=desk)
        seed_trader_wallet(partner, region, t, desk=pdesk)
    return desk, pdesk


def audit_currency_total(regions, currency):
    """Total global supply of *currency* across all agents, banks, reserves.

    Conservation invariant: each currency's total is unchanged by trade and
    FX conversion (fx_pool pays out home money only; reserves just shift
    foreign money between holders).

    v3 provinces: several tiles may SHARE one bank / one charity (via an
    InstitutionBundle).  Counting ``bank.equity``/``fx_pool``/reserves or
    ``charity.agent.cash`` on EVERY member tile would double-count the shared
    institution — a phantom SUPPLY SHIFT.  Each distinct bank/charity is
    therefore counted ONCE (id()-seen set).  In the legacy 1:1 layout every
    id appears exactly once, so behavior is byte-identical.
    """
    total = 0.0
    seen_banks = set()
    seen_charities = set()
    seen_reserves = set()
    for r in regions:
        bank = getattr(r, 'bank', None)
        if r.home_currency == currency:
            total += sum(a.cash for a in r.agents)
            if bank is not None and id(bank) not in seen_banks:
                seen_banks.add(id(bank))
                total += bank.equity
                total += bank.fx_pool
            charity = getattr(r, 'charity', None)
            if charity is not None and id(charity) not in seen_charities:
                seen_charities.add(id(charity))
                total += charity.agent.cash
        # Foreign currency held by this region's agents (wallets)
        total += sum(fx_balance(a, currency) for a in r.agents)
        # Foreign currency held by this region's bank (reserves) — once per bank
        # per CURRENCY (runs for every currency, unlike the home-equity block).
        if bank is not None and id(bank) not in seen_reserves:
            seen_reserves.add(id(bank))
            total += bank.foreign_reserves.get(currency, 0.0)

    # Multi-tier Fiscal Federalism: National Sovereign and Provincial treasuries
    seen_gov_agents = set()
    for r in regions:
        for a in r.agents:
            seen_gov_agents.add(id(a))

    seen_sovereign_govs = set()
    for r in regions:
        owner = getattr(r, 'owner_nation', None)
        nat_gov = getattr(owner, 'government', None) if owner else None
        if nat_gov is not None and id(nat_gov) not in seen_sovereign_govs:
            seen_sovereign_govs.add(id(nat_gov))
            nat_agent = getattr(nat_gov, 'agent', None)
            if nat_agent is not None and id(nat_agent) not in seen_gov_agents:
                seen_gov_agents.add(id(nat_agent))
                gov_cur = getattr(nat_gov, 'currency', getattr(owner, 'currency', None))
                if gov_cur == currency:
                    total += nat_agent.cash
                total += sum(fx_balance(nat_agent, currency) for _ in [0])

        prov = getattr(r, 'province', None)
        prov_gov = getattr(prov, 'gov', None) if prov else None
        if prov_gov is not None and id(prov_gov) not in seen_sovereign_govs:
            seen_sovereign_govs.add(id(prov_gov))
            prov_agent = getattr(prov_gov, 'agent', None)
            if prov_agent is not None and id(prov_agent) not in seen_gov_agents:
                seen_gov_agents.add(id(prov_agent))
                gov_cur = getattr(prov_gov, 'currency', getattr(prov, 'currency', None))
                if gov_cur == currency:
                    total += prov_agent.cash
                total += sum(fx_balance(prov_agent, currency) for _ in [0])

    return total


# =============================================================================
# Phase 3: interbank market cycle (bids + clear + desk last resort)
# =============================================================================

WORKING_CAPITAL_TARGET = 100.0  # desired foreign float per trader


def set_working_capital_target(amount):
    """Globally adjust the per-trader foreign working-capital target."""
    global WORKING_CAPITAL_TARGET
    WORKING_CAPITAL_TARGET = float(amount)


def cycle_market(region_a, region_b, t=0):
    """Run one interbank market cycle across both desks.

    For each desk:
      * post a BID for each home trader's working-capital shortfall of the
        other currency (bounded by cash they can actually pay),
      * clear_book() matches crossing bids/asks wallet-to-wallet (conserved),
      * residual ASKs are repatriated by the desk (fx_pool-capped) — desk as
        market-maker of last resort,
      * residual BIDs buy from the desk's foreign reserves (reserve-capped).

    Conservation: book matches move home cash trader-to-trader and foreign
    wallet-to-wallet; desk legs use the existing reserve-capped conversions.
    Returns {'Region_A': value, 'Region_B': value} matched per desk.
    """
    result = {}

    for region, partner in ((region_a, region_b), (region_b, region_a)):
        desk = getattr(region, 'forex', None)
        if desk is None:
            continue
        other = partner.home_currency
        bank = region.bank

        # ---- Post working-capital BIDs (buy foreign to fund travel) ----
        for trader in region.trader_agents:
            if trader.home_region != region.name:
                continue
            cur_bal = fx_balance(trader, other)
            shortfall = max(0.0, WORKING_CAPITAL_TARGET - cur_bal)
            if shortfall <= 0:
                continue
            rate = desk.sell_rate()
            affordable = trader.cash / rate if rate > 0 else 0.0
            qty = min(shortfall, affordable)
            if qty > 0:
                desk.post_order('bid', trader, qty, rate)

        # ---- Clear the book (wallet-to-wallet, conserved) ----
        matched = desk.clear_book(region, t=t)
        result[region.name] = matched

        # ---- Desk last resort: repatriate residual asks ----
        repatriate_traders(region.trader_agents, region, t)

        # ---- Desk last resort: fill residual bids from reserves ----
        for order in list(desk.book):
            if order['kind'] != 'bid':
                continue
            trader = order['trader']
            qty = order['qty']
            if qty <= 0:
                continue
            bought = buy_fx_from_bank(bank, trader, other, qty,
                                      desk.sell_rate(), region)
            if bought > 0:
                order['qty'] -= bought
        # Drop fully-filled bids and STALE asks (trader's wallet was drained
        # by repatriation this same turn, so those asks can never fill).
        # Without this, foreign_sell stacks a fresh ask per turn and the book
        # grows without bound -> O(T^2) hang.
        desk.book = [o for o in desk.book
                     if o['qty'] > 0 and o['kind'] == 'ask'
                     and fx_balance(o['trader'], other) > 0]

    return result


def _cycle_one_desk(region, partner, desk, t):
    """Run one desk's interbank cycle for region<->partner.

    Shared by cycle_market (legacy single-partner) and cycle_all_markets
    (multi-neighbor).  See cycle_market docstring for mechanics.
    Returns home value matched on this desk.
    """
    other = partner.home_currency
    bank = region.bank

    # ---- Post working-capital BIDs (buy foreign to fund travel) ----
    for trader in region.trader_agents:
        if trader.home_region != region.name:
            continue
        cur_bal = fx_balance(trader, other)
        shortfall = max(0.0, WORKING_CAPITAL_TARGET - cur_bal)
        if shortfall <= 0:
            continue
        rate = desk.sell_rate()
        affordable = trader.cash / rate if rate > 0 else 0.0
        qty = min(shortfall, affordable)
        if qty > 0:
            desk.post_order('bid', trader, qty, rate)

    # ---- Clear the book (wallet-to-wallet, conserved) ----
    matched = desk.clear_book(region, t=t)

    # ---- Desk last resort: repatriate residual asks ----
    for trader in region.trader_agents:
        if trader.home_region != region.name:
            continue
        bal = fx_balance(trader, other)
        if bal > 0:
            rate = desk.buy_rate()
            home = sell_fx_to_bank(bank, trader, other, bal, rate, region)
            if home > 0:
                trader._trader_revenue += home

    # ---- Desk last resort: fill residual bids from reserves ----
    for order in list(desk.book):
        if order['kind'] != 'bid':
            continue
        trader = order['trader']
        qty = order['qty']
        if qty <= 0:
            continue
        bought = buy_fx_from_bank(bank, trader, other, qty, desk.sell_rate(), region)
        if bought > 0:
            order['qty'] -= bought

    # Drop fully-filled bids and STALE asks (trader's wallet was drained
    # by repatriation this same turn, so those asks can never fill).
    desk.book = [o for o in desk.book
                 if o['qty'] > 0 and o['kind'] == 'ask'
                 and fx_balance(o['trader'], other) > 0]
    return matched


def cycle_all_markets(regions, t=0):
    """Run one interbank cycle across every region-neighbour desk.

    For each region and each of its forex_desks (one per neighbour), run the
    cycle body (bid / clear / repatriate / desk-fill).  Legacy single-partner
    setups with only ``region.forex`` set are also served.
    Returns {f'{region.name}->{partner.name}': matched_value} for each desk.
    """
    result = {}
    for region in regions:
        desks = getattr(region, 'forex_desks', None)
        if desks:
            for pname, desk in desks.items():
                partner = region.neighbors.get(pname)
                if partner is None:
                    # desk exists but neighbor list not wired (shouldn't
                    # happen in ring/nation setups); fall back to name match
                    partner = next((r for r in regions if r.name == pname), None)
                if partner is None:
                    continue
                result[f"{region.name}->{pname}"] = _cycle_one_desk(
                    region, partner, desk, t)
        else:
            desk = getattr(region, 'forex', None)
            if desk is not None:
                partner = getattr(region, 'destination_region', None)
                if partner is not None:
                    result[f"{region.name}->{partner.name}"] = _cycle_one_desk(
                        region, partner, desk, t)
    return result


def _get_working_capital_target():
    return WORKING_CAPITAL_TARGET
