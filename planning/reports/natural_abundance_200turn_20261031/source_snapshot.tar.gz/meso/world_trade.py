"""
Generalized multi-region trade helpers for N-tile drivers (M0.3+).

These mirror the helpers in econsim_two_region.py but are multi-neighbour
aware: they resolve the per-pair ForexDesk from ``region.forex_desks``
(falling back to the legacy ``region.forex``) and per-pair Route from
``region.routes`` (falling back to ``region.route``).  econsim_two_region.py
itself is NOT touched so the legacy single-partner driver stays intact.
"""
from treasury_trace import begin_public_change as _trace_public_begin, finish_public_change as _trace_public_finish

from goods import Goods
import forex as fx


def desk_for(region, partner):
    """Per-pair ForexDesk between *region* and *partner* (multi-neighbor)."""
    desks = getattr(region, 'forex_desks', None)
    if desks:
        d = desks.get(partner.name)
        if d is not None:
            return d
    return getattr(region, 'forex', None)


def route_for(region, partner):
    """Per-pair Route from *region* to *partner* (multi-neighbor)."""
    routes = getattr(region, 'routes', None)
    if routes:
        r = routes.get(partner.name)
        if r is not None:
            return r
    return getattr(region, 'route', None)


TRADE_GOODS = tuple(g for g in Goods
                    if g not in (Goods.none, Goods.gov, Goods.transport))
# Kept as an import alias for older callers; routes now carry all commodities.
GOODS_T1 = TRADE_GOODS
T1_MARGIN_MIN = 0.05


def pending_imports(dest, src):
    """Goods that *src*'s traders have physically delivered to *dest*.

    Returns {Goods.good: [(trader, qty, is_parked, ...provenance), ...]}.
    Provenance fields after those first three values are the active route-leg
    shipment ID, source unit cost, freight and currency, cost status, original
    shipment ID, source region, route history, acquisition links, and the
    source tile object used to post the seller's receipt to their home ledger.
      - Active pool: ``inventory_foreign`` lots whose current destination is
        *dest* (same rule as the legacy two-region helper) -> is_parked=False.
      - Parked pool (T1): lots that matured at *dest* after the trader
        re-pointed elsewhere -> is_parked=True.  Settlement decrements
        parked_foreign instead of the shared inventory_foreign.
    """
    pend = {}
    for trader in src.trader_agents:
        if not getattr(trader, 'is_trader', False) or not getattr(trader, 'alive', True):
            continue
        if getattr(trader, 'destination_region', None) is dest:
            for g in TRADE_GOODS:
                if g not in getattr(dest, 'recipes', {}):
                    continue
                lots = [lot for lot in getattr(trader, 'import_lots', [])
                        if lot.get('destination') == dest.name and lot.get('good') == g.name
                        and not lot.get('parked', False)
                        and int(lot.get('quantity', 0)) > 0]
                lot_qty = sum(int(lot['quantity']) for lot in lots)
                for lot in lots:
                    pend.setdefault(g, []).append((trader, int(lot['quantity']), False,
                                                   lot.get('shipment_id'),
                                                   lot.get('unit_cost'),
                                                   lot.get('freight_per_unit'),
                                                   lot.get('source_currency'),
                                                   lot.get('source_cost_status'),
                                                   lot.get('source_shipment_id'),
                                                   lot.get('source_region'),
                                                   list(lot.get('route_history') or []),
                                                   list(lot.get('source_acquisitions') or []),
                                                   src))
                qty = max(0, int(trader.inventory_foreign[g.value]) - lot_qty)
                if qty > 0:
                    pend.setdefault(g, []).append((trader, qty, False, None, None,
                                                   None, None, 'unlinked_legacy_cargo',
                                                   None, None, [], [], src))
        for g in TRADE_GOODS:
            if g not in getattr(dest, 'recipes', {}):
                continue
            lots = [lot for lot in getattr(trader, 'import_lots', [])
                    if lot.get('destination') == dest.name and lot.get('good') == g.name
                    and lot.get('parked', False) and int(lot.get('quantity', 0)) > 0]
            lot_qty = sum(int(lot['quantity']) for lot in lots)
            for lot in lots:
                pend.setdefault(g, []).append((trader, int(lot['quantity']), True,
                                               lot.get('shipment_id'),
                                               lot.get('unit_cost'),
                                               lot.get('freight_per_unit'),
                                               lot.get('source_currency'),
                                               lot.get('source_cost_status'),
                                               lot.get('source_shipment_id'),
                                               lot.get('source_region'),
                                               list(lot.get('route_history') or []),
                                               list(lot.get('source_acquisitions') or []),
                                               src))
            qty = max(0, int(trader.parked_get(dest.name, g, 0)) - lot_qty)
            if qty > 0:
                pend.setdefault(g, []).append((trader, qty, True, None, None, None,
                                               None, 'unlinked_legacy_cargo', None,
                                               None, [], [], src))
    return pend


def record_away_trader_food_purchase(source_region, destination_region, trader,
                                    seller, turn, quantity, unit_price, *,
                                    use_fx, trader_cash_before,
                                    trader_wallet_before, seller_cash_before,
                                    trader_food_before, seller_food_before):
    """Journal an away trader's food purchase and its cash or wallet tender."""
    from economy.actor_accounts import record as record_economic_event
    from run_trace import emit

    amount = float(quantity) * float(unit_price)
    ident = int(getattr(destination_region, '_next_trader_food_transfer_id', 1))
    destination_region._next_trader_food_transfer_id = ident + 1
    transfer_id = (f'trader-food:{int(turn)}:{source_region.name}:'
                   f'{destination_region.name}:{ident}')
    trader_cash_after = float(trader.cash)
    seller_cash_after = float(seller.cash)
    trader_wallet_after = fx.fx_balance(trader, destination_region.home_currency)
    detail = {
        'transfer_id': transfer_id,
        'payment_kind': 'away_trader_food_purchase',
        'tender': 'foreign_wallet' if use_fx else 'hand_cash',
        'source_tile': source_region.name,
        'destination_tile': destination_region.name,
        'trader_id': trader.id,
        'seller_id': seller.id,
        'good': Goods.food.name,
        'quantity': int(quantity),
        'unit_price': float(unit_price),
        'amount': amount,
        'currency': destination_region.home_currency,
        'trader_cash_before': float(trader_cash_before),
        'trader_cash_after': trader_cash_after,
        'trader_wallet_before': float(trader_wallet_before),
        'trader_wallet_after': float(trader_wallet_after),
        'seller_cash_before': float(seller_cash_before),
        'seller_cash_after': seller_cash_after,
        'trader_food_before': int(trader_food_before),
        'trader_food_after': int(trader.inv_get(Goods.food, 0)),
        'seller_food_before': int(seller_food_before),
        'seller_food_after': int(seller.inv_get(Goods.food, 0)),
    }
    wallet_event = None
    if use_fx:
        wallet_event = record_economic_event(
            source_region, 'wallet_transfer_out', turn=turn,
            payer_id=trader.id, amount=amount, asset_id=transfer_id,
            source_id=transfer_id, currency=destination_region.home_currency,
            detail={**detail, 'settlement_leg': 'trader_wallet_debit'})
    sale_event = record_economic_event(
        destination_region, 'spot_sale', turn=turn,
        payer_id=None if use_fx else trader.id, recipient_id=seller.id,
        good=Goods.food, quantity=quantity, amount=amount,
        asset_id=transfer_id, source_id=transfer_id,
        currency=destination_region.home_currency,
        detail={**detail, 'cash_receipt': amount,
                'seller_receipt': amount, 'wallet_receipt': 0.0,
                'away_trader_purchase': True})
    emit(destination_region, kind='away_trader_food_purchase',
         record_class='transfer', phase='trade',
         subject={'type': 'tile', 'id': destination_region.name,
                  'good': Goods.food.name, 'buyer_id': trader.id,
                  'seller_id': seller.id},
         metric_id='trade.away_trader_food_purchase',
         unit=destination_region.home_currency,
         before=(float(trader_wallet_before) if use_fx
                 else float(trader_cash_before)),
         after=(float(trader_wallet_after) if use_fx
                else trader_cash_after),
         inputs={**detail,
                 'sale_event': {'tile': destination_region.name,
                                'event_id': sale_event['id']},
                 'wallet_event': ({'tile': source_region.name,
                                   'event_id': wallet_event['id']}
                                  if wallet_event is not None else None)})
    return transfer_id


def _net_foreign_home(trader, region, all_regions, good):
    """*region*'s price for *good* expressed in the trader's home currency.

    Uses the home-side per-pair desk buy rate (converts the destination
    currency into the trader's home currency), matching _repoint_traders.
    Same-currency tiles convert at 1.0.
    """
    price = region.recipes.get(good, {}).get('price', 0.0)
    if price <= 0:
        return 0.0
    if trader.home_region == region.name:
        return price
    home = None
    for r in all_regions:
        if r.name == trader.home_region:
            home = r
            break
    if home is None:
        return 0.0
    desk = (home.forex_desks or {}).get(region.name)
    if desk is None:
        return 0.0
    return price * desk.buy_rate()


def resolve_parked(regions):
    """T1.3: resolve parked goods once per turn (re-route / hold).

    Selling at the parked tile is driven by that tile's auction: the harness's
    pending_imports(dest, src) offers parked lots with is_parked=True, and
    settlement decrements parked_foreign in place.  Unslued lots remain parked
    for the next turn automatically.

    This function only handles RE-ROUTE: a parked lot at tile X is re-shipped
    toward the trader's CURRENT destination via X's own outbound route, and
    only when the trader changed destination (dest != x) AND that tile clears
    strictly more than a sale at X and still beats cost.  Otherwise HOLD.
    """
    for x in regions:
        for src in regions:
            if src is x:
                continue
            for trader in src.trader_agents:
                if not getattr(trader, 'is_trader', False) or not getattr(trader, 'alive', True):
                    continue
                bucket = trader.parked_foreign.get(x.name)
                if not bucket:
                    continue
                dest = getattr(trader, 'destination_region', None)
                if dest is None or dest is x or dest is src:
                    continue
                if dest.name not in x.neighbors:
                    continue
                for g in TRADE_GOODS:
                    qty = bucket[g.value]
                    if qty <= 0:
                        continue
                    cost = trader.cost_get(g, 0)
                    if cost <= 0:
                        cost = max(0.05, src.recipes.get(g, {}).get('price', 0.0))
                    decent = cost * (1.0 + T1_MARGIN_MIN)
                    net_x = _net_foreign_home(trader, x, regions, g)
                    net_z = _net_foreign_home(trader, dest, regions, g)
                    if net_z > net_x and net_z >= decent:
                        route = x.routes.get(dest.name)
                        if route is not None:
                            route.post_parked(trader, g, qty)


def settle_trade(t, destination_region, source_region):
    """Post-auction settlement for an ordered region pair (multi-neighbor).

    Same responsibilities as econsim_two_region.settle_trade: log the priced
    auction's import sales, let away-traders buy food at the destination out
    of their wallet, and post leftover foreign earnings as ASKs on the home
    desk for this specific partner currency.  Returns (qty, value).

    v3_wilderness: a WILDERNESS destination (no bank, no currency, no market)
    is serviced exclusively by trade_settle.settle_wilderness — arriving here
    would credit homesteader sellers in a None-keyed wallet and leak past the
    per-currency audit, so skip it.
    """
    if getattr(destination_region, 'wilderness', False):
        return 0, 0.0
    sname = source_region.name
    traders = [a for a in source_region.trader_agents
               if a.home_region == sname]
    desk = desk_for(source_region, destination_region)
    use_fx = desk is not None and getattr(source_region, 'home_currency',
                                          None) is not None
    dest_currency = destination_region.home_currency
    total_sold_value = 0.0
    total_sold_quantity = 0

    # 1. Log what the destination's priced auction sold for us this turn.
    for good in TRADE_GOODS:
        source_sales_by_good = getattr(
            destination_region, '_auction_import_sales_by_source', {})
        source_sales = source_sales_by_good.get(good)
        if source_sales is None:
            # Legacy/direct callers may only provide the all-source total.
            aq, av = destination_region._auction_import_sales.get(
                good, (0, 0.0))
        else:
            source_sale = source_sales.get(source_region.name, {})
            aq = int(source_sale.get('quantity', 0))
            av = float(source_sale.get('value', 0.0))
        if aq > 0 and (good in source_region.export_vol and good in destination_region.import_vol):
            source_region.export_vol[good].append(aq)
            source_region.export_val[good].append(av)
            destination_region.import_vol[good].append(aq)
            destination_region.import_val[good].append(av)
            total_sold_quantity += aq
            total_sold_value += av
        elif good in source_region.export_vol and good in destination_region.import_vol:
            source_region.export_vol[good].append(0)
            source_region.export_val[good].append(0.0)
            destination_region.import_vol[good].append(0)
            destination_region.import_val[good].append(0.0)

    # 2. Away traders buy food for themselves at the destination.
    for trader in traders:
        if trader.inv_get(Goods.food, 0) < 8:
            food_price = destination_region.recipes[Goods.food]['price']
            need = 8 - trader.inv_get(Goods.food, 0)
            if use_fx:
                wallet_bal = fx.fx_balance(trader, dest_currency)
                afford = int(wallet_bal / food_price) if food_price > 0 else 0
            else:
                afford = int(trader.cash / food_price) if food_price > 0 else 0
            to_buy = min(need, afford)
            if to_buy > 0:
                sellers = [a for a in destination_region.agents
                           if a.output == Goods.food
                           and a.inv_get(Goods.food, 0) > 2
                           and not getattr(a, 'is_trader', False)]
                bought = 0
                for seller in sellers:
                    if bought >= to_buy:
                        break
                    available = seller.inv_get(Goods.food, 0) - 2
                    if available <= 0:
                        continue
                    take = min(available, to_buy - bought)
                    trader_cash_before = float(trader.cash)
                    trader_wallet_before = fx.fx_balance(trader, dest_currency)
                    seller_cash_before = float(seller.cash)
                    trader_food_before = int(trader.inv_get(Goods.food, 0))
                    seller_food_before = int(seller.inv_get(Goods.food, 0))
                    seller.inv_add(Goods.food, -take)
                    _trace_cash_write = _trace_public_begin(None, seller)
                    seller.cash += take * food_price
                    _trace_public_finish(_trace_cash_write, 'world_trade:settle_trade',
                                         inputs={"source_writer": 'world_trade.py:settle_trade:5602179fd3206209:1'})
                    if use_fx:
                        fx.fx_sub(trader, dest_currency, take * food_price)
                    else:
                        _trace_cash_write = _trace_public_begin(None, trader)
                        trader.cash -= take * food_price
                        _trace_public_finish(_trace_cash_write, 'world_trade:settle_trade',
                                             inputs={"source_writer": 'world_trade.py:settle_trade:9abad278453f8762:1'})
                    trader.inv_add(Goods.food, take)
                    record_away_trader_food_purchase(
                        source_region, destination_region, trader, seller, t,
                        take, food_price, use_fx=use_fx,
                        trader_cash_before=trader_cash_before,
                        trader_wallet_before=trader_wallet_before,
                        seller_cash_before=seller_cash_before,
                        trader_food_before=trader_food_before,
                        seller_food_before=seller_food_before)
                    bought += take

    # 3. Post leftover foreign earnings as ASKs on the home desk for this
    #    partner's currency (book persists; cycle clears/repatriates).
    if use_fx:
        for trader in traders:
            bal = fx.fx_balance(trader, dest_currency)
            if bal > 0:
                desk.post_order('ask', trader, bal, desk.buy_rate())

    if total_sold_value > 0 and t % 50 == 0:
        from logger import loginfo
        loginfo(t, f"TRADE {source_region.name}->{destination_region.name}: "
                f"sold {total_sold_quantity} units worth ${total_sold_value:.2f} "
                f"through the priced auction")

    return total_sold_quantity, total_sold_value


def trader_wealth(region):
    """Total trader wealth in home currency across all desks.

    Cash + bank deposits + every foreign wallet converted at that currency's
    per-pair desk buy rate.
    """
    total = 0.0
    desks = getattr(region, 'forex_desks', None)
    for a in region.trader_agents:
        w = a.cash + region.bank.deposits.get(a, 0)
        if desks:
            for name, d in desks.items():
                other = d.other
                if other == region.home_currency:
                    continue
                w += fx.fx_balance(a, other) * d.buy_rate()
        elif getattr(region, 'forex', None) is not None:
            d = region.forex
            w += fx.fx_balance(a, d.other) * d.buy_rate()
        total += w
    return total


def check_trader_holdings(region, other, t):
    """Sanity-check that no trader holds goods that can't clear a profit.

    Multi-neighbor equivalent of econsim_two_region.check_trader_holdings:
    uses the per-pair desk rate and per-pair route holdings.
    Returns number of violations.
    """
    violations = 0
    stranded_value = 0.0
    worst = []
    transport_cost = region._transport_cost_per_unit()
    desk = desk_for(region, other)
    home_per_dest = desk.buy_rate() if desk is not None else 1.0
    route = route_for(region, other)
    for trader in region.trader_agents:
        if not getattr(trader, 'is_trader', False):
            continue
        holdings = {}
        for g in TRADE_GOODS:
            qty = (trader.inventory_export[g.value]
                   + trader.inventory_foreign[g.value]
                   + trader.parked_total(g))
            if route is not None:
                qty += route.holdings_of(trader).get(g, 0)
            if g != Goods.food:
                qty += trader.inv_get(g, 0)
            if qty > 0:
                holdings[g] = qty
        for g, qty in holdings.items():
            dest_price = other.recipes.get(g, {}).get('price', 0)
            cost = trader.cost_get(g, 0)
            if cost <= 0:
                cost = region.recipes.get(g, {}).get('price', 0)
            net_foreign = dest_price * home_per_dest
            loss_per_unit = (cost + transport_cost) - net_foreign
            if loss_per_unit > 0:
                violations += 1
                stranded_value += loss_per_unit * qty
                worst.append((loss_per_unit * qty, trader.name(), qty, g,
                              loss_per_unit))
    if violations > 0:
        worst.sort(reverse=True)
        print(f"  [TRADER AUDIT] T={t} {region.name}: {violations} unprofitable "
              f"holdings, stranded value ${stranded_value:,.0f}")
        for loss, name, qty, g, unit in worst[:5]:
            print(f"      {name}: {qty} {g} @ ${unit:.2f} loss/unit")
    return violations
