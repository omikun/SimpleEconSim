"""Data-driven creditor reactions and foreign reports for authored situations."""

from __future__ import annotations
from treasury_trace import begin_public_change as _trace_public_begin, finish_public_change as _trace_public_finish

from functools import lru_cache
import json
from pathlib import Path


EFFECT_FIELDS = frozenset({
    'confidence_delta', 'autonomy_delta', 'legitimacy_delta', 'treasury_cost',
    'payment_amount_multiplier', 'payment_due_in', 'payment_status',
    'export_fraction', 'levy_per_turn', 'palace_authority_delta',
})


def _validate_template(data: dict) -> None:
    if data.get('format') != 'coc.situation.v1' or not isinstance(data.get('branches'), dict):
        raise ValueError('Unsupported situation scenario format.')
    naval_rules = data.get('naval_crisis', {})
    for key in ('british_squadron_strength', 'alexandria_battery_strength',
                'battery_reinforcement_strength', 'battery_reinforcement_cost',
                'mobilization_cost', 'upkeep_per_turn', 'max_british_protest_energy',
                'max_french_protest_energy', 'minimum_force_ratio', 'settlement_fraction'):
        if not isinstance(naval_rules.get(key), (int, float)) or naval_rules[key] <= 0:
            raise ValueError(f'naval_crisis: {key} must be positive.')
    response_ids = set()
    for action_id, branch in data['branches'].items():
        reaction = branch.get('reaction')
        if not isinstance(branch.get('delay_turns'), int) or branch['delay_turns'] < 1:
            raise ValueError(f'{action_id}: delay_turns must be at least one.')
        if not isinstance(reaction, dict) or not reaction.get('headline') or not reaction.get('body'):
            raise ValueError(f'{action_id}: reaction needs a headline and body.')
        for node in [reaction] + list(reaction.get('responses', [])):
            effects = node.get('effects', {})
            if not isinstance(effects, dict) or set(effects) - EFFECT_FIELDS:
                raise ValueError(f'{action_id}: unsupported situation effect.')
        for response in reaction.get('responses', []):
            response_id = response.get('id')
            if not response_id or response_id in response_ids or not response.get('label') or not response.get('tooltip'):
                raise ValueError(f'{action_id}: response needs a unique id, label, and tooltip.')
            if float(response.get('requires_cash', 0.0)) < float(response.get('effects', {}).get('treasury_cost', 0.0)):
                raise ValueError(f'{action_id}: response cash requirement is below its cost.')
            response_ids.add(response_id)


@lru_cache(maxsize=1)
def situation_template() -> dict:
    path = Path(__file__).with_name('situation_scenario_template.json')
    with path.open(encoding='utf-8') as source:
        data = json.load(source)
    _validate_template(data)
    return data


def _egypt(world: dict):
    return next((nation for nation in world.get('nations', [])
                 if nation.name == world.get('player_nation_name')), None)


def _trace_region(world: dict):
    return next((tile for tile in world.get('tiles', [])
                 if (getattr(tile, '_run_trace', None) is not None
                     and getattr(tile, '_collective_trace_clock', None) is not None)), None)


def _emit_situation_trace(world: dict, **event):
    region = _trace_region(world)
    if region is None:
        return None
    from run_trace import emit
    return emit(region, **event)


def _situation_operation_id(world: dict, source: str) -> str | None:
    region = _trace_region(world)
    if region is None:
        return None
    safe_source = str(source).replace(' ', '_')
    return (f'creditor-effect:{safe_source}:{int(world.get("turn", 0))}:'
            f'{int(region._collective_trace_clock.get("next", 0))}')


def queue_creditor_reaction(world: dict, action_id: str) -> None:
    branch = situation_template()['branches'].get(action_id)
    if branch is None:
        return
    state = world.get('scenario_state', {})
    state.setdefault('creditor_reactions', []).append({
        'action_id': action_id,
        'due_turn': int(world.get('turn', 0)) + int(branch['delay_turns']),
        'status': 'pending',
    })


def _pay_creditors(world: dict, amount: float) -> list[dict]:
    creditors = [n for n in world.get('nations', []) if n.name in ('Britain', 'France')]
    payments = []
    if creditors:
        for creditor in creditors:
            recipient = creditor.government.agent
            cash_before = float(recipient.cash)
            share = amount / len(creditors)
            _trace_cash_write = _trace_public_begin(None, recipient)
            recipient.cash += share
            _trace_public_finish(_trace_cash_write, 'scenario_situation:_pay_creditors',
                                 inputs={"source_writer": 'scenario_situation.py:_pay_creditors:c4c372097abecd57:1'})
            payments.append({'nation': creditor, 'amount': float(share),
                             'cash_before': cash_before,
                             'cash_after': float(recipient.cash)})
    return payments


def _effect_state(nation, state: dict) -> dict:
    return {
        'creditor_confidence': float(state.get('creditor_confidence', 0.0)),
        'fiscal_autonomy': float(state.get('fiscal_autonomy', 0.0)),
        'legitimacy': float(getattr(nation, 'legitimacy', 0.0)),
        'payment_status': state.get('payment_status'),
        'scheduled_remittance': float(state.get('scheduled_remittance', 0.0)),
        'deferral_count': int(state.get('deferral_count', 0)),
        'palace_authority': (float(state['politics'].get('palace_authority', 0.0))
                             if state.get('politics') else None),
        'food_export_fraction_by_tile': {
            tile.name: float(getattr(tile, 'food_export_fraction', 1.0))
            for tile in getattr(nation, 'tiles', [])},
    }


def _trace_creditor_payment(world: dict, nation, source: str, operation_id,
                            amount: float, cash_before: float, cash_after: float,
                            payments: list[dict], cause_event_ids=None) -> list[str]:
    region = _trace_region(world)
    if region is None:
        return []
    from finance_trace import account_ref, emit_treasury_leg, transfer_contract
    payer_currency = (getattr(nation, 'currency', None)
                      or getattr(region, 'home_currency', None)
                      or 'local_currency')
    payee_names = [row['nation'].name for row in payments]
    payee_pool = account_ref(
        'creditor_government_pool' if payments else 'uncredited_creditor_payment',
        ','.join(payee_names) if payee_names else 'no_eligible_creditor',
        payer_currency,
        balance_scope='split_receipts' if payments else 'missing_payee',
        balance_status='see_individual_recipient_legs' if payments else
        'treasury_cash_debited_without_creditor_receipt')
    operation_id = operation_id or f'creditor-effect:{source}:{int(world.get("turn", 0))}'
    payer_contract = transfer_contract(
        operation_id, 'creditor_situation_treasury_cost', side='payer',
        amount=amount, amount_currency=payer_currency,
        payer_account=account_ref(
            'government_treasury', str(nation.government.agent.id), payer_currency,
            balance_before=cash_before, balance_after=cash_after,
            balance_scope='government_agent.cash', nation_id=nation.name),
        payee_account=payee_pool,
        local_cash_leg_amount=amount, local_cash_leg_currency=payer_currency,
        counterparty_leg_status=('split_creditor_receipts_recorded' if payments else
                                 'treasury_debit_only_no_eligible_creditor'),
        source=source, recipient_count=len(payments))
    payer_event_id = emit_treasury_leg(
        region,
        kind=('creditor_situation_treasury_cost' if payments else
              'creditor_situation_cost_without_recipient'),
        nation_name=nation.name, currency=payer_currency,
        signed_amount=-amount, contract=payer_contract,
        phase='creditor_reaction',
        inputs={'operation_id': operation_id, 'source': source,
                'treasury_cash_before': cash_before,
                'treasury_cash_after': cash_after,
                'creditor_names': payee_names,
                'recipient_count': len(payments),
                'recipient_amounts': [row['amount'] for row in payments]},
        cause_event_ids=cause_event_ids)
    event_ids = [payer_event_id] if payer_event_id is not None else []
    for payment in payments:
        creditor = payment['nation']
        creditor_currency = (getattr(creditor, 'currency', None)
                             or payer_currency)
        share = float(payment['amount'])
        contract = transfer_contract(
            operation_id, 'creditor_situation_treasury_cost', side='recipient',
            amount=share, amount_currency=payer_currency,
            payer_account=account_ref(
                'government_treasury', str(nation.government.agent.id), payer_currency,
                nation_id=nation.name, balance_scope='aggregate_source_debit',
                balance_status='captured_on_payer_leg'),
            payee_account=account_ref(
                'government_treasury', str(creditor.government.agent.id),
                creditor_currency, balance_before=payment['cash_before'],
                balance_after=payment['cash_after'],
                balance_scope='government_agent.cash', nation_id=creditor.name),
            local_cash_leg_amount=share,
            local_cash_leg_currency=creditor_currency,
            currency_conversion_applied=False,
            counterparty_leg_status='paired_to_aggregate_source_debit',
            source=source, aggregate_source_amount=amount)
        receipt_event_id = emit_treasury_leg(
            region, kind='creditor_situation_payment_receipt',
            nation_name=creditor.name, currency=creditor_currency,
            signed_amount=share, contract=contract,
            phase='creditor_reaction',
            inputs={'operation_id': operation_id, 'source': source,
                    'payer_nation': nation.name, 'recipient_share': share,
                    'recipient_cash_before': payment['cash_before'],
                    'recipient_cash_after': payment['cash_after']},
            cause_event_ids=[payer_event_id] if payer_event_id is not None else None)
        if receipt_event_id is not None:
            event_ids.append(receipt_event_id)
    return event_ids


def apply_effects(world: dict, effects: dict, *, source: str = 'direct',
                  trace_event_ids=None) -> tuple[bool, str]:
    """Apply only the bounded effects supported by situation template v1."""
    operation_id = _situation_operation_id(world, source)
    nation = _egypt(world)
    if nation is None:
        message = 'The Egyptian administration is unavailable.'
        event_id = _emit_situation_trace(
            world, kind='creditor_effect_application', record_class='outcome',
            phase='creditor_reaction',
            subject={'type': 'scenario/nation',
                     'id': world.get('player_nation_name', 'Egypt')},
            metric_id='scenario.creditor_effects',
            inputs={'operation_id': operation_id, 'source': source,
                    'success': False, 'reason': 'player_nation_unavailable',
                    'effects_requested': dict(effects), 'effects_applied': []})
        if event_id is not None and trace_event_ids is not None:
            trace_event_ids.append(event_id)
        return False, message
    state = world.get('scenario_state', {})
    cost = float(effects.get('treasury_cost', 0.0))
    treasury_before = float(nation.government.agent.cash)
    cause_ids = []
    funding_event_id = None
    if cost > 0.0:
        funding_event_id = _emit_situation_trace(
            world, kind='creditor_effect_funding_decision', record_class='decision',
            phase='creditor_reaction',
            subject={'type': 'scenario/nation', 'id': nation.name},
            metric_id='scenario.creditor_response_funding',
            inputs={'operation_id': operation_id, 'source': source,
                    'treasury_cash_available': treasury_before,
                    'required_cash': cost,
                    'cash_shortfall': max(0.0, cost - treasury_before),
                    'affordable': treasury_before >= cost,
                    'decision': ('apply_response' if treasury_before >= cost
                                 else 'reject_response'),
                    'reason': ('treasury_funds_response' if treasury_before >= cost
                               else 'treasury_cash_below_response_cost')})
        if funding_event_id is not None:
            cause_ids.append(funding_event_id)
            if trace_event_ids is not None:
                trace_event_ids.append(funding_event_id)
    if cost > treasury_before:
        message = f'The treasury needs {cost:,.0f} units for this response.'
        event_id = _emit_situation_trace(
            world, kind='creditor_effect_application', record_class='outcome',
            phase='creditor_reaction',
            subject={'type': 'scenario/nation', 'id': nation.name},
            metric_id='scenario.creditor_effects', before=treasury_before,
            after=treasury_before,
            inputs={'operation_id': operation_id, 'source': source,
                    'success': False, 'reason': 'insufficient_treasury_cash',
                    'treasury_cost_requested': cost,
                    'effects_requested': dict(effects), 'effects_applied': [],
                    'funding_decision_event_id': funding_event_id},
            cause_event_ids=cause_ids or None)
        if event_id is not None and trace_event_ids is not None:
            trace_event_ids.append(event_id)
        return False, message

    before_state = _effect_state(nation, state)
    payment_event_ids = []
    if cost:
        treasury_cash_before = float(nation.government.agent.cash)
        _trace_cash_write = _trace_public_begin(None, nation.government.agent)
        nation.government.agent.cash -= cost
        _trace_public_finish(_trace_cash_write, 'scenario_situation:apply_effects',
                             inputs={"source_writer": 'scenario_situation.py:apply_effects:6eb6faf09a7d465f:1'})
        creditor_payments = _pay_creditors(world, cost)
        treasury_cash_after = float(nation.government.agent.cash)
        payment_event_ids = _trace_creditor_payment(
            world, nation, source, operation_id, cost,
            treasury_cash_before, treasury_cash_after, creditor_payments,
            cause_event_ids=cause_ids or None)
        cause_ids.extend(payment_event_ids)
        if trace_event_ids is not None:
            trace_event_ids.extend(payment_event_ids)
    for field, delta in (('creditor_confidence', effects.get('confidence_delta', 0.0)),
                         ('fiscal_autonomy', effects.get('autonomy_delta', 0.0))):
        state[field] = max(0.0, min(1.0, float(state.get(field, 0.0)) + float(delta)))
    if 'legitimacy_delta' in effects:
        nation.legitimacy = max(0.0, min(1.0, float(nation.legitimacy) + float(effects['legitimacy_delta'])))
    if 'palace_authority_delta' in effects and state.get('politics'):
        politics = state['politics']
        politics['palace_authority'] = max(0.0, min(1.0, float(politics['palace_authority'])
                                                  + float(effects['palace_authority_delta'])))
    if 'payment_amount_multiplier' in effects or 'payment_due_in' in effects:
        from scenario_debt import adjust_service
        amount = (float(state['scheduled_remittance'])
                  * float(effects.get('payment_amount_multiplier', 1.0)))
        due_turn = (int(world.get('turn', 0)) + int(effects['payment_due_in'])
                    if 'payment_due_in' in effects else None)
        adjust_service(world, round(amount, 2), due_turn=due_turn)
    if 'payment_status' in effects:
        state['payment_status'] = effects['payment_status']
        if state['payment_status'] == 'deferred':
            state['deferral_count'] = max(1, int(state.get('deferral_count', 0)))
    if 'export_fraction' in effects:
        fraction = max(0.0, min(1.0, float(effects['export_fraction'])))
        for tile in nation.tiles:
            tile.food_export_fraction = fraction
        state['domestic_grain_priority'] = fraction < 1.0
    if 'levy_per_turn' in effects:
        from scenario_debt import set_collection_assignment
        set_collection_assignment(world, effects['levy_per_turn'], origin='caisse_consent')
    after_state = _effect_state(nation, state)
    event_id = _emit_situation_trace(
        world, kind='creditor_effect_application', record_class='outcome',
        phase='creditor_reaction',
        subject={'type': 'scenario/nation', 'id': nation.name},
        metric_id='scenario.creditor_effects', before=treasury_before,
        after=float(nation.government.agent.cash),
        unit=getattr(nation, 'currency', None) or 'local_currency',
        inputs={'operation_id': operation_id, 'source': source,
                'success': True, 'reason': 'effects_applied',
                'treasury_cost_requested': cost,
                'treasury_cash_before': treasury_before,
                'treasury_cash_after': float(nation.government.agent.cash),
                'effects_requested': dict(effects),
                'effects_applied': sorted(effects),
                'state_before': before_state, 'state_after': after_state,
                'funding_decision_event_id': funding_event_id,
                'payment_event_ids': payment_event_ids},
        cause_event_ids=cause_ids or None)
    if event_id is not None and trace_event_ids is not None:
        trace_event_ids.append(event_id)
    return True, ''


def advance_creditor_reactions(world: dict, turn: int, ticker_push) -> None:
    """Resolve informational replies and pause for the next demanding reply."""
    if world.get('scenario_warning_modal'):
        return
    state = world.get('scenario_state', {})
    for pending in state.get('creditor_reactions', []):
        if pending.get('status') != 'pending' or int(pending['due_turn']) > turn:
            continue
        reaction = situation_template()['branches'][pending['action_id']]['reaction']
        ok, message = apply_effects(
            world, reaction.get('effects', {}),
            source=f"reaction:{pending['action_id']}")
        if not ok:
            state['creditor_feedback'] = message
            continue
        headline = reaction['headline']
        state['creditor_feedback'] = f'{headline}. {reaction["body"]}'
        world['scenario_feedback'] = state['creditor_feedback']
        state.setdefault('creditor_news', []).append({'turn': turn, 'headline': headline,
                                                      'body': reaction['body']})
        ticker_push(world, turn, 'CREDITOR', state['creditor_feedback'], (225, 178, 87))
        if reaction.get('responses'):
            pending['status'] = 'awaiting_response'
            world['scenario_warning_modal'] = {
                'kind': 'creditor_reaction', 'action_id': pending['action_id'],
            }
            world['playing'] = False
            return
        pending['status'] = 'resolved'


def creditor_response_options(world: dict, action_id: str) -> list[dict]:
    reaction = situation_template()['branches'].get(action_id, {}).get('reaction', {})
    cash = float(getattr(getattr(getattr(_egypt(world), 'government', None), 'agent', None), 'cash', 0.0))
    used_plan = bool(world.get('scenario_state', {}).get('arrears_plan_used'))
    horizon = int(world.get('scenario', {}).get('horizon_turns', 20))
    arrears_response = next((response for response in reaction.get('responses', [])
                             if response['id'] == 'offer_arrears_plan'), None)
    arrears_delay = int(arrears_response.get('effects', {}).get('payment_due_in', 0)) if arrears_response else 0
    beyond_horizon = int(world.get('turn', 0)) + arrears_delay > horizon
    return [{**response, 'enabled': cash >= float(response.get('requires_cash', 0.0))
             and not (response['id'] == 'offer_arrears_plan' and (used_plan or beyond_horizon))}
            for response in reaction.get('responses', [])]


def response_label(response_id: str) -> str | None:
    for branch in situation_template()['branches'].values():
        for response in branch['reaction'].get('responses', []):
            if response['id'] == response_id:
                return response['label']
    return None


def resolve_creditor_response(world: dict, response_id: str) -> tuple[bool, str]:
    state = world.get('scenario_state', {})
    pending = next((item for item in state.get('creditor_reactions', [])
                    if item.get('status') == 'awaiting_response'), None)
    if pending is None:
        return False, 'There is no creditor demand awaiting a response.'
    options = creditor_response_options(world, pending['action_id'])
    response = next((item for item in options if item['id'] == response_id), None)
    if response is None:
        return False, 'That response is unavailable.'
    if not response['enabled']:
        if response_id == 'offer_arrears_plan' and state.get('arrears_plan_used'):
            return False, 'The Caisse will not accept another arrears plan.'
        due_delay = int(response.get('effects', {}).get('payment_due_in', 0))
        if (response_id == 'offer_arrears_plan'
                and int(world.get('turn', 0)) + due_delay > int(world.get('scenario', {}).get('horizon_turns', 20))):
            return False, 'The proposed arrears date falls after the campaign ends.'
        return False, f'The treasury needs {float(response.get("requires_cash", 0.0)):,.0f} units for this response.'
    from scenario_status import snapshot, record_change
    before = snapshot(world)
    apply_event_ids = []
    ok, message = apply_effects(
        world, response.get('effects', {}), source=f'response:{response_id}',
        trace_event_ids=apply_event_ids)
    if not ok:
        return False, message
    record_change(world, response_id, before, snapshot(world))
    if response_id == 'offer_arrears_plan':
        state['arrears_plan_used'] = True
    if response_id == 'defend_controller_dismissal' and state.get('politics'):
        politics = state['politics']
        politics['nationalist_movement'] = min(1.0, politics['nationalist_movement'] + .08)
        politics['army_loyalty'] = max(0.0, politics['army_loyalty'] - .08)
    pending['status'] = 'resolved'
    if response_id in ('contest_customs_claim', 'reject_revised_terms'):
        from scenario_gunboat import begin_escalation
        begin_escalation(world, response_id, cause_event_ids=apply_event_ids)
    elif response_id in ('accept_customs_control', 'offer_arrears_plan'):
        if state.get('naval_crisis', {}).get('stage') in ('mobilizing', 'ultimatum', 'blockaded'):
            from scenario_gunboat import withdraw
            withdraw(world, 'Cairo and the creditors reach terms; the naval claim is withdrawn.', cause='settlement')
    text = f'Creditor reply: {response["label"]}.'
    state.setdefault('actions_taken', []).append({'turn': int(world.get('turn', 0)),
                                                   'action': response_id,
                                                   'message': f'{text} {response["tooltip"]}'})
    state['creditor_feedback'] = text
    world['scenario_feedback'] = text
    from client.desktop.engine import ticker_push
    ticker_push(world, int(world.get('turn', 0)), 'SCENARIO', text, (120, 220, 170))
    return True, text


def collect_creditor_levy(world: dict) -> float:
    from scenario_debt import collected_this_turn
    return collected_this_turn(world)


def _foreign_snapshot(world: dict) -> dict:
    reports = {}
    for nation in world.get('nations', []):
        if nation.name not in ('Britain', 'France'):
            continue
        tiles = list(getattr(nation, 'tiles', []))
        if not tiles:
            continue
        highest = max(tiles, key=lambda tile: tile.protest_energy_log[-1]
                      if getattr(tile, 'protest_energy_log', None) else 0.0)
        energy = float(highest.protest_energy_log[-1]) if getattr(highest, 'protest_energy_log', None) else 0.0
        sources = getattr(highest, 'grievance_sources_log', [])
        raw = sources[-1].get('raw', {}) if sources else {}
        driver = max(raw, key=raw.get) if raw else 'mixed pressures'
        people = [agent for tile in tiles for agent in getattr(tile, 'agents', [])
                  if getattr(agent, 'alive', True) and not getattr(agent, 'is_government', False)
                  and not getattr(agent, 'is_corporation', False) and not getattr(agent, 'is_trader', False)]
        hungry = sum(getattr(agent, 'hungry_steps', 0) > 0 for agent in people)
        reports[nation.name] = {
            'energy': energy,
            'region': getattr(highest, 'display_name', highest.name),
            'driver': driver.replace('_', ' '),
            'legitimacy': float(getattr(nation, 'legitimacy', 0.5)),
            'hunger': hungry / max(1, len(people)),
            'treasury': float(nation.government.agent.cash),
        }
    return reports


def update_foreign_reports(world: dict) -> None:
    state = world.get('scenario_state', {})
    previous = state.get('foreign_previous', {})
    current = _foreign_snapshot(world)
    reports = []
    for name in ('Britain', 'France'):
        if name not in current:
            continue
        info = current[name]
        energy = info['energy']
        stage = ('riot risk' if energy >= 6.5 else 'organized protests' if energy >= 4.0
                 else 'elevated unrest' if energy >= 2.0 else 'quiet')
        delta = energy - float(previous.get(name, {}).get('energy', energy))
        delta_label = '0.0' if abs(delta) < 0.05 else f'{delta:+.1f}'
        reports.append({**info, 'nation': name, 'stage': stage, 'delta': delta, 'delta_label': delta_label,
                        'summary': f'{name}: {stage} in {info["region"]} ({energy:.1f}/10, {delta_label}).',
                        'detail': f'Main measured grievance: {info["driver"]}. Hunger {info["hunger"]:.0%}; '
                                  f'legitimacy {info["legitimacy"]:.0%}; treasury {info["treasury"]:,.0f}. '
                                  'This is a foreign country report; its unrest does not determine Egypt’s breakdown.'})
    state['foreign_reports'] = reports
    state['foreign_previous'] = current
