"""
test_geographic_demographics_and_trade.py — Unit Tests for Geographic Demographics,
Mountain Terrain Preservation, Occupation Allocation, and Capped Trade Networks.

Verifies:
1. Mountain terrain preservation: Claimed regions on mountains retain high elevation and mountain biomes.
2. Geographic population scaling: Mountains (~45), Hills (~75), Plains (~95), Coasts (~135).
3. Zero loggers/carpenters in mountains (no trees), enhanced farming/fishing on coasts.
4. Natural resources: Zero timber generated on high mountain peaks.
5. Capped trade partners: Mountain tiles have <= 2 neighbors; general tiles have <= 3 neighbors.
6. Pioneer migration: Settlers prioritize mineral-rich wilderness tiles.
"""

import unittest
from sim_world import build_world
from goods import Goods
from tile_resources import TileResource
from migration import _score_wilderness_attractiveness


class TestGeographicDemographicsAndTrade(unittest.TestCase):

    def setUp(self):
        # Build deterministic world
        self.tiles, self.nations, self.grid = build_world(seed=42, terrain_seed=12345, nation_seed=67890)

    def test_mountain_terrain_preservation_and_no_plains_wipe(self):
        """Verify claimed nation tiles on mountain terrain are NOT wiped to flat plains."""
        mountain_found = False
        for n in self.nations:
            for t in n.tiles:
                # If the underlying topography is high elevation, it must keep mountain biome and high elevation
                if t.elevation >= 0.72:
                    mountain_found = True
                    self.assertIn(t.biome, ('mountains', 'snow_peaks'))
                    self.assertGreaterEqual(t.elevation_meters, 2000)
                    self.assertNotEqual(t.biome, 'plains')
                elif t.elevation >= 0.48:
                    self.assertIn(t.biome, ('hills', 'mountains', 'snow_peaks'))
                    self.assertNotEqual(t.biome, 'plains')

        # Across all claimed and wilderness tiles, verify mountain biomes exist on land
        land_mountains = [t for t in self.tiles if not getattr(t, 'is_ocean', False) and t.elevation >= 0.72]
        self.assertTrue(len(land_mountains) > 0)
        for m in land_mountains:
            self.assertIn(m.biome, ('mountains', 'snow_peaks'))

    def test_geographic_starting_population(self):
        """Verify starting population is scaled by terrain (mountains sparse, coasts populous)."""
        for t in self.tiles:
            if getattr(t, 'is_ocean', False):
                self.assertEqual(len(t.agents), 0)
                continue

            elev = getattr(t, 'elevation', 0.20)
            biome = getattr(t, 'biome', 'plains')
            is_mountain = (elev >= 0.72) or (biome in ('mountains', 'snow_peaks'))
            is_coast = getattr(t, 'is_coast', False) or (biome == 'coast')

            if getattr(t, 'owner_nation', None) is not None:
                citizens = [a for a in t.agents if not getattr(a, 'is_trader', False) and not getattr(a, 'is_government', False)]
                if is_mountain:
                    self.assertEqual(len(citizens), 45)
                elif is_coast:
                    self.assertEqual(len(citizens), 135)
                elif elev >= 0.40:
                    self.assertEqual(len(citizens), 75)
                else:
                    self.assertEqual(len(citizens), 95)

    def test_mountain_and_coast_occupations(self):
        """Verify zero loggers/carpenters in mountains, and higher farming on coasts."""
        for n in self.nations:
            for t in n.tiles:
                elev = getattr(t, 'elevation', 0.20)
                biome = getattr(t, 'biome', 'plains')
                is_mountain = (elev >= 0.72) or (biome in ('mountains', 'snow_peaks'))
                is_coast = getattr(t, 'is_coast', False) or (biome == 'coast')

                citizens = [a for a in t.agents if not getattr(a, 'is_trader', False) and not getattr(a, 'is_government', False)]
                loggers = sum(1 for a in citizens if a.output == Goods.wood)
                carpenters = sum(1 for a in citizens if a.output == Goods.furniture)
                farmers = sum(1 for a in citizens if a.output == Goods.food)

                if is_mountain:
                    # Strictly no trees in mountains -> 0 loggers and 0 carpenters
                    self.assertEqual(loggers, 0)
                    self.assertEqual(carpenters, 0)
                    self.assertEqual(farmers, len(citizens))
                elif is_coast:
                    # Coast has high agricultural and fishing concentration (>= 80%)
                    self.assertGreaterEqual(farmers / len(citizens), 0.80)

    def test_no_timber_on_high_mountain_summits(self):
        """Verify high mountain peaks (elevation >= 0.72) never generate timber."""
        for t in self.tiles:
            elev = getattr(t, 'elevation', 0.0)
            if elev >= 0.72:
                self.assertNotIn(TileResource.TIMBER, getattr(t, 'natural_resources', set()))

    def test_capped_trade_partner_network(self):
        """Verify mountains have at most 2 neighbors and general tiles have at most 3."""
        for t in self.tiles:
            if getattr(t, 'is_ocean', False):
                continue
            elev = getattr(t, 'elevation', 0.0)
            biome = getattr(t, 'biome', 'plains')
            is_mountain = (elev >= 0.72) or (biome in ('mountains', 'snow_peaks'))

            num_partners = len(t.neighbors)
            if is_mountain:
                self.assertLessEqual(num_partners, 2)
            else:
                self.assertLessEqual(num_partners, 3)

    def test_settlers_attracted_to_mineral_mountains(self):
        """Verify pioneer attractiveness scoring favors mineral-rich mountains."""
        class MockTile:
            def __init__(self, resources, pop=0):
                self.natural_resources = resources
                self.wilderness_pop = pop
                self.agents = []

        plain_tile = MockTile(resources={TileResource.PASTURE_FLAX}, pop=30)
        iron_mountain = MockTile(resources={TileResource.IRON_ORE, TileResource.RARE_MINERALS}, pop=10)

        score_plain = _score_wilderness_attractiveness(plain_tile)
        score_mountain = _score_wilderness_attractiveness(iron_mountain)

        # Mineral rush bonus must make rich mountain tile more attractive to pioneers
        self.assertGreater(score_mountain, score_plain)


    def test_all_land_tiles_single_connected_component(self):
        """Verify 100% single connected component: every land tile is reachable even if via 1 trade route."""
        for seed in (42, 101, 500, 999, 12345):
            tiles, nations, grid = build_world(seed=seed)
            land = [t for t in tiles if not getattr(t, 'is_ocean', False)]
            visited = set()
            comps = []
            for t in land:
                if t.name not in visited:
                    comp = []
                    queue = [t]
                    visited.add(t.name)
                    while queue:
                        curr = queue.pop(0)
                        comp.append(curr)
                        for n in curr.neighbors.values():
                            if n.name not in visited and not getattr(n, 'is_ocean', False):
                                visited.add(n.name)
                                queue.append(n)
                    comps.append(comp)

            # Exactly 1 single connected component!
            self.assertEqual(len(comps), 1, f"Seed {seed} had {len(comps)} disconnected land components")
            self.assertEqual(len(comps[0]), len(land))

            # Every land tile has at least 1 trade route
            for t in land:
                self.assertGreaterEqual(len(t.neighbors), 1, f"Tile {t.name} in seed {seed} has 0 trade partners")

    def test_world_names_expanded_countries_and_starting_nations(self):
        """Verify Japan, Korea, Vietnam, Britain, France, Germany, Italy, Spain and US/China/Japan start."""
        from world_names import GLOBAL_NATION_DATA, COUNTRY_CURRENCIES, get_starting_nations_claimed_by
        requested = ["Japan", "Korea", "Vietnam", "Britain", "France", "Germany", "Italy", "Spain"]
        for c in requested:
            self.assertIn(c, GLOBAL_NATION_DATA, f"{c} missing from GLOBAL_NATION_DATA")
            provinces = GLOBAL_NATION_DATA[c]
            self.assertEqual(len(provinces), 10, f"{c} does not have 10 provinces")
            for p, cities in provinces.items():
                self.assertEqual(len(cities), 10, f"{c}-{p} does not have 10 cities")
            self.assertIn(c, COUNTRY_CURRENCIES, f"{c} missing currency")

        self.assertEqual(COUNTRY_CURRENCIES["Japan"], "JPY")
        self.assertEqual(COUNTRY_CURRENCIES["Korea"], "KRW")
        self.assertEqual(COUNTRY_CURRENCIES["Vietnam"], "VND")
        self.assertEqual(COUNTRY_CURRENCIES["Britain"], "GBP")

        # Every game starts with US, China, and Japan
        for s in (42, 101, 777, 999):
            starting = get_starting_nations_claimed_by(seed=s)
            self.assertEqual(list(starting.keys()), ["United States", "China", "Japan"])

    def test_real_national_and_provincial_capitals(self):
        """Verify real national and provincial capitals are used across nations and provinces."""
        from world_names import (
            get_national_capital, get_provincial_capital, NATIONAL_CAPITALS, PROVINCIAL_CAPITALS
        )
        # Check national capitals
        self.assertEqual(get_national_capital("United States"), "Washington, D.C.")
        self.assertEqual(get_national_capital("China"), "Beijing")
        self.assertEqual(get_national_capital("Japan"), "Tokyo")
        self.assertEqual(get_national_capital("Britain"), "London")
        self.assertEqual(get_national_capital("France"), "Paris")
        self.assertEqual(get_national_capital("Germany"), "Berlin")
        self.assertEqual(get_national_capital("Italy"), "Rome")
        self.assertEqual(get_national_capital("Spain"), "Madrid")
        self.assertEqual(get_national_capital("Korea"), "Seoul")
        self.assertEqual(get_national_capital("Vietnam"), "Hanoi")

        # Check key real provincial capitals
        self.assertEqual(get_provincial_capital("United States", "California"), "Sacramento")
        self.assertEqual(get_provincial_capital("United States", "Texas"), "Austin")
        self.assertEqual(get_provincial_capital("United States", "New York"), "Albany")
        self.assertEqual(get_provincial_capital("United States", "Florida"), "Tallahassee")
        self.assertEqual(get_provincial_capital("Germany", "North Rhine-Westphalia"), "Düsseldorf")
        self.assertEqual(get_provincial_capital("Germany", "Hesse"), "Wiesbaden")
        self.assertEqual(get_provincial_capital("Germany", "Bavaria"), "Munich")
        self.assertEqual(get_provincial_capital("Spain", "Galicia"), "Santiago de Compostela")
        self.assertEqual(get_provincial_capital("Spain", "Basque Country"), "Vitoria-Gasteiz")
        self.assertEqual(get_provincial_capital("China", "Guangdong"), "Guangzhou")

        # Verify in built world that national capital tile has the real national capital
        tiles, nations, grid = build_world(seed=42)
        for n in nations:
            expected_nat_cap = get_national_capital(n.name)
            self.assertEqual(n.capital.city_name, expected_nat_cap,
                             f"{n.name} capital should be {expected_nat_cap}, got {n.capital.city_name}")
            for prov in getattr(n, 'provinces', []):
                if prov.capital and prov.capital is not n.capital:
                    expected_prov_cap = get_provincial_capital(n.name, prov.display_name)
                    self.assertEqual(prov.capital.city_name, expected_prov_cap,
                                     f"{n.name}-{prov.display_name} capital should be {expected_prov_cap}, got {prov.capital.city_name}")


if __name__ == "__main__":
    unittest.main()



