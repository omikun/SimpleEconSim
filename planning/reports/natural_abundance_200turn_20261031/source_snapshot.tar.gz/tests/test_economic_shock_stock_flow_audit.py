import unittest

from economic_shock_stock_flow_audit import audit_run, render_markdown


class EconomicShockStockFlowAuditTests(unittest.TestCase):
    def _run(self, snapshots, completed_turns=2):
        return {
            "scenario": "supply_rivalry",
            "seed": 17,
            "experiment": "rivalry_cotton_supply_reduction",
            "arm": "cotton-control",
            "completed_turns": completed_turns,
            "scenario_goods_stock_observations": snapshots,
        }

    def test_reconciles_production_inputs_consumption_and_internal_turnover(self):
        run = self._run([
            {"turn": 1, "stocks": [
                {"good": "cotton", "quantity": 10},
                {"good": "cloth", "quantity": 2},
                {"good": "food", "quantity": 20},
                {"good": "wood", "quantity": 3},
            ]},
            {"turn": 2, "stocks": [
                {"good": "cotton", "quantity": 11},
                {"good": "cloth", "quantity": 4},
                {"good": "food", "quantity": 20},
                {"good": "wood", "quantity": 3},
            ]},
        ])
        events = [
            {"turn": 2, "kind": "independent_production",
             "subject": {"good": "cotton"}, "value_after": 4},
            {"turn": 2, "kind": "firm_production",
             "subject": {"good": "cloth"}, "value_after": 3,
             "inputs": {"input_good": "cotton", "input_quantity_used": 3}},
            {"turn": 2, "kind": "household_nonfood_consumption",
             "subject": {"good": "cloth"}, "delta": -1,
             "inputs": {"units_consumed": 1}},
            {"turn": 2, "kind": "civilian_food_consumption_total",
             "subject": {"good": "food"}, "value_after": 0,
             "inputs": {"eaten_food_units": 0}},
            {"turn": 2, "kind": "paid_market_sale",
             "subject": {"good": "cotton"}, "value_after": 99,
             "inputs": {"imported": False}},
            {"turn": 2, "kind": "route_shipment_loaded",
             "subject": {"type": "shipment"},
             "inputs": {"good": "cotton", "quantity": 2}},
            {"turn": 2, "kind": "feudal_tribute_transfer",
             "record_class": "transfer", "subject": {"good": "cotton"},
             "value_after": 1},
            {"turn": 2, "kind": "market_seller_receipt_posted",
             "record_class": "transfer", "subject": {"good": "cotton"},
             "value_after": 50},
        ]

        result = audit_run(run, events)

        self.assertTrue(result["passed"])
        self.assertEqual(result["summary_by_good"]["cotton"][
            "balanced_interval_count"], 1)
        self.assertEqual(result["summary_by_good"]["cloth"][
            "production_units"], 3.0)
        self.assertEqual(result["summary_by_good"]["cloth"][
            "household_nonfood_consumption_units"], 1.0)
        turnover = result["summary_by_good"]["cotton"]["internal_turnover"]
        self.assertEqual(turnover["paid_market_sale"]["reported_quantity"], 99)
        self.assertEqual(turnover["route_shipment_loaded"]["reported_quantity"], 2)
        self.assertEqual(turnover["feudal_tribute_transfer"]["event_count"], 1)
        self.assertEqual(turnover["market_seller_receipt_posted"][
            "reported_quantity"], 0)

    def test_missing_input_good_is_an_explicit_coverage_failure(self):
        run = self._run([
            {"turn": 1, "stocks": [{"good": "cotton", "quantity": 4}]},
            {"turn": 2, "stocks": [{"good": "cotton", "quantity": 4}]},
        ])
        events = [{
            "turn": 2, "kind": "firm_production",
            "subject": {"good": "cloth"}, "value_after": 1,
            "inputs": {"inputs_used": 1},
        }]

        result = audit_run(run, events)

        self.assertFalse(result["passed"])
        self.assertIn("missing_production_input_good",
                      [issue["kind"] for issue in result["issues"]])

    def test_missing_snapshot_interval_is_not_silently_skipped(self):
        run = self._run([
            {"turn": 1, "stocks": []},
            {"turn": 3, "stocks": []},
        ], completed_turns=3)

        result = audit_run(run, [])

        self.assertFalse(result["passed"])
        self.assertIn({"kind": "missing_consecutive_stock_snapshot", "turn": 2},
                      result["issues"])
        self.assertIn({"kind": "missing_consecutive_stock_snapshot", "turn": 3},
                      result["issues"])

    def test_report_uses_experiment_and_arm_as_distinct_columns(self):
        run = self._run([
            {"turn": 1, "stocks": []},
            {"turn": 2, "stocks": []},
        ])
        result = audit_run(run, [])

        report = render_markdown([result])

        self.assertIn("| 17 | cotton supply | cotton-control |", report)
        self.assertNotIn("| 17 | mill cotton demand |", report)

    def test_food_balance_includes_foraging_meals_and_granary_stock(self):
        run = self._run([
            {"turn": 1, "stocks": [
                {"good": "food", "pool": "inventory", "quantity": 10},
                {"good": "food", "pool": "granary_food", "quantity": 5},
            ]},
            {"turn": 2, "stocks": [
                {"good": "food", "pool": "inventory", "quantity": 11},
                {"good": "food", "pool": "granary_food", "quantity": 6},
            ]},
        ])
        events = [
            {"turn": 2, "kind": "independent_production",
             "subject": {"good": "food"}, "value_after": 1},
            {"turn": 2, "kind": "foraged_food_receipt",
             "subject": {"good": "food"}, "value_after": 2},
            {"turn": 2, "kind": "civilian_food_consumption_total",
             "subject": {"good": "food"}, "value_after": 1,
             "inputs": {"eaten_food_units": 1}},
            {"turn": 2, "kind": "granary_food_stock_transfer",
             "record_class": "transfer", "subject": {"good": "food"},
             "inputs": {"direction": "deposit", "units": 1}},
        ]

        result = audit_run(run, events)

        self.assertTrue(result["passed"])
        self.assertEqual(result["summary_by_good"]["food"][
            "foraged_food_units"], 2.0)
        self.assertEqual(result["summary_by_good"]["food"][
            "civilian_food_consumption_units"], 1.0)
        food_interval = next(row for row in result["intervals"]
                             if row["good"] == "food")
        self.assertEqual(food_interval["granary_stock_delta"], 1)
        self.assertEqual(result["summary_by_good"]["food"][
            "internal_turnover"]["granary_food_stock_transfer"][
                "reported_quantity"], 1)

    def test_unrecorded_granary_change_exposes_missing_stock_leg(self):
        run = self._run([
            {"turn": 1, "stocks": [
                {"good": "food", "pool": "inventory", "quantity": 10},
                {"good": "food", "pool": "granary_food", "quantity": 5},
            ]},
            {"turn": 2, "stocks": [
                {"good": "food", "pool": "inventory", "quantity": 12},
                {"good": "food", "pool": "granary_food", "quantity": 7},
            ]},
        ])
        events = [{
            "turn": 2, "kind": "civilian_food_consumption_total",
            "subject": {"good": "food"}, "value_after": 0,
            "inputs": {"eaten_food_units": 0},
        }]

        result = audit_run(run, events)

        self.assertFalse(result["passed"])
        food_interval = next(row for row in result["intervals"]
                             if row["good"] == "food")
        self.assertEqual(food_interval["granary_stock_delta"], 2)
        self.assertEqual(food_interval["residual"], 4)

    def test_legacy_food_census_uses_dispatch_and_arrival_to_reconstruct_cargo(self):
        run = self._run([
            {"turn": 1, "coverage": {"region_count": 1},
             "stocks": [{"good": "food", "quantity": 10}]},
            {"turn": 2, "coverage": {"region_count": 1},
             "stocks": [{"good": "food", "quantity": 2}]},
            {"turn": 3, "coverage": {"region_count": 1},
             "stocks": [{"good": "food", "quantity": 10}]},
        ], completed_turns=3)
        events = [
            {"turn": 2, "kind": "provincial_food_dispatch",
             "record_class": "transfer", "subject": {"good": "food"},
             "inputs": {"units": 8}},
            {"turn": 2, "kind": "civilian_food_consumption_total",
             "subject": {"id": "North", "good": "food"},
             "inputs": {"eaten_food_units": 0}},
            {"turn": 3, "kind": "provincial_food_arrival",
             "record_class": "transfer", "subject": {"good": "food"},
             "inputs": {"units": 8}},
            {"turn": 3, "kind": "civilian_food_consumption_total",
             "subject": {"id": "North", "good": "food"},
             "inputs": {"eaten_food_units": 0}},
        ]

        result = audit_run(run, events, audited_goods=("food",))

        self.assertTrue(result["passed"])
        dispatch_interval, arrival_interval = result["intervals"]
        self.assertEqual(dispatch_interval["census_stock_delta"], -8)
        self.assertEqual(dispatch_interval["provincial_food_cargo_change"], 8)
        self.assertFalse(
            dispatch_interval["provincial_food_cargo_census_included"])
        self.assertEqual(dispatch_interval["provincial_food_cargo_adjustment"], 8)
        self.assertEqual(dispatch_interval["residual"], 0)
        self.assertEqual(arrival_interval["census_stock_delta"], 8)
        self.assertEqual(arrival_interval["provincial_food_cargo_change"], -8)
        self.assertEqual(arrival_interval["provincial_food_cargo_adjustment"], -8)
        self.assertEqual(arrival_interval["residual"], 0)
        self.assertIn("reconstruct the in-transit cargo change",
                      render_markdown([result]))

    def test_food_census_with_provincial_cargo_does_not_double_count_events(self):
        run = self._run([
            {"turn": 1, "coverage": {
                "region_count": 1, "provincial_food_shipments_scanned": 0},
             "stocks": [{"good": "food", "quantity": 10}]},
            {"turn": 2, "coverage": {
                "region_count": 1, "provincial_food_shipments_scanned": 1},
             "stocks": [
                 {"good": "food", "pool": "inventory", "quantity": 2},
                 {"good": "food", "pool": "provincial_food_shipment",
                  "quantity": 8},
             ]},
        ])
        events = [
            {"turn": 2, "kind": "provincial_food_dispatch",
             "record_class": "transfer", "subject": {"good": "food"},
             "inputs": {"units": 8}},
            {"turn": 2, "kind": "civilian_food_consumption_total",
             "subject": {"id": "North", "good": "food"},
             "inputs": {"eaten_food_units": 0}},
        ]

        result = audit_run(run, events, audited_goods=("food",))

        self.assertTrue(result["passed"])
        interval = result["intervals"][0]
        self.assertEqual(interval["census_stock_delta"], 0)
        self.assertEqual(interval["provincial_food_cargo_change"], 8)
        self.assertTrue(interval["provincial_food_cargo_census_included"])
        self.assertEqual(interval["provincial_food_cargo_adjustment"], 0)
        self.assertEqual(interval["residual"], 0)

    def test_food_census_boundary_change_is_reported_as_unresolved(self):
        run = self._run([
            {"turn": 1, "coverage": {"region_count": 1},
             "stocks": [{"good": "food", "quantity": 10}]},
            {"turn": 2, "coverage": {
                "region_count": 1, "provincial_food_shipments_scanned": 0},
             "stocks": [{"good": "food", "quantity": 10}]},
        ])
        events = [{
            "turn": 2, "kind": "civilian_food_consumption_total",
            "subject": {"id": "North", "good": "food"},
            "inputs": {"eaten_food_units": 0},
        }]

        result = audit_run(run, events, audited_goods=("food",))

        self.assertFalse(result["passed"])
        interval = result["intervals"][0]
        self.assertTrue(
            interval["provincial_food_cargo_census_boundary_changed"])
        self.assertEqual(interval["provincial_food_cargo_adjustment"], 0)
        self.assertIn(
            "provincial_food_cargo_census_boundary_changed",
            [issue["kind"] for issue in result["issues"]])

    def test_food_aggregates_are_required_once_per_region(self):
        run = self._run([
            {"turn": 1, "coverage": {"region_count": 2},
             "stocks": [{"good": "food", "quantity": 10}]},
            {"turn": 2, "coverage": {"region_count": 2},
             "stocks": [{"good": "food", "quantity": 5}]},
        ])
        events = [
            {"turn": 2, "kind": "civilian_food_consumption_total",
             "subject": {"id": "North", "good": "food"},
             "inputs": {"eaten_food_units": 2}},
            {"turn": 2, "kind": "civilian_food_consumption_total",
             "subject": {"id": "South", "good": "food"},
             "inputs": {"eaten_food_units": 3}},
        ]

        result = audit_run(run, events)

        self.assertTrue(result["passed"])
        self.assertEqual(result["summary_by_good"]["food"][
            "civilian_food_consumption_units"], 5.0)

    def test_default_stock_census_can_audit_goods_outside_the_fixed_sample(self):
        run = self._run([])
        run.update({
            "scenario": "default",
            "experiment": "wood_supply_reduction",
            "arm": "control",
            "default_goods_stock_observations": [
                {"turn": 1, "coverage": {"region_count": 1}, "stocks": [
                    {"good": "iron", "quantity": 3},
                    {"good": "food", "quantity": 10},
                ]},
                {"turn": 2, "coverage": {"region_count": 1}, "stocks": [
                    {"good": "iron", "quantity": 5},
                    {"good": "food", "quantity": 10},
                ]},
            ],
        })
        events = [
            {"turn": 2, "kind": "independent_production",
             "subject": {"good": "iron"}, "value_after": 2},
            {"turn": 2, "kind": "civilian_food_consumption_total",
             "subject": {"id": "North", "good": "food"},
             "inputs": {"eaten_food_units": 0}},
        ]

        result = audit_run(run, events, audited_goods=("iron", "food"))

        self.assertTrue(result["passed"])
        self.assertEqual(result["summary_by_good"]["iron"][
            "balanced_interval_count"], 1)
        self.assertEqual(result["summary_by_good"]["food"][
            "balanced_interval_count"], 1)
        self.assertIn("# Selected-goods aggregate stock-flow audit",
                      render_markdown([result]))
        self.assertIn("| iron | 1 | 1 | 0 |",
                      render_markdown([result]))

    def test_tile_production_totals_override_detail_without_double_counting(self):
        run = self._run([])
        run.update({
            "completed_turns": 2,
            "default_goods_stock_observations": [
                {"turn": 1, "coverage": {"region_count": 1}, "stocks": [
                    {"good": "iron", "quantity": 0}]},
                {"turn": 2, "coverage": {"region_count": 1}, "stocks": [
                    {"good": "iron", "quantity": 10}]},
            ],
        })
        result = audit_run(run, [
            {"turn": 2, "kind": "independent_production",
             "subject": {"good": "iron"}, "value_after": 4},
            {"turn": 2, "kind": "tile_production_total",
             "subject": {"good": "iron"}, "value_after": 10},
        ], audited_goods=("iron",))

        self.assertTrue(result["passed"])
        self.assertEqual(result["intervals"][0]["production"], 10)
        self.assertEqual(result["intervals"][0]["production_source"],
                         "tile_production_total")

    def test_late_corvee_output_is_added_to_the_ordinary_tile_total(self):
        run = self._run([])
        run.update({
            "completed_turns": 2,
            "default_goods_stock_observations": [
                {"turn": 1, "stocks": [{"good": "cotton", "quantity": 0}]},
                {"turn": 2, "stocks": [{"good": "cotton", "quantity": 15}]},
            ],
        })
        result = audit_run(run, [
            {"turn": 2, "kind": "tile_production_total",
             "subject": {"good": "cotton"}, "value_after": 0},
            {"turn": 2, "kind": "elite_operator_execution",
             "inputs": {"operator_id": "corvee_cotton_plantation",
                        "execution_result": {"success": True, "yield": 15}}},
        ], audited_goods=("cotton",))

        self.assertTrue(result["passed"])
        self.assertEqual(result["intervals"][0]["production"], 15)
        self.assertEqual(result["intervals"][0]["operator_production"], 15)
        self.assertEqual(result["intervals"][0]["production_source"],
                         "tile_production_total+elite_operator_execution")

    def test_fertilizer_stock_changes_are_included_in_the_material_balance(self):
        run = self._run([
            {"turn": 1, "stocks": [{"good": "fertilizer", "quantity": 10}]},
            {"turn": 2, "stocks": [{"good": "fertilizer", "quantity": 13}]},
        ])
        result = audit_run(run, [
            {"turn": 2, "kind": "fertilizer_stock_inflow",
             "metric_id": "ecology.fertilizer_stock",
             "value_before": 10, "value_after": 15},
            {"turn": 2, "kind": "fertilizer_stock_use",
             "metric_id": "ecology.fertilizer_stock",
             "value_before": 15, "value_after": 13},
        ], audited_goods=("fertilizer",))

        self.assertTrue(result["passed"])
        interval = result["intervals"][0]
        self.assertEqual(interval["fertilizer_stock_change"], 3)
        self.assertEqual(interval["residual"], 0)
        report = render_markdown([result])
        self.assertIn("This selected-goods view", report)
        self.assertIn("Traced before/after fertilizer-reserve changes", report)

    def test_foreign_trader_sale_within_census_boundary_is_internal_turnover(self):
        run = self._run([
            {"turn": 1, "coverage": {"region_count": 1},
             "stocks": [{"good": "cotton", "quantity": 5}]},
            {"turn": 2, "coverage": {"region_count": 1},
             "stocks": [{"good": "cotton", "quantity": 5}]},
        ])
        result = audit_run(run, [
            {"turn": 2, "kind": "civilian_food_consumption_total",
             "subject": {"id": "North", "good": "food"},
             "inputs": {"eaten_food_units": 0}},
            {"turn": 2, "kind": "paid_market_sale", "record_class": "transfer",
             "subject": {"good": "cotton"}, "value_after": 2,
             "inputs": {"imported": True, "source_region": None,
                        "seller_account_tile": "South"}},
        ])

        self.assertTrue(result["passed"])
        self.assertEqual(result["summary_by_good"]["cotton"][
            "internal_turnover"]["paid_market_sale"]["reported_quantity"], 2)

    def test_all_physical_goods_report_labels_and_orders_the_balance_summary(self):
        goods = (
            "food", "wood", "furniture", "transport", "wool", "cloth",
            "nitrates", "cotton", "iron_ore", "iron", "coal", "tobacco",
            "sugar", "tea", "fine_textiles", "porcelain", "rum",
            "foreign_luxuries", "fertilizer",
        )
        result = audit_run(self._run([]), [], audited_goods=goods)

        report = render_markdown([result])

        self.assertIn("# All-physical-goods aggregate stock-flow audit", report)
        self.assertIn("no nonzero source-linked fertilizer", report)
        self.assertLess(report.index("| fertilizer |"),
                        report.index("Complete stock-flow closure:"))


if __name__ == "__main__":
    unittest.main()
