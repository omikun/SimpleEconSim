from treasury_trace import begin_public_change as _trace_public_begin, finish_public_change as _trace_public_finish
from treasury_trace import begin_public_change, finish_public_change
import math
import bisect
import random
from collections import defaultdict
from goods import Goods
from logger import *
from econsim_states import recipes
from bank_trace import begin_change, finish_change

inventory_limit = 10


def get_input_commodity(agent, recipes):
    recipe = recipes[agent.output]
    input_com = recipe.get('input', Goods.none)
    return input_com


def get_output_commodity(agent):
    return agent.output


class Offer:
    def __init__(self, is_bid, agent, price, quantity):
        self.is_bid = is_bid
        self.agent = agent
        self.price = price
        self.quantity = quantity


def lerp(a, b, t):
    return a + (b - a) * t


def clamp(x, min_x, max_x):
    return max(min_x, min(x, max_x))


class Loan:
    def __init__(self, bank, agent, principle, interest_rate):
        self.bank = bank
        self.agent = agent
        self.principle = principle
        self.interest_rate = interest_rate
        self.interest_paid = 0
        self.principle_paid = 0
        self.num_payments = 100

    def isPaid(self):
        return self.principle_paid >= self.principle

    def getInterest(self):
        remaining_principle = self.principle - self.principle_paid
        return self.interest_rate * remaining_principle

    def getPaymentAmount(self):
        remaining_principle = self.principle - self.principle_paid
        interest = self.getInterest()
        payment = interest + self.principle / self.num_payments
        return payment

    def pay(self, amount):
        # Conservation guard: a negative "payment" (possible when the agent's
        # total wealth fell below zero) would pay NEGATIVE interest into the
        # bank — destroying deposits without any cash transfer.  Clamp to 0.
        if amount <= 0:
            return
        trace_change = begin_change(self.bank, self.bank._region_for_account(self.agent))
        interest_paid = min(self.getInterest(), amount)
        principle_paid = max(0, amount - interest_paid)
        self.principle_paid += principle_paid
        self.interest_paid += interest_paid
        self.bank.pay_principle(principle_paid)
        self.bank.pay_interest(interest_paid)
        finish_change(self.bank, trace_change, 'loan_payment', inputs={
            'borrower_id': getattr(self.agent, 'id', None),
            'payment': amount, 'principal_paid': principle_paid, 'interest_paid': interest_paid})


class Bank():
    def __init__(self, gov=None):
        self.interest_rate = .001
        self.deposit_interest_rate = 0.0005
        self.base_deposit_interest_rate = 0.0005
        # Shareholder equity: seed capital + retained earnings (loan interest
        # less deposit interest) less bad-debt write-downs.  The old phantom
        # 2000-base that lived inside total_deposits is now an explicit,
        # countable capital tier — losses absorb here FIRST (Basel-style loss
        # absorption) before any depositor is touched.
        self.capital = 2000.0
        self.total_deposits = 0.0
        self.reserve_fraction = .1
        self.loans = []
        self.total_liabilities = 0
        self.deposits = defaultdict(int)
        self.total_interest_earned = 0
        self.total_deposit_interest_paid = 0
        self.turn_loan_interest = 0
        self.gov = gov  # Reference to tile government (lender of last resort)

        # ---- Multi-currency FX (Phase 1) ----
        self.foreign_reserves = defaultdict(float)   # currency -> holdings
        self.fx_pool = 0.0                           # domestic money for FX desk

        # ---- Sovereign Debt Nexus & Domestic Contagion (Priority B) ----
        self.sovereign_bonds_held = []               # list of held sovereign debt tranches
        self.is_frozen = False                       # Corralito / Emergency deposit freeze flag
        self.frozen_turns = 0                        # turns under freeze
        self.subsistence_withdrawal_cap = 5.0        # max emergency withdrawal allowed per turn
        self.cumulative_writedowns = 0.0             # cumulative bond write-downs absorbed

    def _region_for_account(self, agent):
        return next((r for r in getattr(self, '_attached_regions', [])
                     if any(a is agent for a in getattr(r, 'agents', []))), None)

    def _record_account_event(self, agent, kind, amount, *, payer=False,
                              recipient=False, detail=None, region=None,
                              turn=None):
        region = region or self._region_for_account(agent)
        if region is None or amount <= 0:
            return None
        from economy.actor_accounts import record
        event_turn = (turn if turn is not None else
                      getattr(region, '_last_turn',
                              getattr(region, '_economic_opening_turn', 0)))
        return record(region, kind, turn=event_turn, payer_id=agent.id if payer else None,
               recipient_id=agent.id if recipient else None, amount=amount,
               asset_id=f"bank:{region.name}",
               currency=getattr(region, 'home_currency', None),
               detail=detail or {})

    def _trace_cash_savings(self, region, kind, agent, amount, requested,
                            cash_before, cash_after, deposit_before,
                            deposit_after, total_before, total_after,
                            *, turn=None, reason='unspecified', blocked=False,
                            frozen_cap=None):
        if region is None:
            return
        from run_trace import emit
        is_deposit = kind == 'bank_deposit'
        trace_kind = ('bank_deposit_posted' if is_deposit else
                      'bank_withdrawal_blocked' if blocked else
                      'bank_withdrawal_posted')
        return emit(region, kind=trace_kind,
             record_class='transfer' if amount > 0 else 'outcome',
             phase='finance',
             subject={'type': 'bank_account', 'id': str(agent.id),
                      'tile': region.name},
             metric_id='finance.bank_deposit' if is_deposit else 'finance.bank_withdrawal',
             unit=getattr(region, 'home_currency', None) or 'local_currency',
             before=deposit_before, after=deposit_after,
             formula_id='bank.cash_to_deposit.v1' if is_deposit else
                        'bank.deposit_to_cash.v1',
             inputs={'agent_id': agent.id,
                     'institution_id': f'bank:{region.name}',
                     'requested_amount': float(requested),
                     'settled_amount': float(amount),
                     'reason': reason,
                     'cash_before': float(cash_before),
                     'cash_after': float(cash_after),
                     'deposit_before': float(deposit_before),
                     'deposit_after': float(deposit_after),
                     'bank_deposits_before': float(total_before),
                     'bank_deposits_after': float(total_after),
                     'turn': int(turn) if turn is not None else None,
                     'bank_frozen': bool(getattr(self, 'is_frozen', False)),
                     'frozen_withdrawal_cap': frozen_cap,
                     'blocked': bool(blocked)})

    @property
    def equity(self):
        """Real countable net worth: capital + deposits - loans outstanding."""
        return self.capital + self.total_deposits - self.total_liabilities

    def Borrow(self, t, agent, amount, trace_region=None, *, trace_treasury=True):
        if getattr(self, 'is_frozen', False):
            loginfo(t, "Borrowing blocked: Bank is under Corralito deposit freeze.")
            if trace_region is not None:
                from run_trace import emit
                emit(trace_region, kind='bank_loan_denied', record_class='outcome',
                     subject={'type': 'tile', 'id': trace_region.name,
                              'agent_id': getattr(agent, 'id', None)},
                     metric_id='finance.bank_loan', unit='local_currency',
                     before=0.0, after=0.0,
                     inputs={'requested_amount': float(amount), 'reason': 'bank_frozen',
                             'bank_capital': self.capital, 'bank_liabilities': self.total_liabilities,
                             'bank_deposits': self.total_deposits})
            return 0
        requested_amount = float(amount)
        borrowable_amount = ((self.capital + self.total_deposits)
                             * (1 - self.reserve_fraction)
                             - self.total_liabilities)
        amount = clamp(amount, 0, borrowable_amount)
        loginfo(t, "borrowing from bank with $", self.total_deposits,
                " deposit and $", self.total_liabilities,
                "borrowable: $", borrowable_amount, " lending: $", amount)
        if amount <= 0:
            if trace_region is not None:
                from run_trace import emit
                emit(trace_region, kind='bank_loan_denied', record_class='outcome',
                     subject={'type': 'tile', 'id': trace_region.name,
                              'agent_id': getattr(agent, 'id', None)},
                     metric_id='finance.bank_loan', unit='local_currency',
                     before=0.0, after=0.0,
                     inputs={'requested_amount': requested_amount,
                             'borrowable_amount': borrowable_amount,
                             'reason': 'capacity_exhausted',
                             'bank_capital': self.capital, 'bank_liabilities': self.total_liabilities,
                             'bank_deposits': self.total_deposits})
            return amount
        trace_change = begin_change(self, trace_region)
        loan = Loan(self, agent, amount, self.interest_rate)
        public_change = begin_public_change(trace_region or self._region_for_account(agent), agent, bank=self, cash=True)
        agent.cash += amount
        finish_public_change(public_change, 'bank_credit')
        agent.loans.append(loan)
        self.loans.append(loan)
        self.total_liabilities += amount
        self._record_account_event(agent, 'bank_loan', float(amount), recipient=True,
                                   detail={'loan_principal': amount}, region=trace_region)
        credit_event_id = None
        if trace_region is not None:
            from run_trace import emit
            credit_event_id = emit(trace_region, kind='bank_loan_issued', record_class='transfer',
                 subject={'type': 'tile', 'id': trace_region.name,
                          'agent_id': getattr(agent, 'id', None)},
                 metric_id='finance.bank_loan', unit='local_currency', after=amount,
                 inputs={'requested_amount': requested_amount,
                         'borrowable_amount': borrowable_amount,
                         'reserve_fraction': self.reserve_fraction,
                         'interest_rate': self.interest_rate,
                         'borrower_is_corporation': bool(getattr(agent, 'is_corporation', False)),
                         'borrower_is_government': bool(getattr(agent, 'is_government', False)),
                         'bank_capital': self.capital, 'bank_liabilities_after': self.total_liabilities,
                         'bank_deposits': self.total_deposits})
        finish_change(self, trace_change, 'loan_issued', inputs={
            'borrower_id': getattr(agent, 'id', None), 'requested_amount': requested_amount,
            'settled_amount': amount, 'interest_rate': self.interest_rate},
            cause_event_ids=[credit_event_id] if credit_event_id else None)
        if trace_treasury:
            from finance_trace import emit_public_account_flow
            region = trace_region or self._region_for_account(agent)
            emit_public_account_flow(region, agent, kind='government_automatic_bank_credit',
                                     signed_amount=amount,
                                     inputs={'requested_amount': requested_amount, 'interest_rate': self.interest_rate},
                                     cause_event_ids=[credit_event_id] if credit_event_id else None)
        return amount

    def pay_principle(self, amount):
        self.total_liabilities -= amount

    def pay_interest(self, amount):
        # Retained earnings accrue to bank capital (shareholder equity), NOT to
        # deposits.  Crediting interest to total_deposits (the old behaviour)
        # was the phantom-base divergence source: it grew the deposit scalar
        # without a matching per-agent dict entry.
        self.capital += amount
        self.total_interest_earned += amount

    def Deposit(self, agent, amount, *, trace_region=None, t=None,
                reason='unspecified'):
        requested = float(amount)
        if requested <= 0:
            return 0.0
        assert agent.cash >= requested
        region = trace_region or self._region_for_account(agent)
        cash_before = float(agent.cash)
        deposit_before = float(self.deposits[agent])
        total_before = float(self.total_deposits)
        trace_change = begin_change(self, region)
        public_change = begin_public_change(region, agent, bank=self, cash=True, deposit=True)
        agent.cash -= requested
        self.total_deposits += requested
        self.deposits[agent] += requested
        finish_public_change(public_change, 'cash_to_deposit')
        cash_after = float(agent.cash)
        deposit_after = float(self.deposits[agent])
        total_after = float(self.total_deposits)
        detail = {'requested_amount': requested, 'settled_amount': requested,
                  'reason': reason, 'cash_before': cash_before,
                  'cash_after': cash_after, 'deposit_before': deposit_before,
                  'deposit_after': deposit_after,
                  'bank_deposits_before': total_before,
                  'bank_deposits_after': total_after}
        self._record_account_event(agent, 'bank_deposit', requested, payer=True,
                                   detail=detail, region=region, turn=t)
        event_id = self._trace_cash_savings(region, 'bank_deposit', agent, requested,
                                 requested, cash_before, cash_after,
                                 deposit_before, deposit_after,
                                 total_before, total_after, turn=t, reason=reason)
        finish_change(self, trace_change, 'deposit', inputs={
            'agent_id': getattr(agent, 'id', None), 'amount': requested, 'reason': reason},
            cause_event_ids=[event_id] if event_id else None)
        return requested

    def Withdraw(self, agent, amount, *, trace_region=None, t=None,
                 reason='unspecified', trace_event_ids=None):
        requested = max(0.0, float(amount))
        region = trace_region or self._region_for_account(agent)
        cash_before = float(agent.cash)
        deposit_before = float(self.deposits[agent])
        total_before = float(self.total_deposits)
        limit = deposit_before
        frozen_cap = None
        if getattr(self, 'is_frozen', False):
            frozen_cap = float(getattr(self, 'subsistence_withdrawal_cap', 5.0))
            limit = min(limit, frozen_cap)
        settled = float(clamp(requested, 0.0, limit))
        if settled <= 0:
            if requested > 0:
                event_id = self._trace_cash_savings(
                    region, 'bank_withdrawal', agent, 0.0, requested,
                    cash_before, cash_before, deposit_before, deposit_before,
                    total_before, total_before, turn=t, reason=reason,
                    blocked=True, frozen_cap=frozen_cap)
                if trace_event_ids is not None and event_id is not None:
                    trace_event_ids.append(event_id)
            return 0.0
        trace_change = begin_change(self, region)
        public_change = begin_public_change(region, agent, bank=self, cash=True, deposit=True)
        agent.cash += settled
        self.total_deposits -= settled
        self.deposits[agent] -= settled
        finish_public_change(public_change, 'deposit_to_cash')
        cash_after = float(agent.cash)
        deposit_after = float(self.deposits[agent])
        total_after = float(self.total_deposits)
        detail = {'requested_amount': requested, 'settled_amount': settled,
                  'reason': reason, 'cash_before': cash_before,
                  'cash_after': cash_after, 'deposit_before': deposit_before,
                  'deposit_after': deposit_after,
                  'bank_deposits_before': total_before,
                  'bank_deposits_after': total_after,
                  'bank_frozen': bool(getattr(self, 'is_frozen', False)),
                  'frozen_withdrawal_cap': frozen_cap}
        self._record_account_event(agent, 'bank_withdrawal', settled,
                                   recipient=True, detail=detail,
                                   region=region, turn=t)
        event_id = self._trace_cash_savings(
            region, 'bank_withdrawal', agent, settled, requested,
            cash_before, cash_after, deposit_before, deposit_after,
            total_before, total_after, turn=t, reason=reason,
            frozen_cap=frozen_cap)
        if trace_event_ids is not None and event_id is not None:
            trace_event_ids.append(event_id)
        finish_change(self, trace_change, 'withdrawal', inputs={
            'agent_id': getattr(agent, 'id', None), 'amount': settled, 'reason': reason},
            cause_event_ids=[event_id] if event_id else None)
        return settled

    def write_down_bonds(self, loss_amount: float, trace_region=None, *,
                         bond_id=None, issuer_nation=None, default_kind='sovereign_default',
                         defaulted_amount=None, turn=None) -> bool:
        """Absorb sovereign debt default losses against bank Tier-1 capital.

        If capital is depleted (<= 0), triggers emergency Corralito deposit freeze.
        """
        trace_change = begin_change(self, trace_region)
        loss_amount = float(loss_amount)
        capital_before = self.capital
        deposit_freeze_before = bool(getattr(self, 'is_frozen', False))
        self.capital -= loss_amount
        self.cumulative_writedowns += loss_amount
        if self.capital <= 0.0:
            self.is_frozen = True
        region = trace_region or next(iter(getattr(self, '_attached_regions', ())), None)
        details = {
            'institution_id': f"bank:{getattr(region, 'name', 'unknown')}",
            'bond_id': bond_id,
            'issuer_nation': issuer_nation,
            'default_kind': default_kind,
            'defaulted_amount': float(defaulted_amount)
            if defaulted_amount is not None else None,
            'loss_amount': loss_amount,
            'capital_before': capital_before,
            'capital_after': self.capital,
            'equity_before': capital_before + self.total_deposits - self.total_liabilities,
            'equity_after': self.equity,
            'deposits': float(self.total_deposits),
            'liabilities': float(self.total_liabilities),
            'cumulative_writedowns': float(self.cumulative_writedowns),
            'deposit_freeze_before': deposit_freeze_before,
            'deposit_freeze_after': bool(self.is_frozen),
        }
        if region is not None:
            from economy.actor_accounts import record
            record(region, 'bank_bond_writeoff', turn=turn,
                   amount=loss_amount, asset_id=bond_id,
                   detail={key: value for key, value in details.items() if value is not None})
        if trace_region is not None:
            from run_trace import emit
            emit(trace_region, kind='bank_bond_write_down', record_class='outcome',
                 subject={'type': 'tile', 'id': trace_region.name},
                 metric_id='finance.bank_capital', unit='local_currency',
                 before=capital_before, after=self.capital,
                 inputs=details)
            emit(trace_region, kind='bank_bond_asset_impaired', record_class='outcome',
                 subject={'type': 'tile', 'id': trace_region.name,
                          'bond_id': bond_id, 'issuer': issuer_nation},
                 metric_id='finance.bank_bond_writeoff', unit='local_currency',
                 after=loss_amount, inputs=details)
        finish_change(self, trace_change, 'bond_write_down', inputs=details)
        return self.is_frozen

    def recapitalize(self, amount: float, trace_region=None, *,
                     operation_id=None, return_event_id=False):
        """Inject recapitalization funds into bank capital.

        If capital is restored (> 0), lifts emergency deposit freeze.
        """
        trace_change = begin_change(self, trace_region)
        capital_before = self.capital
        self.capital += amount
        if self.capital > 0.0:
            self.is_frozen = False
            self.frozen_turns = 0
        event_id = None
        if trace_region is not None:
            from run_trace import emit
            event_id = emit(
                trace_region, kind='bank_recapitalization', record_class='outcome',
                subject={'type': 'tile', 'id': trace_region.name},
                metric_id='finance.bank_capital', unit='local_currency',
                before=capital_before, after=self.capital,
                inputs={'injection': amount, 'deposit_freeze_after': self.is_frozen,
                        'operation_id': operation_id})
        finish_change(self, trace_change, 'recapitalization', inputs={
            'injection': amount, 'operation_id': operation_id},
            cause_event_ids=[event_id] if event_id else None)
        result = not self.is_frozen
        return (result, event_id) if return_event_id else result

    def apply_bail_in_haircut(self, haircut_pct: float = 0.25, exemption_floor: float = 50.0,
                              trace_region=None, *, return_event_id=False):
        """Execute a Cyprus-style statutory bail-in haircut on large deposits.

        Converts uninsured deposit liabilities into Tier-1 shareholder equity.
        """
        trace_change = begin_change(self, trace_region)
        total_haircut = 0.0
        affected = []
        bailin_event_ids = []
        capital_before = self.capital
        deposits_before = self.total_deposits
        for agent, dep in list(self.deposits.items()):
            if dep > exemption_floor:
                excess = dep - exemption_floor
                cut = round(excess * haircut_pct, 2)
                if cut > 0:
                    depositor_balance_before = float(dep)
                    bank_capital_before = float(self.capital)
                    public_change = begin_public_change(trace_region, agent, bank=self, cash=False, deposit=True)
                    self.deposits[agent] -= cut
                    finish_public_change(public_change, 'statutory_deposit_bail_in')
                    self.total_deposits -= cut
                    self.capital += cut
                    total_haircut += cut
                    self._record_account_event(agent, 'bank_deposit_haircut',
                                               float(cut), payer=True,
                                               detail={'deposit_haircut': True})
                    affected.append({'agent_id': getattr(agent, 'id', None),
                                     'deposit_before': dep,
                                     'deposit_after': float(self.deposits[agent]),
                                     'haircut': cut})
                    # Psychological and grievance impact on depositor
                    if hasattr(agent, 'despair'):
                        agent.despair = min(1.0, getattr(agent, 'despair', 0.0) + 0.20)
                    if hasattr(agent, 'alienation'):
                        agent.alienation = min(1.0, getattr(agent, 'alienation', 0.0) + 0.15)
                    if trace_region is not None:
                        from finance_trace import account_ref
                        from run_trace import emit
                        owner_nation = getattr(trace_region, 'owner_nation', None)
                        currency = (getattr(owner_nation, 'currency', None)
                                    or getattr(trace_region, 'home_currency', None)
                                    or 'local_currency')
                        clock = getattr(trace_region, '_collective_trace_clock', {}) or {}
                        turn = int(clock.get('turn',
                                             getattr(trace_region, '_last_turn', 0)))
                        operation_id = (f'bank-bail-in:{trace_region.name}:{turn}:'
                                        f'{getattr(agent, "id", None)}')
                        deposit_account = account_ref(
                            'depositor_bank_deposit', getattr(agent, 'id', None), currency,
                            balance_before=depositor_balance_before,
                            balance_after=float(self.deposits[agent]),
                            balance_scope='depositor_bank_deposit')
                        capital_account = account_ref(
                            'bank_capital', trace_region.name, currency,
                            balance_before=bank_capital_before,
                            balance_after=float(self.capital), balance_scope='capital')
                        contract = {
                            'contract_version': 'bank_bailin.v1',
                            'operation_id': operation_id,
                            'operation_type': 'deposit_to_equity_conversion',
                            'amount': float(cut), 'amount_currency': currency,
                            'side': 'depositor_asset_loss_bank_equity_gain',
                            'payer_account': deposit_account,
                            'payee_account': capital_account,
                            'cash_movement': False,
                            'currency_conversion_applied': False,
                            'counterparty_leg_status': 'deposit_reduction_matches_equity_increase',
                            'mutation_reference': {'bank_tile': trace_region.name,
                                                   'depositor_id': getattr(agent, 'id', None),
                                                   'haircut_fraction': float(haircut_pct),
                                                   'exemption_floor': float(exemption_floor)},
                        }
                        event_id = emit(
                            trace_region, kind='bank_depositor_bail_in_transfer',
                            record_class='transfer', phase='banking_policy',
                            subject={'type': 'tile', 'id': trace_region.name,
                                     'depositor_id': getattr(agent, 'id', None)},
                            metric_id='finance.bank_bailin_transfer', unit=currency,
                            after=float(cut), inputs={'operation_id': operation_id,
                                'transfer_contract': contract,
                                'deposit_before': depositor_balance_before,
                                'deposit_after': float(self.deposits[agent]),
                                'bank_capital_before': bank_capital_before,
                                'bank_capital_after': float(self.capital),
                                'haircut_fraction': float(haircut_pct),
                                'exemption_floor': float(exemption_floor)})
                        if event_id is not None:
                            bailin_event_ids.append(event_id)
                        affected[-1]['operation_id'] = operation_id
        if self.capital > 0.0:
            self.is_frozen = False
            self.frozen_turns = 0
        if trace_region is not None:
            from run_trace import emit
            aggregate_event_id = emit(
                 trace_region, kind='bank_depositor_bail_in', record_class='outcome',
                 subject={'type': 'tile', 'id': trace_region.name},
                 metric_id='finance.bank_capital', unit='local_currency',
                 before=capital_before, after=self.capital,
                 inputs={'haircut_fraction': haircut_pct,
                         'exemption_floor': exemption_floor,
                         'total_haircut': total_haircut,
                         'deposits_before': deposits_before,
                         'deposits_after': self.total_deposits,
                         'affected_depositors': affected,
                         'deposit_transfer_event_ids': bailin_event_ids,
                         'deposit_freeze_after': self.is_frozen})
        else:
            aggregate_event_id = None
        finish_change(self, trace_change, 'deposit_bail_in', inputs={
            'haircut_fraction': haircut_pct, 'exemption_floor': exemption_floor,
            'affected_depositors': affected, 'total_haircut': total_haircut},
            cause_event_ids=[aggregate_event_id] if aggregate_event_id else None)
        return ((total_haircut, aggregate_event_id) if return_event_id
                else total_haircut)

    def PayDepositInterest(self, agents, trace_region=None):
        """Pay interest to all depositors based on their deposit balance.

        Interest rate is reduced as deposit ratio increases (Fix F).  Payout is
        funded out of bank CAPITAL (retained earnings from loan interest), NOT
        out of deposits, so total_deposits stays in lockstep with the per-agent
        dict.  Capped to 60% of estimated loan interest (bank keeps 40% margin)
        and to available capital so capital never turns negative.
        """
        capital_before = self.capital
        trace_change = begin_change(self, trace_region)
        total_interest_before = self.total_deposit_interest_paid
        circulating_cash = max(1, sum(agent.cash for agent in agents))
        deposit_ratio = self.total_deposits / circulating_cash
        if deposit_ratio < 5:
            self.deposit_interest_rate = self.base_deposit_interest_rate
        elif deposit_ratio < 10:
            self.deposit_interest_rate = self.base_deposit_interest_rate * 0.4
        else:
            self.deposit_interest_rate = self.base_deposit_interest_rate * 0.1
        estimated_loan_interest = sum(
            loan.getInterest() for loan in self.loans
        )
        max_total_payout = min(
            estimated_loan_interest * 0.6,
            max(0.0, self.capital),
        )
        total_payout = 0
        for agent, amount in list(self.deposits.items()):
            interest = amount * self.deposit_interest_rate
            if interest > 0:
                remaining_capacity = max(0, max_total_payout - total_payout)
                interest = min(interest, remaining_capacity)
                if interest > 0:
                    public_change = begin_public_change(trace_region or self._region_for_account(agent), agent, bank=self, cash=True)
                    agent.cash += interest
                    finish_public_change(public_change, 'deposit_interest')
                    self.capital -= interest
                    from finance_trace import emit_public_account_flow
                    region = trace_region or self._region_for_account(agent)
                    emit_public_account_flow(
                        region, agent, kind='government_deposit_interest_received',
                        signed_amount=interest,
                        inputs={'deposit_balance': amount, 'rate': self.deposit_interest_rate,
                                'funded_from_bank_capital': True})
                    self.total_deposit_interest_paid += interest
                    total_payout += interest
                    self._record_account_event(agent, 'bank_deposit_interest',
                                               float(interest), recipient=True,
                                               detail={'funded_from_bank_capital': True})
        interest_event_id = None
        if trace_region is not None:
            from run_trace import emit
            interest_event_id = emit(trace_region, kind='bank_deposit_interest_payout', record_class='transfer',
                 subject={'type': 'tile', 'id': trace_region.name},
                 metric_id='finance.bank_deposit_interest', unit='local_currency',
                 after=total_payout,
                 inputs={'deposit_interest_rate': self.deposit_interest_rate,
                         'deposit_ratio': deposit_ratio,
                         'estimated_loan_interest': estimated_loan_interest,
                         'payout_cap': max_total_payout,
                         'capital_before': capital_before, 'capital_after': self.capital,
                         'cumulative_interest_paid_before': total_interest_before,
                         'cumulative_interest_paid_after': self.total_deposit_interest_paid})
        finish_change(self, trace_change, 'deposit_interest', inputs={
            'total_payout': total_payout, 'deposit_interest_rate': self.deposit_interest_rate,
            'payout_cap': max_total_payout},
            cause_event_ids=[interest_event_id] if interest_event_id else None)
        return total_payout


bank = Bank()


def Borrow(t, agent, food_price, bank, trace_region=None):
    amount = food_price * 1.2
    bank.Borrow(t, agent, amount, trace_region=trace_region)


def borrow_if_needed(t, agent, bank=None, trace_region=None):
    if bank is None:
        bank = globals().get('bank', None)
        if bank is None:
            return
    wealth = agent.wealth()
    if wealth < agent.owed_this_turn():
        needed = agent.owed_this_turn() - wealth
        Borrow(t, agent, needed * 2, bank, trace_region=trace_region)


def PayLoans(agent, bank=None, trace_region=None, t=None):
    if bank is None:
        bank = globals().get('bank', None)
        if bank is None:
            return
    total_wealth = agent.cash + bank.deposits[agent]
    remaining_wealth = total_wealth
    total_paid = 0
    active_loans = list(agent.loans)
    interest_before = sum(loan.interest_paid for loan in active_loans)
    principal_before = sum(loan.principle_paid for loan in active_loans)
    for loan in agent.loans:
        # Conservation guard: never pay more than the agent actually holds.
        # A negative remaining_wealth (overdrawn agent) must not produce a
        # negative "payment" — that would flow negative interest into the
        # bank and destroy deposits without any cash transfer.  Also ensures
        # agent.cash can't be driven further negative by the Withdraw path.
        if remaining_wealth <= 0:
            break
        payment = min(remaining_wealth, loan.getPaymentAmount())
        loan.pay(payment)
        total_paid += payment
        remaining_wealth -= payment
    if total_paid > 0:
        if total_paid > agent.cash:
            needed_from_bank = total_paid - agent.cash
            bank.Withdraw(agent, needed_from_bank, trace_region=trace_region,
                          t=t, reason='bank_loan_repayment')
        public_change = begin_public_change(trace_region or bank._region_for_account(agent), agent, bank=bank, cash=True)
        agent.cash -= total_paid
        finish_public_change(public_change, 'ordinary_loan_repayment')
        from finance_trace import emit_public_account_flow
        region = trace_region or bank._region_for_account(agent)
        emit_public_account_flow(region, agent, kind='government_ordinary_loan_repayment',
                                 signed_amount=-total_paid,
                                 inputs={'cash_after': agent.cash, 'deposits_after': bank.deposits.get(agent, 0)})
        bank._record_account_event(agent, 'bank_loan_repayment', float(total_paid),
                                   payer=True, detail={
                                       'principal_repaid': sum(loan.principle_paid for loan in active_loans)
                                       - principal_before,
                                       'interest_paid': sum(loan.interest_paid for loan in active_loans)
                                       - interest_before}, region=trace_region,
                                   turn=t)
    agent.loans = [l for l in agent.loans if not l.isPaid()]
    if total_paid > 0 and trace_region is not None:
        from run_trace import emit
        emit(trace_region, kind='bank_loan_repayment', record_class='transfer',
             subject={'type': 'tile', 'id': trace_region.name,
                      'agent_id': getattr(agent, 'id', None)},
             metric_id='finance.bank_loan_repayment', unit='local_currency',
             after=total_paid,
             inputs={'principal_repaid': sum(loan.principle_paid for loan in active_loans)
                     - principal_before,
                     'interest_paid': sum(loan.interest_paid for loan in active_loans)
                     - interest_before,
                     'cash_after': agent.cash,
                     'deposits_after': bank.deposits.get(agent, 0),
                     'remaining_loan_count': len(agent.loans)})


# =============================================================================
# TRADE — entry point
# =============================================================================

def Trade(t, agents, recipes, demand_ratio_log, demand_log,
          supply_log, sold_log, bought_log, trace_context=None):
    previous_total_cash = get_total_cash(agents, bank)
    max_demand_ratio = 0
    goods = [Goods.food, Goods.wood, Goods.furniture]
    opening_prices = {good: recipes[good]['price'] for good in goods}
    if trace_context is not None:
        clock = trace_context._collective_trace_clock
        clock.update(turn=t, phase='market')
    number_desired = 16
    all_goods_price = sum(recipes[good]['price'] for good in goods)
    food_price = recipes[Goods.food]['price']
    random.shuffle(agents)
    interest_paid = bank.PayDepositInterest(agents)
    if interest_paid > 0:
        loginfo(t, "Bank paid $", round(interest_paid, 2),
                "in deposit interest at rate", bank.deposit_interest_rate)
    report_cash(t, agents, previous_total_cash, "pre borrow and deposit", True)
    decide_borrow_deposit(agents, all_goods_price, bank, food_price,
                          previous_total_cash, t)
    report_cash(t, agents, previous_total_cash, "post borrow and deposit")
    for good in goods:
        if good == Goods.food:
            current_desired = 16
        elif good == Goods.wood:
            current_desired = 10
        else:
            current_desired = max(1, int(16 / max(1, recipes[good]['price'])))
        loginfo(t, 'bids and asks for ', good)
        price = recipes[good]['price']
        total_asks, total_bids = gather_bids_asks(t, agents, good, price,
                                                   current_desired, recipes,
                                                   0, 0)
        total_trades = min(total_asks, total_bids)
        if total_asks == 0 and total_bids == 0:
            _price_default_decay(good, recipes, trace_context=trace_context)
            continue
        demand_ratio = 5.0 if total_asks == 0 else total_bids / total_asks
        if max_demand_ratio < demand_ratio and total_bids > 0:
            max_demand_ratio = demand_ratio
        demand_ratio_log.setdefault(good, [])
        demand_ratio_log[good].append(demand_ratio)
        demand_log[good].append(total_bids)
        supply_log[good].append(total_asks)
        price = set_market_price(demand_ratio, good, recipes, agents,
                                 trace_context=trace_context)
        if total_trades == 0:
            continue
        logdebug(t, "trading ", good, " at $", round(price, 2),
                 "demand_ratio:", round(demand_ratio, 2),
                 " asks: ", round(total_asks, 2),
                 " bids: ", round(total_bids, 2))
        total_bought, total_cash_purchases = \
            bidders_buy_good(t, agents, good, bought_log, price, total_asks, 0)
        askers = sorted(agents, key=lambda a: a.ask, reverse=True)
        total_cash_sales, total_sold = \
            askers_sell_good(askers, good, price, t, total_bought,
                             total_cash_purchases, 0, 0)
        diff = math.fabs(total_cash_sales - total_cash_purchases)
        if diff > .1:
            logwarning(t, "traded", good, "demand:", demand_ratio,
                       "price:", price, "trades: ", good, " traded: ", 0,
                       "total bought", total_bought, "totalSold", total_sold,
                       "cash bought $", total_cash_purchases,
                       "cash sold $", total_cash_sales, "diff",
                       math.fabs(total_cash_sales - total_cash_purchases))
        sold_log[good].append(total_sold)
        report_cash(t, agents, previous_total_cash, "post primary trade " + str(good))
        sec_traded, sec_value = secondary_trade(t, agents, good, price, recipes)
        if sec_traded > 0:
            logdebug(t, "secondary traded", good, "vol:", sec_traded,
                     "value:$", round(sec_value, 2))
        report_cash(t, agents, previous_total_cash, "post secondary trade " + str(good))

    if trace_context is not None:
        clock = trace_context._collective_trace_clock
        for good in goods:
            subject = {'type': 'simulation', 'id': 'econsim', 'good': good.name}
            before = opening_prices[good]
            after = recipes[good]['price']
            trace_context._run_trace.snapshot(
                clock, subject=subject, metric_id='goods.price',
                unit='local_currency_per_unit', before=before, after=after)
            trace_context._run_trace.price_bridge(
                clock, subject=subject, before=before, after=after,
                unit='local_currency_per_unit')


# =============================================================================
# PRICE DEFAULT DECAY
# =============================================================================

def _price_default_decay(good, recipes, trace_context=None):
    """When no bids and no asks, price decays toward fundamental cost."""
    recipe = recipes[good]
    before = recipe['price']
    cost_to_make = 1.0
    input_good = None
    input_cost = None
    if recipe.get('numInput', 0) > 0 and recipe.get('production', 0) > 0:
        input_good = recipe['input']
        input_cost = recipes[input_good]['price']
        cost_to_make = (recipe['numInput'] * input_cost) / recipe['production']
    if recipe['price'] > cost_to_make * 1.05:
        recipe['price'] = max(cost_to_make, recipe['price'] * 0.95)
    recipe['price'] = max(cost_to_make, recipe['price'])
    if trace_context is not None:
        from run_trace import emit
        emit(trace_context, kind='econsim_market_price_decay',
             record_class='calculation', phase='market',
             subject={'type': 'simulation', 'id': 'econsim', 'good': good.name},
             metric_id='goods.price', unit='local_currency_per_unit',
             before=before, after=recipe['price'],
             formula_id='econsim.price_decay.v1',
             inputs={'prior_display_price': before,
                     'prior_internal_reference': None,
                     'new_internal_reference': None,
                     'trigger': 'no_bids_and_no_asks',
                     'threshold_multiplier': 1.05, 'decay_factor': 0.95,
                     'input_cost_floor': cost_to_make,
                     'input_good': input_good.name if input_good is not None else None,
                     'input_price': input_cost,
                     'input_quantity': recipe.get('numInput', 0),
                     'production_quantity': recipe.get('production', 0),
                     'price_basis': 'legacy_econsim_recipe_price',
                     'currency': 'local'},
             constraints={'active_floor': cost_to_make
                          if recipe['price'] == cost_to_make else None})


# =============================================================================
# BIDS & ASKS
# =============================================================================

def gather_bids_asks(t, agents, good, good_price, number_desired, recipes,
                    total_asks, total_bids):
    for agent in agents:
        agent_rec = recipes[agent.output]
        is_employee = getattr(agent, 'employer', None) is not None
        _withdraw_if_low_cash(agent, good_price, number_desired, bank, t=t)
        mult = getattr(agent, 'consumption_multiplier', 1.0)
        bid = _compute_bid(agent, good, good_price, number_desired, agent_rec,
                           is_employee, mult, recipes)
        agent.bid = bid
        agent.remainingCash -= agent.bid * good_price
        loginfo(t, agent.name(), 'bid', agent.bid, 'input',
                get_input_commodity(agent, recipes), 'recipe for',
                agent_rec['commodity'], 'num input', agent_rec['numInput'],
                agent.inventory[good.value])
        total_bids += agent.bid
        ask = _compute_ask(agent, good, good_price, recipes, is_employee)
        agent.ask = ask
        total_asks += agent.ask
    return total_asks, total_bids


def _withdraw_if_low_cash(agent, good_price, number_desired, bank, t=None):
    """Withdraw from bank deposits if cash is low for purchasing."""
    bank_balance = bank.deposits.get(agent, 0)
    if bank_balance > 0:
        desired_cash = good_price * number_desired
        if agent.remainingCash < desired_cash:
            needed = desired_cash - agent.remainingCash
            bank.Withdraw(agent, min(bank_balance, needed), t=t,
                          reason='market_bid')


def _compute_bid(agent, good, good_price, number_desired, agent_rec, is_employee,
                 mult, recipes):
    """Compute how much *agent* wants to buy of *good* at *good_price*."""
    if not is_employee and get_input_commodity(agent, recipes) == good:
        # Corporate/Independent producer input bidding
        num_employees = len(agent.employees) if getattr(agent, 'is_corporation',
                                                        False) else 0
        multiplier = 1 + num_employees
        desired = max(0, agent_rec['numInput'] * multiplier
                      - agent.inv_get(good, 0))
        if mult > 1.0:
            desired = int(desired * mult)
        affordable = agent.remainingCash // good_price if good_price > 0 else desired
        return int(min(desired, affordable))
    elif (is_employee or agent.output != good) and agent.remainingCash > good_price:
        # Consumer bidding
        maxinv_limit = agent_rec['maxinv']
        if getattr(agent, 'is_corporation', False):
            maxinv_limit *= (1 + len(agent.employees))
        if mult > 1.0:
            maxinv_limit = int(maxinv_limit * min(mult, 3.0))
        num_storable = max(0, maxinv_limit - agent.inv_get(good, 0))
        base_desire = min(number_desired,
                          agent.remainingCash // good_price)
        scaled_desire = int(base_desire * mult)
        bid = min(scaled_desire, num_storable)
        if mult > 2.0 and good != Goods.food:
            extra_affordable = min(
                int(number_desired * (mult - 1.0)),
                agent.remainingCash // good_price
            ) if good_price > 0 else 0
            bid += min(extra_affordable, num_storable - bid)
            loginfo('', agent.name(),
                    'wealth consumption (mult=' + str(round(mult, 2))
                    + ') bid extra for', good)
        return max(0, min(bid, num_storable))
    return 0


def _compute_ask(agent, good, good_price, recipes, is_employee):
    """Compute how much *agent* wants to sell of *good* at *good_price*."""
    if is_employee:
        return 0
    if agent.output != good and agent.output != Goods.gov:
        if agent.inv_get(good, 0) <= 0:
            return 0
    if agent.output == good or (agent.output == Goods.gov
                                and agent.inv_get(good, 0) > 0):
        cost_to_make = 0
        agent_rec = recipes.get(good, {})
        if agent.output == good and agent_rec.get('numInput', 0) > 0 \
           and agent_rec.get('production', 0) > 0:
            input_com = agent_rec['input']
            input_cost = agent.cost_get(input_com, 0)
            cost_to_make = ((agent_rec['numInput'] * input_cost)
                            / agent_rec['production'])
        if good == Goods.food and agent.output == Goods.food:
            return max(0, agent.inv_get(good, 0) - 2)
        elif good_price >= cost_to_make:
            return max(0, agent.inv_get(good, 0))
    return 0


# =============================================================================
# EXECUTION: buyers & sellers
# =============================================================================

def askers_sell_good(askers, good, price, t, total_bought, total_cash_purchases,
                    total_cash_sales, total_sold):
    for agent in askers:
        if total_sold < total_bought and total_cash_purchases > total_cash_sales:
            ask = agent.ask
            remaining = total_bought - total_sold
            sold = min(ask, remaining)
            assert sold >= 0, 'neg sold ' + str(sold)
            total_sold += sold
            _trace_cash_write = _trace_public_begin(None, agent)
            agent.cash += sold * price
            _trace_public_finish(_trace_cash_write, 'econsim_trade_money:askers_sell_good',
                                 inputs={"source_writer": 'econsim_trade_money.py:askers_sell_good:0f1355ebe5b1abd1:1'})
            agent.inv_add(good, -sold)
            total_cash_sales += sold * price
            if sold > 0:
                loginfo(t, agent.name(), 'sold ', sold, good, ', ask: ', ask)
    return total_cash_sales, total_sold


def bidders_buy_good(t, agents, good, bought_log, price, total_asks,
                    total_bought):
    bidders = sorted(agents, key=lambda a: a.hungry_steps, reverse=True)
    total_cash_purchases = 0
    for agent in bidders:
        if total_asks > total_bought:
            prevCash = agent.cash
            bid = agent.bid
            remaining = total_asks - total_bought
            affordable = int(agent.cash / price)
            bought = max(0, min(bid, min(remaining, affordable)))
            cash = bought * price
            _trace_cash_write = _trace_public_begin(None, agent)
            agent.cash = max(0.0, agent.cash - cash)
            _trace_public_finish(_trace_cash_write, 'econsim_trade_money:bidders_buy_good',
                                 inputs={"source_writer": 'econsim_trade_money.py:bidders_buy_good:2952f6d97de06b7b:1'})
            assert agent.cash >= -1e-5, (
                'neg cash, bought $' + str(cash) + ' of ' + str(good)
                + ' now has ' + str(agent.cash))
            total_cash_purchases += cash
            if bought > 0:
                logdebug(t, agent.name(), 'had $', prevCash, 'now',
                         agent.cash, 'bought ', bought, good, ', bid: ',
                         bid, 'affordable: ', affordable, 'remaining:',
                         remaining)
                old_qty = agent.inv_get(good, 0)
                old_cost = agent.cost_get(good, 0)
                total_qty = old_qty + bought
                if total_qty > 0:
                    agent.cost_set(good, (old_qty * old_cost + bought * price) / total_qty)
                else:
                    agent.cost_set(good, price)
                agent.inv_add(good, bought)
                total_bought += bought
                bought_log[agent.output][good][-1] += bought
            else:
                logdebug(t, agent.name(), 'had $', prevCash, 'now',
                         agent.cash, 'bought ', bought, good, ', bid: ',
                         bid, 'affordable: ', affordable, 'remaining:',
                         remaining)
    return total_bought, total_cash_purchases


# =============================================================================
# MARKET PRICE
# =============================================================================

def set_market_price(demand_ratio, good, recipes, agents=None, trace_context=None):
    recipe = recipes[good]
    price = recipe['price']
    before = price
    fundamental_cost = 1.0
    input_good = None
    input_cost = None
    if recipe.get('numInput', 0) > 0 and recipe.get('production', 0) > 0:
        input_good = recipe['input']
        input_cost = recipes[input_good]['price']
        fundamental_cost = (recipe['numInput'] * input_cost) / recipe['production']
    food_price = recipes.get(Goods.food, {}).get('price', 1.0)
    production_rate = recipe.get('production', 1)
    living_cost_floor = (4 * food_price) / max(1, production_rate)
    if recipe.get('numInput', 0) > 0:
        min_price_floor = max(fundamental_cost * 1.10, living_cost_floor)
    else:
        min_price_floor = max(living_cost_floor, 0.10)
    demand_multiplier = 1.0
    if demand_ratio >= 1:
        clamped_ratio = min(5.0, demand_ratio - 1)
        demand_multiplier = lerp(1.01, 1.20, clamped_ratio / 5.0)
        price *= demand_multiplier
    elif demand_ratio < 0.2:
        demand_multiplier = lerp(0.90, 0.95, demand_ratio / 0.2)
        price *= demand_multiplier
    elif demand_ratio < .5:
        demand_multiplier = lerp(0.95, 1.0, (demand_ratio - 0.2) / 0.3)
        price *= demand_multiplier
    price_after_demand = price
    producers = []
    dynamic_adjusted_price = None
    if agents and good != Goods.gov:
        producer_agents = [a for a in agents if a.output == good]
        if producer_agents:
            total_multiplier = 0
            for a in producer_agents:
                poor_factor = clamp(a.cash / 20.0, 0.2, 1.0)
                hungry_factor = max(0.1, 0.8 ** a.hungry_steps)
                total_multiplier += poor_factor * hungry_factor
                producers.append({'cash': a.cash, 'hungry_steps': a.hungry_steps,
                                  'poor_factor': poor_factor,
                                  'hungry_factor': hungry_factor,
                                  'price_multiplier': poor_factor * hungry_factor})
            avg_multiplier = total_multiplier / len(producer_agents)
            dynamic_adjusted_price = fundamental_cost * avg_multiplier
            price = max(price, dynamic_adjusted_price)
    price_before_floor = price
    price = max(min_price_floor, price)
    price = max(0.1, price)
    recipe['price'] = price
    if trace_context is not None:
        from run_trace import emit
        emit(trace_context, kind='econsim_market_price_update',
             record_class='calculation', phase='market',
             subject={'type': 'simulation', 'id': 'econsim', 'good': good.name},
             metric_id='goods.price', unit='local_currency_per_unit',
             before=before, after=price,
             formula_id='econsim.market_price.v1',
             inputs={'prior_display_price': before,
                     'prior_internal_reference': None,
                     'new_internal_reference': None,
                     'demand_ratio': demand_ratio,
                     'demand_multiplier': demand_multiplier,
                     'price_after_demand': price_after_demand,
                     'fundamental_cost': fundamental_cost,
                     'input_good': input_good.name if input_good is not None else None,
                     'input_price': input_cost,
                     'input_quantity': recipe.get('numInput', 0),
                     'production_quantity': recipe.get('production', 0),
                     'food_price': food_price,
                     'production_rate': production_rate,
                     'living_cost_floor': living_cost_floor,
                     'min_price_floor': min_price_floor,
                     'producers': producers,
                     'dynamic_adjusted_price': dynamic_adjusted_price,
                     'price_before_floor': price_before_floor,
                     'price_basis': 'legacy_econsim_recipe_price',
                     'currency': 'local'},
             constraints={'min_price_floor': min_price_floor,
                          'dynamic_price_floor': dynamic_adjusted_price,
                          'active_floor': (min_price_floor
                                           if price == min_price_floor else None)})
    return price


# =============================================================================
# BORROW / DEPOSIT DECISIONS
# =============================================================================

def decide_borrow_deposit(agents, all_goods_price, bank, food_price,
                          previous_total_cash, t):
    for agent in agents:
        borrow_if_needed(t, agent, bank=bank)
        PayLoans(agent, bank=bank, t=t)
        _maybe_borrow_food_money(t, agent, food_price, bank)
        _maybe_borrow_inputs(t, agent, bank)
        _deposit_excess_cash(t, agent, all_goods_price, bank)
        agent.remainingCash = agent.cash


def _maybe_borrow_food_money(t, agent, food_price, bank):
    """Borrow for food if starving and no cash."""
    from nutrition import food_credit_pressure
    from random_cache import rand
    pressure = food_credit_pressure(agent)
    if agent.output != Goods.food and agent.cash < food_price \
       and pressure > 0 and rand.random() < pressure:
        bank_balance = bank.deposits.get(agent, 0)
        if bank_balance > 0:
            needed = food_price - agent.cash
            bank.Withdraw(agent, min(bank_balance, needed), t=t,
                          reason='food_purchase_liquidity')
        if agent.cash < food_price:
            Borrow(t, agent, food_price, bank)


def _maybe_borrow_inputs(t, agent, bank):
    """Borrow for business inputs if insufficient cash."""
    if agent.output not in recipes:
        return
    if recipes[agent.output].get('numInput', 0) <= 0:
        return
    input_com = recipes[agent.output]['input']
    input_price = recipes[input_com]['price']
    num_input = recipes[agent.output]['numInput']
    cost = input_price * num_input
    if agent.cash >= cost:
        return
    bank_balance = bank.deposits.get(agent, 0)
    if bank_balance > 0:
        amount_needed = cost - agent.cash
        bank.Withdraw(agent, min(bank_balance, amount_needed), t=t,
                      reason='production_input_liquidity')
    if agent.cash < cost:
        amount_needed = cost - agent.cash
        bank.Borrow(t, agent, amount_needed)


def _deposit_excess_cash(t, agent, all_goods_price, bank):
    """Deposit excess cash above a consumption-multiplier-based floor."""
    mult = getattr(agent, 'consumption_multiplier', 1.0)
    total_liquid = agent.cash + bank.deposits.get(agent, 0)
    current_deposits = bank.deposits.get(agent, 0)
    deposit_frac = max(0.30, min(0.70, 0.70 / max(1.0, mult)))
    cash_floor = int(all_goods_price * (100 / max(1.0, mult)))
    max_deposits = total_liquid * deposit_frac
    excess_deposit_capacity = max(0, max_deposits - current_deposits)
    if agent.cash > cash_floor and excess_deposit_capacity > 0:
        amount = min(agent.cash - cash_floor, excess_deposit_capacity)
        bank.Deposit(agent, amount, t=t, reason='excess_cash_sweep')


# =============================================================================
# SECONDARY MARKET
# =============================================================================

def secondary_trade(t, agents, good, current_market_price, recipes):
    """Execute a secondary market: distressed sellers, premium buyers."""
    recipe = recipes[good]
    fundamental_cost = 1.0
    if recipe.get('numInput', 0) > 0 and recipe.get('production', 0) > 0:
        input_cost = recipes[recipe['input']]['price']
        fundamental_cost = (recipe['numInput'] * input_cost) / recipe['production']
    min_secondary_price = fundamental_cost * 1.05
    secondary_asks = _gather_secondary_asks(agents, good, current_market_price,
                                            min_secondary_price)
    secondary_bids = _gather_secondary_bids(agents, good, current_market_price,
                                            recipes)
    return _match_secondary_orders(secondary_asks, secondary_bids, good, t)


def _gather_secondary_asks(agents, good, market_price, min_price):
    """Collect distressed sellers with discounted prices."""
    asks = []
    for agent in agents:
        is_employee = getattr(agent, 'employer', None) is not None
        remaining_inv = agent.inv_get(good, 0)
        keep_amount = 2 if (good == Goods.food
                            and agent.output == Goods.food) else 0
        sellable = max(0, remaining_inv - keep_amount)
        if sellable > 0 and agent.output == good and not is_employee:
            poor_factor = clamp(agent.cash / 20.0, 0.2, 1.0)
            hungry_factor = max(0.1, 0.8 ** agent.hungry_steps)
            distress_factor = poor_factor * hungry_factor
            min_ask = min_price * distress_factor
            ask_price = max(min_ask, market_price * distress_factor)
            asks.append(Offer(False, agent, ask_price, sellable))
    return asks


def _gather_secondary_bids(agents, good, market_price, recipes):
    """Collect buyers willing to pay a premium."""
    bids = []
    for agent in agents:
        is_employee = getattr(agent, 'employer', None) is not None
        if not is_employee and agent.output == good:
            continue
        desired = 0
        if not is_employee and get_input_commodity(agent, recipes) == good:
            num_employees = len(agent.employees) if getattr(agent, 'is_corporation',
                                                            False) else 0
            agent_rec = recipes[agent.output]
            desired = max(0, recipes[good]['numInput'] * (1 + num_employees)
                          - agent.inv_get(good, 0))
        else:
            maxinv_limit = recipes[good]['maxinv']
            if getattr(agent, 'is_corporation', False):
                maxinv_limit *= (1 + len(agent.employees))
            num_storable = max(0, maxinv_limit - agent.inv_get(good, 0))
            if good == Goods.food:
                desired = min(16, num_storable)
            elif agent.remainingCash > market_price * 2:
                desired = min(1, num_storable)
        if desired > 0 and agent.remainingCash > 0:
            premium = _compute_bid_premium(agent, good, market_price, recipes)
            max_willing = market_price * premium
            affordable_qty = agent.remainingCash / max_willing
            if affordable_qty >= 1:
                bid_qty = min(desired, int(affordable_qty))
                bids.append(Offer(True, agent, max_willing, bid_qty))
            elif agent.remainingCash >= market_price * 0.5:
                bids.append(Offer(True, agent, agent.remainingCash, 1))
    return bids


def _compute_bid_premium(agent, good, market_price, recipes):
    """How much above market price is *agent* willing to pay?"""
    is_employee = getattr(agent, 'employer', None) is not None
    mult = getattr(agent, 'consumption_multiplier', 1.0)
    if good == Goods.food and agent.hungry_steps > 0:
        base_premium = 1.0 + 0.5 * agent.hungry_steps
        return min(10.0, base_premium * mult * 0.5)
    elif (not is_employee and agent.output in recipes
          and get_input_commodity(agent, recipes) == good
          and agent.inv_get(good, 0) == 0):
        premium = 1.0 + (mult - 1.0) * 0.5
        return max(1.5, min(5.5, premium))
    elif mult > 2.0 and good != Goods.food:
        return 1.0 + (mult - 1.0) * 0.3
    return 1.0


def _match_secondary_orders(asks, bids, good, t):
    """Sort and match ask/bid offers; execute trades."""
    asks.sort(key=lambda x: x.price)
    bids.sort(key=lambda x: x.price, reverse=True)
    total_traded = 0
    total_value = 0
    ask_idx = 0
    bid_idx = 0
    while ask_idx < len(asks) and bid_idx < len(bids):
        ask = asks[ask_idx]
        bid = bids[bid_idx]
        if bid.price >= ask.price:
            clear_price = (bid.price + ask.price) / 2.0
            trade_qty = min(ask.quantity, bid.quantity)
            max_affordable = (
                int(bid.agent.remainingCash / clear_price)
                if clear_price > 0 else trade_qty
            )
            trade_qty = min(trade_qty, max_affordable)
            if trade_qty > 0:
                cost = trade_qty * clear_price
                bid.agent.remainingCash -= cost
                _trace_cash_write = _trace_public_begin(None, bid.agent)
                bid.agent.cash -= cost
                _trace_public_finish(_trace_cash_write, 'econsim_trade_money:_match_secondary_orders',
                                     inputs={"source_writer": 'econsim_trade_money.py:_match_secondary_orders:35dbef5f3ad5bd7c:1'})
                _trace_cash_write = _trace_public_begin(None, ask.agent)
                ask.agent.cash += cost
                _trace_public_finish(_trace_cash_write, 'econsim_trade_money:_match_secondary_orders',
                                     inputs={"source_writer": 'econsim_trade_money.py:_match_secondary_orders:ccbe9e03380c1bc1:1'})
                bid.agent.inv_add(good, trade_qty)
                ask.agent.inv_add(good, -trade_qty)
                old_qty = bid.agent.inv_get(good, 0) - trade_qty
                old_cost = bid.agent.cost_get(good, 0)
                if bid.agent.inv_get(good, 0) > 0:
                    bid.agent.cost_set(good, (old_qty * old_cost + cost) / bid.agent.inv_get(good, 0))
                total_traded += trade_qty
                total_value += cost
                ask.quantity -= trade_qty
                bid.quantity -= trade_qty
                loginfo(t, "SECONDARY TRADE:", bid.agent.name(),
                        "bought", trade_qty, good, "from",
                        ask.agent.name(), "at $",
                        round(clear_price, 2))
        if ask.quantity <= 0:
            ask_idx += 1
        if bid.quantity <= 0 or bid.price < ask.price:
            bid_idx += 1
    return total_traded, total_value


# =============================================================================
# HELPERS
# =============================================================================

def report_cash(t, agents, previous_total_cash, msg, print=False):
    temp_total_cash = get_total_cash(agents, bank)
    diff = math.fabs(temp_total_cash - previous_total_cash)
    epsilon = 1e-8
    if diff > epsilon or print:
        loginfo(t, msg, "total cash", previous_total_cash, '!=', temp_total_cash,
                diff)


def get_total_cash(agents, bank=None):
    if bank is None:
        bank = globals().get('bank', None)
        if bank is None:
            return sum(agent.cash for agent in agents)
    return sum(agent.cash for agent in agents) + bank.equity
